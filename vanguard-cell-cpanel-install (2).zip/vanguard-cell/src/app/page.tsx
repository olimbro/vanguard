'use client'
import { useEffect, useState, useCallback } from 'react'
import { useApp, api } from '@/lib/store'
import { LoginScreen } from '@/components/app/login'
import { AppShell } from '@/components/app/shell'
import { DashboardView } from '@/components/app/views/dashboard'
import { MembersView } from '@/components/app/views/members'
import { EventsView } from '@/components/app/views/events'
import { AttendanceView } from '@/components/app/views/attendance'
import { LeaderboardView } from '@/components/app/views/leaderboard'
import { AnnouncementsView } from '@/components/app/views/announcements'
import { MessagesView } from '@/components/app/views/messages'
import { ReportsView } from '@/components/app/views/reports'
import { SettingsView } from '@/components/app/views/settings'
import { AuditView } from '@/components/app/views/audit'
import { ProfileView } from '@/components/app/views/profile'
import { VisitorsView } from '@/components/app/views/visitors'
import { FollowUpView } from '@/components/app/views/followup'
import { GamificationView } from '@/components/app/views/gamification'
import { NotificationsView } from '@/components/app/views/notifications'
import { CalendarView } from '@/components/app/views/calendar'
import { UsersView } from '@/components/app/views/users'
import { PermissionsView } from '@/components/app/views/permissions'

export default function Home() {
  const { user, setUser, loading, setLoading, view, pendingSyncCount, setPendingSyncCount } = useApp()
  const [online, setOnline] = useState(true)

  const loadMe = useCallback(async () => {
    try {
      const data = await api('/api/auth/me')
      setUser(data.user)
    } catch {
      setUser(null)
    } finally {
      setLoading(false)
    }
  }, [setUser, setLoading])

  useEffect(() => {
    loadMe()
  }, [loadMe])

  useEffect(() => {
    const goOnline = () => {
      setOnline(true)
      // Try to sync offline queue
      import('@/lib/store').then(({ syncOfflineQueue }) => {
        syncOfflineQueue().then((r) => {
          if (r.synced > 0) {
            setPendingSyncCount(0)
            // Reload dashboard data
            loadMe()
          }
        }).catch(() => {})
      })
    }
    const goOffline = () => setOnline(false)
    window.addEventListener('online', goOnline)
    window.addEventListener('offline', goOffline)
    setOnline(navigator.onLine)

    // Load pending sync count on mount
    import('@/lib/store').then(({ getOfflineQueue }) => {
      getOfflineQueue().then((q) => setPendingSyncCount(q.length)).catch(() => {})
    })

    return () => {
      window.removeEventListener('online', goOnline)
      window.removeEventListener('offline', goOffline)
    }
  }, [loadMe, setPendingSyncCount])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0B2A5B] to-[#123F8C]">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-[#E7B93E] to-[#D4AF37] flex items-center justify-center text-3xl font-bold text-[#0B2A5B]">V</div>
          <div className="text-white/80 text-sm animate-pulse">Loading Vanguard Cell...</div>
        </div>
      </div>
    )
  }

  if (!user) {
    return <LoginScreen onLoggedIn={loadMe} />
  }

  const isAdmin = ['SUPER_ADMIN', 'CELL_ADMIN', 'ASSISTANT', 'WORKER'].includes(user.role)

  return (
    <AppShell online={online}>
      {view === 'dashboard' && <DashboardView />}
      {view === 'members' && <MembersView />}
      {view === 'events' && <EventsView />}
      {view === 'attendance' && <AttendanceView />}
      {view === 'leaderboard' && <LeaderboardView />}
      {view === 'announcements' && <AnnouncementsView />}
      {view === 'messages' && <MessagesView />}
      {view === 'reports' && <ReportsView />}
      {view === 'settings' && <SettingsView />}
      {view === 'audit' && <AuditView />}
      {view === 'profile' && <ProfileView />}
      {view === 'visitors' && isAdmin && <VisitorsView />}
      {view === 'followup' && isAdmin && <FollowUpView />}
      {view === 'gamification' && <GamificationView />}
      {view === 'notifications' && <NotificationsView />}
      {view === 'calendar' && <CalendarView />}
      {view === 'users' && user.role === 'SUPER_ADMIN' && <UsersView />}
      {view === 'permissions' && user.role === 'SUPER_ADMIN' && <PermissionsView />}
    </AppShell>
  )
}

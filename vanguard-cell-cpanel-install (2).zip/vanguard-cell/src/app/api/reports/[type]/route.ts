import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'
import { getEngagementHealth } from '@/lib/gamification'
import { audit } from '@/lib/audit'

// GET /api/reports/[type]?from=&to=&format=csv|json
// types: attendance, engagement, growth, follow-up, leaderboard, monthly-engagement, event-performance
export async function GET(req: NextRequest, { params }: { params: Promise<{ type: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!['SUPER_ADMIN', 'CELL_ADMIN', 'ASSISTANT', 'WORKER'].includes(auth.session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const { type } = await params
  const { searchParams } = new URL(req.url)
  const from = searchParams.get('from') ? new Date(searchParams.get('from')!) : new Date(Date.now() - 30 * 24 * 3600 * 1000)
  const to = searchParams.get('to') ? new Date(searchParams.get('to')!) : new Date()
  const format = searchParams.get('format') || 'json'
  const cellFilter = auth.cellId ? { cellId: auth.cellId } : {}

  if (type === 'attendance') {
    const records = await db.attendanceRecord.findMany({
      where: { event: { ...cellFilter, startDate: { gte: from, lte: to } } },
      include: { member: { include: { currentRank: true } }, event: true },
      orderBy: { createdAt: 'desc' },
    })
    if (format === 'csv') return csvResponse('attendance', records.map((r) => ({
      Member: r.member?.fullName || '',
      Event: r.event?.name || '',
      Date: r.event?.startDate?.toISOString().split('T')[0] || '',
      Status: r.status,
      Method: r.method,
      CheckIn: r.checkInTime?.toISOString() || '',
      Duration: r.durationMinutes || '',
    })))
    return NextResponse.json({ records })
  }

  if (type === 'engagement') {
    const members = await db.member.findMany({
      where: { ...cellFilter, status: { not: 'ARCHIVED' } },
      include: { currentRank: true, user: true, _count: { select: { attendanceRecords: true, badges: true } } },
      orderBy: { engagementScore: 'desc' },
    })
    const data = members.map((m) => ({
      Name: m.fullName,
      Status: m.status,
      AttendancePct: Math.round(m.attendancePercentage * 10) / 10,
      EngagementScore: Math.round(m.engagementScore * 10) / 10,
      Health: getEngagementHealth(m.engagementScore).label,
      Rank: m.currentRank?.name || 'Newcomer',
      Points: m.currentPoints,
      Streak: m.currentStreak,
      LongestStreak: m.longestStreak,
      LastAttendance: m.lastAttendanceAt?.toISOString().split('T')[0] || 'Never',
      Badges: m._count.badges,
    }))
    if (format === 'csv') return csvResponse('engagement', data)
    return NextResponse.json({ members: data })
  }

  if (type === 'growth') {
    const newMembers = await db.member.count({ where: { ...cellFilter, dateJoinedCell: { gte: from, lte: to } } })
    const visitors = await db.visitor.count({ where: { cellId: auth.cellId || undefined, firstVisitDate: { gte: from, lte: to } } })
    const conversions = await db.visitor.count({ where: { cellId: auth.cellId || undefined, convertedAt: { gte: from, lte: to } } })
    const activeMembers = await db.member.count({ where: { ...cellFilter, status: { in: ['ACTIVE_MEMBER', 'REGULAR_MEMBER', 'WORKER', 'CELL_LEADER'] } } })
    const inactiveMembers = await db.member.count({ where: { ...cellFilter, status: 'INACTIVE' } })
    const data = { Period: `${from.toISOString().split('T')[0]} to ${to.toISOString().split('T')[0]}`, NewMembers: newMembers, Visitors: visitors, Conversions: conversions, ActiveMembers: activeMembers, InactiveMembers: inactiveMembers }
    if (format === 'csv') return csvResponse('growth', [data])
    return NextResponse.json(data)
  }

  if (type === 'follow-up') {
    const followups = await db.followUp.findMany({
      where: { subject: cellFilter },
      include: { subject: { select: { id: true, fullName: true } }, worker: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
    })
    const data = followups.map((f) => ({
      Member: f.subject?.fullName || '',
      Worker: f.worker?.name || 'Unassigned',
      Status: f.status,
      Priority: f.priority,
      LastContact: f.lastContactAt?.toISOString().split('T')[0] || '',
      NextFollowUp: f.nextFollowUpAt?.toISOString().split('T')[0] || '',
      Outcome: f.outcome || '',
    }))
    if (format === 'csv') return csvResponse('follow-up', data)
    return NextResponse.json({ followups: data })
  }

  if (type === 'leaderboard') {
    const members = await db.member.findMany({
      where: { ...cellFilter, status: { not: 'ARCHIVED' } },
      include: { currentRank: true, _count: { select: { badges: true } } },
      orderBy: { currentPoints: 'desc' },
      take: 50,
    })
    const data = members.map((m, i) => ({
      Rank: i + 1,
      Name: m.fullName,
      Points: m.currentPoints,
      RankName: m.currentRank?.name || 'Newcomer',
      Streak: m.currentStreak,
      Badges: m._count.badges,
      AttendancePct: Math.round(m.attendancePercentage * 10) / 10,
    }))
    if (format === 'csv') return csvResponse('leaderboard', data)
    return NextResponse.json({ leaderboard: data })
  }

  if (type === 'event-performance') {
    const events = await db.event.findMany({
      where: { ...cellFilter, startDate: { gte: from, lte: to } },
      include: { _count: { select: { registrations: true, attendanceRecords: true } } },
      orderBy: { startDate: 'desc' },
    })
    const data = await Promise.all(events.map(async (e) => {
      const attended = await db.attendanceRecord.count({ where: { eventId: e.id, status: { in: ['PRESENT', 'LATE'] } } })
      const registered = await db.eventRegistration.count({ where: { eventId: e.id, status: { in: ['REGISTERED', 'CONFIRMED', 'ATTENDED'] } } })
      const noShow = registered > 0 ? registered - attended : 0
      return {
        Event: e.name,
        Date: e.startDate?.toISOString().split('T')[0] || '',
        Registered: registered,
        Attended: attended,
        NoShow: noShow,
        AttendancePct: registered > 0 ? Math.round((attended / registered) * 1000) / 10 : 0,
      }
    }))
    if (format === 'csv') return csvResponse('event-performance', data)
    return NextResponse.json({ events: data })
  }

  if (type === 'monthly-engagement') {
    // Section 33/82 — Monthly Cell Engagement Report
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1)
    const monthEnd = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0, 23, 59, 59)
    const totalMembers = await db.member.count({ where: { ...cellFilter, status: { not: 'ARCHIVED' } } })
    const activeMembers = await db.member.count({ where: { ...cellFilter, status: { in: ['ACTIVE_MEMBER', 'REGULAR_MEMBER', 'WORKER', 'CELL_LEADER'] } } })
    const visitors = await db.visitor.count({ where: { cellId: auth.cellId || undefined, firstVisitDate: { gte: monthStart, lte: monthEnd } } })
    const newMembers = await db.member.count({ where: { ...cellFilter, dateJoinedCell: { gte: monthStart, lte: monthEnd } } })
    const avgAttendancePct = (await db.member.aggregate({ where: { ...cellFilter, status: { not: 'ARCHIVED' } }, _avg: { attendancePercentage: true } }))._avg.attendancePercentage || 0
    const avgEngagement = (await db.member.aggregate({ where: { ...cellFilter, status: { not: 'ARCHIVED' } }, _avg: { engagementScore: true } }))._avg.engagementScore || 0
    const eventsHeld = await db.event.count({ where: { ...cellFilter, startDate: { gte: monthStart, lte: monthEnd } } })
    const totalAttendance = await db.attendanceRecord.count({ where: { event: { ...cellFilter, startDate: { gte: monthStart, lte: monthEnd } }, status: { in: ['PRESENT', 'LATE'] } } })
    const needingFollowUp = await db.member.count({ where: { ...cellFilter, OR: [{ lastAttendanceAt: { lt: new Date(Date.now() - 21 * 24 * 3600 * 1000) } }, { lastAttendanceAt: null }] } })
    const topMember = await db.member.findFirst({ where: { ...cellFilter, status: { not: 'ARCHIVED' } }, orderBy: { currentPoints: 'desc' }, include: { currentRank: true } })
    const highestStreak = await db.member.findFirst({ where: { ...cellFilter, status: { not: 'ARCHIVED' } }, orderBy: { longestStreak: 'desc' } })

    const cell = auth.cellId ? await db.cell.findUnique({ where: { id: auth.cellId }, include: { church: true } }) : null
    const report = {
      Cell: cell?.name || '',
      Church: cell?.church?.name || '',
      Period: new Date().toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }),
      TotalMembers: totalMembers,
      ActiveMembers: activeMembers,
      Visitors: visitors,
      NewMembers: newMembers,
      AverageAttendance: Math.round(avgAttendancePct) + '%',
      AverageEngagement: Math.round(avgEngagement) + '%',
      EventsHeld: eventsHeld,
      TotalAttendance: totalAttendance,
      MembersNeedingFollowUp: needingFollowUp,
      TopParticipation: topMember?.fullName || 'N/A',
      HighestAttendanceStreak: highestStreak ? `${highestStreak.longestStreak} weeks` : 'N/A',
    }
    if (format === 'csv') return csvResponse('monthly-engagement', [report])
    return NextResponse.json(report)
  }

  return NextResponse.json({ error: 'Unknown report type' }, { status: 404 })
}

function csvResponse(name: string, rows: any[]) {
  if (rows.length === 0) {
    return new NextResponse('No data', { headers: { 'Content-Type': 'text/plain' } })
  }
  const headers = Object.keys(rows[0])
  const lines = [headers.join(',')]
  for (const r of rows) {
    lines.push(headers.map((h) => `"${String(r[h] ?? '').replace(/"/g, '""')}"`).join(','))
  }
  return new NextResponse(lines.join('\n'), {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename="${name}-${new Date().toISOString().split('T')[0]}.csv"`,
    },
  })
}

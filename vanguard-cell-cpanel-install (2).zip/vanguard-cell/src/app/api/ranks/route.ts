import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'

// GET all ranks (sorted by level)
export async function GET() {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const ranks = await db.rank.findMany({ orderBy: { level: 'asc' } })
  const badges = await db.badge.findMany({ where: { isActive: true }, orderBy: { name: 'asc' } })
  return NextResponse.json({ ranks, badges })
}

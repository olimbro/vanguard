import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'

// Generate a QR token for an event (admin displays this; members scan it)
export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const body = await req.json()
  const { eventId } = body
  if (!eventId) return NextResponse.json({ error: 'eventId required' }, { status: 400 })
  const event = await db.event.findUnique({ where: { id: eventId } })
  if (!event) return NextResponse.json({ error: 'Event not found' }, { status: 404 })
  // QR token format: base64(eventId:expiresAt:hmac)
  // Simplified: base64(eventId:expiresAt)
  const expiresAt = Date.now() + 5 * 60 * 1000 // 5-minute validity
  const payload = `${event.id}:${expiresAt}`
  const token = Buffer.from(payload, 'utf8').toString('base64')
  // Compute PIN (4-digit, derived from event ID hash)
  const pin = String(
    Math.abs(
      event.id.split('').reduce((acc: number, c: string) => (acc * 31 + c.charCodeAt(0)) | 0, 7)
    ) % 10000
  ).padStart(4, '0')
  return NextResponse.json({ token, pin, expiresAt, eventId: event.id, eventName: event.name })
}

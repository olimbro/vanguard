import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'
import { getLeaderboard } from '@/lib/gamification'

// GET /api/leaderboard?period=WEEKLY|MONTHLY|QUARTERLY|ALL_TIME&cellId=...
export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { searchParams } = new URL(req.url)
  const period = (searchParams.get('period') || 'WEEKLY') as any
  const cellId = searchParams.get('cellId') || auth.cellId || ''
  if (!cellId) return NextResponse.json({ leaderboard: [] })
  const leaderboard = await getLeaderboard(cellId, period, 30)
  return NextResponse.json({ leaderboard, period })
}

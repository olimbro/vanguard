import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canTakeAttendance } from '@/lib/api-auth'

// GET /api/events/[id]/live — live event dashboard data
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { id } = await params
  const event = await db.event.findUnique({
    where: { id },
    include: {
      host: { select: { id: true, name: true } },
      cell: true,
      _count: { select: { registrations: true, attendanceRecords: true } },
    },
  })
  if (!event) return NextResponse.json({ error: 'Event not found' }, { status: 404 })

  const [registered, attended, registrations, attendanceRecords, recentCheckIns, members] = await Promise.all([
    db.eventRegistration.count({ where: { eventId: id, status: { in: ['REGISTERED', 'CONFIRMED', 'ATTENDED'] } } }),
    db.attendanceRecord.count({ where: { eventId: id, status: { in: ['PRESENT', 'LATE'] } } }),
    db.eventRegistration.findMany({
      where: { eventId: id },
      include: { user: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: 'asc' },
    }),
    db.attendanceRecord.findMany({
      where: { eventId: id },
      include: { member: { select: { id: true, fullName: true, preferredName: true } } },
    }),
    db.attendanceRecord.findMany({
      where: { eventId: id, checkInTime: { not: null } },
      include: { member: { select: { id: true, fullName: true } } },
      orderBy: { checkInTime: 'desc' },
      take: 10,
    }),
    db.member.findMany({
      where: { cellId: event.cellId, status: { not: 'ARCHIVED' } },
      include: {
        user: { select: { id: true, name: true } },
        attendanceRecords: { where: { eventId: id }, select: { id: true, status: true, method: true, checkInTime: true } },
      },
      orderBy: { fullName: 'asc' },
    }),
  ])

  // Compute attendance pct
  const attendancePct = registered > 0 ? Math.round((attended / registered) * 1000) / 10 : 0

  return NextResponse.json({
    event: {
      id: event.id, name: event.name, startDate: event.startDate,
      venue: event.venue, address: event.address,
      startTime: event.startTime, endTime: event.endTime,
      status: event.status, capacity: event.capacity,
      registrationRequired: event.registrationRequired,
      enablePin: event.enablePin, enableQr: event.enableQr,
      enableGeolocation: event.enableGeolocation,
      host: event.host,
    },
    stats: {
      registered, attended, remaining: event.capacity ? Math.max(0, event.capacity - attended) : null,
      attendancePct,
      total: members.length,
    },
    members: members.map((m) => ({
      id: m.id, name: m.fullName, preferredName: m.preferredName,
      status: m.status,
      attendance: m.attendanceRecords[0] || null,
    })),
    recentCheckIns: recentCheckIns.map((r) => ({
      id: r.id, member: r.member?.fullName, status: r.status,
      method: r.method, checkInTime: r.checkInTime,
    })),
    registrations: registrations.map((r) => ({
      id: r.id, registrationNumber: r.registrationNumber,
      name: r.guestName || r.user?.name, email: r.guestEmail || r.user?.email,
      status: r.status, checkedInAt: r.checkedInAt,
    })),
  })
}

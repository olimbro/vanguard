import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { id } = await params
  const event = await db.event.findUnique({
    where: { id },
    include: {
      host: { select: { id: true, name: true } },
      cell: true,
      series: true,
      registrationFields: { orderBy: { order: 'asc' } },
      _count: { select: { registrations: true, attendanceRecords: true } },
    },
  })
  if (!event) return NextResponse.json({ error: 'Event not found' }, { status: 404 })
  return NextResponse.json({ event })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { id } = await params
  const body = await req.json()
  const before = await db.event.findUnique({ where: { id } })
  if (!before) return NextResponse.json({ error: 'Event not found' }, { status: 404 })
  const { startDate, endDate, registrationDeadline, ...rest } = body
  const updated = await db.event.update({
    where: { id },
    data: {
      ...rest,
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
      registrationDeadline: registrationDeadline ? new Date(registrationDeadline) : undefined,
    },
  })
  await audit({ actorId: auth.session.userId, action: 'UPDATE', objectType: 'Event', objectId: id, oldValue: before, newValue: body })
  return NextResponse.json({ event: updated })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!['SUPER_ADMIN', 'CELL_ADMIN'].includes(auth.session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const { id } = await params
  await db.event.delete({ where: { id } })
  await audit({ actorId: auth.session.userId, action: 'DELETE', objectType: 'Event', objectId: id })
  return NextResponse.json({ ok: true })
}

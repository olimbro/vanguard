import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'
import { audit } from '@/lib/audit'
import { randomUUID } from 'crypto'

function slugify(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') + '-' + randomUUID().slice(0, 6)
}

export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status')
  const upcoming = searchParams.get('upcoming') === 'true'
  const past = searchParams.get('past') === 'true'
  const limit = parseInt(searchParams.get('limit') || '50')

  const where: any = {}
  if (auth.session.role !== 'SUPER_ADMIN') where.cellId = auth.cellId
  if (status) where.status = status
  if (upcoming) where.startDate = { gte: new Date() }
  if (past) where.startDate = { lt: new Date() }

  const events = await db.event.findMany({
    where,
    include: {
      host: { select: { id: true, name: true } },
      series: { select: { id: true, name: true } },
      _count: { select: { registrations: true, attendanceRecords: true } },
    },
    orderBy: { startDate: upcoming ? 'asc' : 'desc' },
    take: limit,
  })
  return NextResponse.json({ events })
}

export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const body = await req.json()
  const {
    name, description, eventType, startDate, endDate, startTime, endTime,
    venue, address, mapLink, hostUserId, coverImageUrl, capacity,
    registrationRequired, registrationDeadline, attendanceRequired,
    isPublic, memberEligibility, guestEligibility, accessRule,
    enableGeolocation, geoLat, geoLng, geoRadiusMeters, enablePin, enableQr,
    cellId, status, registrationFields = [],
  } = body
  if (!name || !startDate || !cellId) return NextResponse.json({ error: 'Name, start date and cell are required' }, { status: 400 })

  const event = await db.event.create({
    data: {
      cellId,
      name,
      slug: slugify(name),
      description,
      eventType: eventType || 'WEEKLY_CELL_MEETING',
      startDate: new Date(startDate),
      endDate: endDate ? new Date(endDate) : null,
      startTime, endTime, venue, address, mapLink,
      hostUserId: hostUserId || auth.session.userId,
      coverImageUrl, capacity,
      registrationRequired: !!registrationRequired,
      registrationDeadline: registrationDeadline ? new Date(registrationDeadline) : null,
      attendanceRequired: attendanceRequired !== false,
      isPublic: !!isPublic,
      memberEligibility: memberEligibility || 'ANY',
      guestEligibility: guestEligibility !== false,
      accessRule: accessRule || 'ANYONE',
      enableGeolocation: !!enableGeolocation,
      geoLat, geoLng, geoRadiusMeters,
      enablePin: enablePin !== false,
      enableQr: enableQr !== false,
      status: status || 'PUBLISHED',
      createdById: auth.session.userId,
    },
    include: { cell: true, host: true },
  })

  // Create registration fields if registration required
  if (registrationRequired && registrationFields.length > 0) {
    for (let i = 0; i < registrationFields.length; i++) {
      const f = registrationFields[i]
      await db.registrationField.create({
        data: {
          eventId: event.id,
          label: f.label,
          fieldKey: f.fieldKey || `field_${i}`,
          fieldType: f.fieldType || 'TEXT',
          options: f.options ? JSON.stringify(f.options) : null,
          required: !!f.required,
          order: f.order ?? i,
        },
      })
    }
  }

  await audit({ actorId: auth.session.userId, action: 'CREATE', objectType: 'Event', objectId: event.id, newValue: body })
  return NextResponse.json({ event }, { status: 201 })
}

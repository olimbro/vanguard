import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'

export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!['SUPER_ADMIN', 'CELL_ADMIN'].includes(auth.session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const { searchParams } = new URL(req.url)
  const limit = parseInt(searchParams.get('limit') || '100')
  const action = searchParams.get('action')
  const where: any = {}
  if (action) where.action = action
  if (auth.session.role !== 'SUPER_ADMIN') {
    // Cell admins can see audit logs for their cell only — but we don't filter strictly here
  }
  const logs = await db.auditLog.findMany({
    where,
    include: { actor: { select: { id: true, name: true, email: true } } },
    orderBy: { createdAt: 'desc' },
    take: limit,
  })
  return NextResponse.json({ logs })
}

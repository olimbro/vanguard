import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const where: any = {}
  if (auth.session.role !== 'SUPER_ADMIN') where.cellId = auth.cellId
  const announcements = await db.announcement.findMany({
    where,
    include: { author: { select: { id: true, name: true } }, cell: { select: { id: true, name: true } } },
    orderBy: [{ isPinned: 'desc' }, { publishedAt: 'desc' }],
    take: 50,
  })
  return NextResponse.json({ announcements })
}

export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const body = await req.json()
  const { title, body: text, category, priority, isPinned, cellId, eventId } = body
  if (!title || !text) return NextResponse.json({ error: 'title and body required' }, { status: 400 })
  const announcement = await db.announcement.create({
    data: {
      title,
      body: text,
      category: category || 'CELL',
      priority: priority || 'NORMAL',
      isPinned: !!isPinned,
      cellId: cellId || auth.cellId,
      eventId,
      authorId: auth.session.userId,
    },
  })
  // Notify all members of the cell
  const members = await db.member.findMany({ where: { cellId: cellId || auth.cellId }, select: { userId: true } })
  for (const m of members) {
    if (m.userId) {
      await db.notification.create({
        data: {
          userId: m.userId,
          type: 'ANNOUNCEMENT',
          title,
          body: text.slice(0, 200),
          data: JSON.stringify({ announcementId: announcement.id }),
        },
      })
    }
  }
  await audit({ actorId: auth.session.userId, action: 'CREATE', objectType: 'Announcement', objectId: announcement.id, newValue: body })
  return NextResponse.json({ announcement }, { status: 201 })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { id } = await params
  await db.announcement.delete({ where: { id } })
  await audit({ actorId: auth.session.userId, action: 'DELETE', objectType: 'Announcement', objectId: id })
  return NextResponse.json({ ok: true })
}

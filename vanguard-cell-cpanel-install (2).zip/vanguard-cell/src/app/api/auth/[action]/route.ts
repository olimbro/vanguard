import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createSession, destroySession, getSessionFromCookie, hashPassword, verifyPassword, SESSION_COOKIE } from '@/lib/auth'
import { audit } from '@/lib/audit'

export async function POST(req: NextRequest, { params }: { params: Promise<{ action: string }> }) {
  const { action } = await params
  const body = await req.json().catch(() => ({}))

  if (action === 'login') {
    const { email, password } = body
    if (!email || !password) return NextResponse.json({ error: 'Email and password are required' }, { status: 400 })
    const user = await db.user.findUnique({ where: { email: String(email).toLowerCase() } })
    if (!user) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
    if (user.status !== 'ACTIVE') return NextResponse.json({ error: 'Account is not active' }, { status: 403 })
    const ok = await verifyPassword(password, user.passwordHash)
    if (!ok) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
    await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } })
    const token = await createSession({ userId: user.id, email: user.email, name: user.name, role: user.role, status: user.status })
    await audit({ actorId: user.id, action: 'LOGIN', objectType: 'User', objectId: user.id })
    const res = NextResponse.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role } })
    res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 7 * 24 * 3600 })
    return res
  }

  if (action === 'register') {
    const { email, password, name, phone } = body
    if (!email || !password || !name) return NextResponse.json({ error: 'Email, password and name are required' }, { status: 400 })
    const existing = await db.user.findUnique({ where: { email: String(email).toLowerCase() } })
    if (existing) return NextResponse.json({ error: 'Email already registered' }, { status: 409 })
    const passwordHash = await hashPassword(password)
    // SECURITY: role is NEVER accepted from the client. All new sign-ups are
    // MEMBER by default. Only a Super Admin can promote a user via the
    // User Management screen.
    const user = await db.user.create({
      data: {
        email: String(email).toLowerCase(),
        passwordHash,
        name,
        phone,
        role: 'MEMBER',
        status: 'ACTIVE',
        emailVerifiedAt: new Date(),
      },
    })
    // Auto-attach the new member to the first cell (single-cell deployment).
    // In a multi-cell deployment, the admin would assign the cell manually.
    const firstCell = await db.cell.findFirst({ orderBy: { createdAt: 'asc' } })
    if (firstCell) {
      await db.member.create({
        data: {
          userId: user.id,
          cellId: firstCell.id,
          fullName: name,
          preferredName: name.split(' ')[0],
          email: user.email,
          phone,
          status: 'NEW_MEMBER',
          dateJoinedCell: new Date(),
        },
      })
    }
    const token = await createSession({ userId: user.id, email: user.email, name: user.name, role: user.role, status: user.status })
    await audit({ actorId: user.id, action: 'REGISTER', objectType: 'User', objectId: user.id })
    const res = NextResponse.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role } })
    res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 7 * 24 * 3600 })
    return res
  }

  if (action === 'logout') {
    const session = await getSessionFromCookie()
    if (session) {
      await destroySession(req.cookies.get(SESSION_COOKIE)?.value)
      await audit({ actorId: session.userId, action: 'LOGOUT', objectType: 'User', objectId: session.userId })
    }
    const res = NextResponse.json({ ok: true })
    res.cookies.delete(SESSION_COOKIE)
    return res
  }

  if (action === 'forgot-password') {
    return NextResponse.json({ ok: true, message: 'If that email exists, a reset link has been sent.' })
  }

  return NextResponse.json({ error: 'Unknown auth action' }, { status: 404 })
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ action: string }> }) {
  const { action } = await params
  if (action === 'me') {
    const session = await getSessionFromCookie()
    if (!session) return NextResponse.json({ user: null })
    const user = await db.user.findUnique({
      where: { id: session.userId },
      include: { member: { include: { cell: true, currentRank: true, assignedWorker: true } } },
    })
    if (!user) return NextResponse.json({ user: null })
    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        status: user.status,
        phone: user.phone,
        preferredName: user.preferredName,
        member: user.member ? {
          id: user.member.id,
          cellId: user.member.cellId,
          cellName: user.member.cell?.name,
          fullName: user.member.fullName,
          status: user.member.status,
          points: user.member.currentPoints,
          streak: user.member.currentStreak,
          longestStreak: user.member.longestStreak,
          attendancePct: user.member.attendancePercentage,
          engagementScore: user.member.engagementScore,
          rank: user.member.currentRank ? { id: user.member.currentRank.id, name: user.member.currentRank.name, level: user.member.currentRank.level, icon: user.member.currentRank.icon, color: user.member.currentRank.color } : null,
        } : null,
      },
    })
  }
  return NextResponse.json({ error: 'Unknown auth action' }, { status: 404 })
}

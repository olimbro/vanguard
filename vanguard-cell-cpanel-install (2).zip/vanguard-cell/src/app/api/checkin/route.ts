import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'
import { audit } from '@/lib/audit'
import { randomUUID } from 'crypto'

// POST /api/checkin — self check-in via QR or PIN
// body: { method: 'QR'|'PIN', token?: string (for QR), pin?: string (for PIN), eventId?: string (for PIN), location?: {lat,lng} }
export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!auth.member) return NextResponse.json({ error: 'Member profile required' }, { status: 400 })
  const body = await req.json()
  const { method, token, pin, eventId, location } = body
  if (!method || !['QR', 'PIN'].includes(method)) {
    return NextResponse.json({ error: 'Invalid method' }, { status: 400 })
  }

  let event: any = null
  if (method === 'QR') {
    if (!token) return NextResponse.json({ error: 'Token required' }, { status: 400 })
    // Token format: EVENTID:HMAC (simplified — for production, use signed JWT)
    // For demo, we accept the raw event ID encoded in the QR.
    // Look up the event by the decoded token.
    const decoded = Buffer.from(String(token), 'base64').toString('utf8')
    const eventIdFromToken = decoded.split(':')[0]
    event = await db.event.findUnique({ where: { id: eventIdFromToken } })
    if (!event) return NextResponse.json({ error: 'Invalid QR token' }, { status: 400 })
  } else if (method === 'PIN') {
    if (!pin || !eventId) return NextResponse.json({ error: 'PIN and event required' }, { status: 400 })
    event = await db.event.findUnique({ where: { id: eventId } })
    if (!event) return NextResponse.json({ error: 'Event not found' }, { status: 404 })
    // PIN is stored as event.enablePin = true and we generate a 4-digit PIN based on event ID hash
    // For simplicity, the PIN equals last 4 digits of a hash of the event ID
    const expectedPin = String(
      Math.abs(
        event.id.split('').reduce((acc: number, c: string) => (acc * 31 + c.charCodeAt(0)) | 0, 7)
      ) % 10000
    ).padStart(4, '0')
    if (pin !== expectedPin) return NextResponse.json({ error: 'Invalid PIN' }, { status: 400 })
  }

  // Check event is happening today or now
  const now = new Date()
  const eventStart = new Date(event.startDate)
  const dayDiff = Math.abs(now.getTime() - eventStart.getTime()) / (1000 * 60 * 60 * 24)
  if (dayDiff > 1) return NextResponse.json({ error: 'Event is not active for check-in' }, { status: 400 })

  // Geolocation check if enabled
  let locationVerified = false
  if (event.enableGeolocation && event.geoLat && event.geoLng) {
    if (!location) return NextResponse.json({ error: 'Location required for this event' }, { status: 400 })
    const dist = haversine(location.lat, location.lng, event.geoLat, event.geoLng)
    if (dist > (event.geoRadiusMeters || 100)) {
      return NextResponse.json({ error: `You are too far from the event venue (${Math.round(dist)}m away).` }, { status: 400 })
    }
    locationVerified = true
  }

  // Check for duplicate
  const existing = await db.attendanceRecord.findUnique({
    where: { eventId_memberId: { eventId: event.id, memberId: auth.member.id } },
  })
  if (existing && existing.status !== 'ABSENT') {
    return NextResponse.json({ error: 'You have already checked in', duplicate: true, record: existing }, { status: 409 })
  }

  // Determine status: PRESENT or LATE (15 min after start)
  const isLate = now.getTime() > eventStart.getTime() + 15 * 60 * 1000
  const status = isLate ? 'LATE' : 'PRESENT'

  const record = await db.attendanceRecord.upsert({
    where: { eventId_memberId: { eventId: event.id, memberId: auth.member.id } },
    create: {
      eventId: event.id,
      memberId: auth.member.id,
      userId: auth.session.userId,
      status,
      method,
      checkInTime: now,
      locationVerified,
      verificationStatus: 'VERIFIED',
      recordedById: auth.session.userId,
      syncStatus: 'SYNCED',
      deviceIdentifier: body.deviceIdentifier || null,
    },
    update: {
      status,
      method,
      checkInTime: now,
      locationVerified,
      recordedById: auth.session.userId,
    },
    include: { event: true },
  })

  // Award points
  const { awardPoints, recalculateStreak, evaluateRank, evaluateBadges, recalculateAttendancePercentage, recalculateEngagementScore, evaluateChallenges, getPointRules } = await import('@/lib/gamification')
  const rules = await getPointRules()
  await awardPoints(auth.member.id, rules.ATTEND_CELL, 'ATTEND', { eventId: event.id, userId: auth.session.userId, description: `Self check-in: ${event.name}` })
  if (status === 'PRESENT') {
    await awardPoints(auth.member.id, rules.ON_TIME, 'ON_TIME', { eventId: event.id, userId: auth.session.userId, description: 'On-time bonus' })
  }
  await db.member.update({ where: { id: auth.member.id }, data: { lastAttendanceAt: now } })
  await recalculateStreak(auth.member.id)
  await recalculateAttendancePercentage(auth.member.id)
  await recalculateEngagementScore(auth.member.id)
  await evaluateRank(auth.member.id)
  await evaluateBadges(auth.member.id)
  await evaluateChallenges(auth.member.id)

  // Streak bonus
  const member = await db.member.findUnique({ where: { id: auth.member.id } })
  if (member) {
    if (member.currentStreak === 4) await awardPoints(auth.member.id, rules.STREAK_4, 'STREAK_4', { description: '4-week streak!' })
    else if (member.currentStreak === 8) await awardPoints(auth.member.id, rules.STREAK_8, 'STREAK_8', { description: '8-week streak!' })
  }

  await audit({ actorId: auth.session.userId, action: 'CREATE', objectType: 'AttendanceRecord', objectId: record.id, newValue: { eventId: event.id, memberId: auth.member.id, method, status } })

  await db.notification.create({
    data: {
      userId: auth.session.userId,
      type: 'CHECK_IN',
      title: `Check-in confirmed: ${event.name}`,
      body: `Status: ${status}. +${rules.ATTEND_CELL + (status === 'PRESENT' ? rules.ON_TIME : 0)} points.`,
    },
  })

  return NextResponse.json({ record, status, points: rules.ATTEND_CELL + (status === 'PRESENT' ? rules.ON_TIME : 0) })
}

function haversine(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLng/2)**2
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
}

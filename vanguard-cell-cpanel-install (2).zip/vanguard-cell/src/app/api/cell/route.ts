import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'

// Returns the current user's cell info + branding
export async function GET() {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (auth.session.role === 'SUPER_ADMIN') {
    // Super admin can see all cells
    const cells = await db.cell.findMany({ include: { church: true, zone: true, _count: { select: { members: true, events: true } } } })
    return NextResponse.json({ cells, currentCellId: null })
  }
  if (!auth.cellId) return NextResponse.json({ cell: null })
  const cell = await db.cell.findUnique({
    where: { id: auth.cellId },
    include: { church: true, zone: true, leader: { select: { id: true, name: true } }, _count: { select: { members: true, events: true } } },
  })
  return NextResponse.json({ cell, currentCellId: auth.cellId })
}

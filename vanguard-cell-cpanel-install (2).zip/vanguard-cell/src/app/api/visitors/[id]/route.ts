import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

// Convert visitor to member (section 27)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { id } = await params
  const visitor = await db.visitor.findUnique({ where: { id } })
  if (!visitor) return NextResponse.json({ error: 'Visitor not found' }, { status: 404 })
  const user = await db.user.create({
    data: {
      email: visitor.email || `visitor-${visitor.id}@vanguard.test`,
      passwordHash: 'CONVERT-' + Math.random().toString(36).slice(2),
      name: visitor.fullName,
      phone: visitor.phone || undefined,
      role: 'MEMBER',
      status: 'ACTIVE',
      emailVerifiedAt: new Date(),
    },
  })
  const member = await db.member.create({
    data: {
      userId: user.id,
      cellId: visitor.cellId,
      fullName: visitor.fullName,
      email: visitor.email,
      phone: visitor.phone,
      gender: visitor.gender,
      status: 'NEW_MEMBER',
      dateJoinedCell: new Date(),
      dateConverted: new Date(),
    },
  })
  await db.visitor.update({ where: { id }, data: { memberId: member.id, convertedAt: new Date(), followUpStatus: 'CLOSED' } })
  await audit({ actorId: auth.session.userId, action: 'CONVERT', objectType: 'Visitor', objectId: id, newValue: { memberId: member.id } })
  return NextResponse.json({ member, visitor })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const where: any = {}
  if (auth.session.role !== 'SUPER_ADMIN') where.cellId = auth.cellId
  const visitors = await db.visitor.findMany({
    where,
    include: {
      member: { select: { id: true, fullName: true } },
      invitedByMember: { select: { id: true, fullName: true } },
    },
    orderBy: { createdAt: 'desc' },
  })
  return NextResponse.json({ visitors })
}

export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const body = await req.json()
  const { fullName, phone, email, gender, invitedByMemberId, firstEventId, followUpStatus, notes, cellId } = body
  if (!fullName || !cellId) return NextResponse.json({ error: 'fullName and cellId required' }, { status: 400 })
  const visitor = await db.visitor.create({
    data: { cellId, fullName, phone, email, gender, invitedByMemberId, firstEventId, followUpStatus: followUpStatus || 'NEW', notes },
  })
  await audit({ actorId: auth.session.userId, action: 'CREATE', objectType: 'Visitor', objectId: visitor.id, newValue: body })
  return NextResponse.json({ visitor }, { status: 201 })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'
import { audit } from '@/lib/audit'
import { randomUUID } from 'crypto'

// POST /api/registrations — register for an event
export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const body = await req.json()
  const { eventId, fieldValues = {}, guestName, guestEmail, guestPhone, invitedByMemberId, numGuests, dietaryInfo, specialNeeds } = body
  if (!eventId) return NextResponse.json({ error: 'eventId required' }, { status: 400 })
  const event = await db.event.findUnique({
    where: { id: eventId },
    include: { registrationFields: true, cell: true },
  })
  if (!event) return NextResponse.json({ error: 'Event not found' }, { status: 404 })
  if (!event.registrationRequired) return NextResponse.json({ error: 'This event does not require registration' }, { status: 400 })
  if (event.registrationDeadline && new Date() > event.registrationDeadline) {
    return NextResponse.json({ error: 'Registration deadline has passed' }, { status: 400 })
  }
  if (event.capacity) {
    const count = await db.eventRegistration.count({ where: { eventId, status: { in: ['REGISTERED', 'CONFIRMED'] } } })
    if (count >= event.capacity) return NextResponse.json({ error: 'Event is full' }, { status: 400 })
  }
  // Check duplicate (same user already registered)
  if (auth.member) {
    const existing = await db.eventRegistration.findFirst({
      where: { eventId, userId: auth.session.userId, status: { in: ['REGISTERED', 'CONFIRMED'] } },
    })
    if (existing) return NextResponse.json({ error: 'You are already registered', registration: existing }, { status: 409 })
  }

  const registrationNumber = `VP-${String(Math.floor(Math.random() * 100000)).padStart(5, '0')}`
  const qrToken = randomUUID()
  const registration = await db.eventRegistration.create({
    data: {
      eventId,
      userId: auth.session.userId,
      registrationNumber,
      qrToken,
      guestName,
      guestEmail,
      guestPhone,
      invitedByMemberId,
      numGuests: numGuests || 1,
      dietaryInfo,
      specialNeeds,
      formData: JSON.stringify(fieldValues),
      status: 'CONFIRMED',
    },
    include: { event: true },
  })

  // Save field values
  for (const field of event.registrationFields) {
    const value = fieldValues[field.fieldKey]
    if (value !== undefined) {
      await db.registrationFieldValue.create({
        data: {
          registrationId: registration.id,
          fieldId: field.id,
          value: String(value),
        },
      })
    }
  }

  // Award points
  if (auth.member) {
    const { awardPoints } = await import('@/lib/gamification')
    const rules = await (await import('@/lib/gamification')).getPointRules()
    await awardPoints(auth.member.id, rules.REGISTER_EVENT, 'REGISTER', {
      eventId, userId: auth.session.userId, description: `Registered for ${event.name}`,
    })
    // If they invited a guest, award bonus
    if (invitedByMemberId) {
      await awardPoints(invitedByMemberId, rules.INVITE_GUEST, 'INVITE_GUEST', {
        eventId, description: `Invited a guest to ${event.name}`,
      })
    }
  }

  // Create notification
  await db.notification.create({
    data: {
      userId: auth.session.userId,
      type: 'REGISTRATION_CONFIRMED',
      title: 'Registration confirmed',
      body: `You are registered for ${event.name}. Registration #${registrationNumber}.`,
      data: JSON.stringify({ eventId, registrationId: registration.id }),
    },
  })

  await audit({ actorId: auth.session.userId, action: 'CREATE', objectType: 'EventRegistration', objectId: registration.id, newValue: body })
  return NextResponse.json({ registration }, { status: 201 })
}

// GET /api/registrations?eventId=...
export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { searchParams } = new URL(req.url)
  const eventId = searchParams.get('eventId')
  const my = searchParams.get('my') === 'true'
  const where: any = {}
  if (eventId) where.eventId = eventId
  if (my) where.userId = auth.session.userId
  if (eventId && auth.session.role !== 'SUPER_ADMIN') {
    // Members can only see their own; admins see all
    if (!['CELL_ADMIN', 'ASSISTANT', 'WORKER'].includes(auth.session.role)) {
      where.userId = auth.session.userId
    }
  }
  const registrations = await db.eventRegistration.findMany({
    where,
    include: {
      event: true,
      user: { select: { id: true, name: true, email: true } },
      values: { include: { field: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 500,
  })
  return NextResponse.json({ registrations })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

// GET visitor lookup by registration number or QR token
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { id } = await params
  // Try by ID, then by registration number, then by QR token
  let registration = await db.eventRegistration.findUnique({
    where: { id },
    include: { event: true, user: { select: { id: true, name: true, email: true } }, values: { include: { field: true } } },
  })
  if (!registration) {
    registration = await db.eventRegistration.findUnique({
      where: { registrationNumber: id },
      include: { event: true, user: { select: { id: true, name: true, email: true } }, values: { include: { field: true } } },
    })
  }
  if (!registration) {
    registration = await db.eventRegistration.findUnique({
      where: { qrToken: id },
      include: { event: true, user: { select: { id: true, name: true, email: true } }, values: { include: { field: true } } },
    })
  }
  if (!registration) return NextResponse.json({ error: 'Registration not found' }, { status: 404 })
  return NextResponse.json({ registration })
}

// PATCH - update status (e.g., check-in at the door)
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!['SUPER_ADMIN', 'CELL_ADMIN', 'ASSISTANT', 'WORKER'].includes(auth.session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const { id } = await params
  const body = await req.json()
  const { status, checkedInAt } = body
  const before = await db.eventRegistration.findUnique({ where: { id } })
  if (!before) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  const updated = await db.eventRegistration.update({
    where: { id },
    data: {
      status: status || undefined,
      checkedInAt: checkedInAt ? new Date(checkedInAt) : status === 'ATTENDED' ? new Date() : undefined,
    },
  })
  // If marked ATTENDED, create attendance record too
  if (status === 'ATTENDED' && before.userId) {
    const member = await db.member.findUnique({ where: { userId: before.userId } })
    if (member) {
      const existing = await db.attendanceRecord.findUnique({
        where: { eventId_memberId: { eventId: before.eventId, memberId: member.id } },
      })
      if (!existing) {
        await db.attendanceRecord.create({
          data: {
            eventId: before.eventId,
            memberId: member.id,
            userId: before.userId,
            status: 'PRESENT',
            method: 'QR',
            checkInTime: new Date(),
            verificationStatus: 'VERIFIED',
            recordedById: auth.session.userId,
            syncStatus: 'SYNCED',
          },
        })
        const { awardPoints, recalculateStreak, evaluateRank, evaluateBadges, recalculateAttendancePercentage, recalculateEngagementScore, getPointRules } = await import('@/lib/gamification')
        const rules = await getPointRules()
        await awardPoints(member.id, rules.ATTEND_REGISTERED, 'ATTEND_REGISTERED', {
          eventId: before.eventId, userId: before.userId, description: 'Attended registered event',
        })
        await recalculateStreak(member.id)
        await recalculateAttendancePercentage(member.id)
        await recalculateEngagementScore(member.id)
        await evaluateRank(member.id)
        await evaluateBadges(member.id)
      }
    }
  }
  await audit({ actorId: auth.session.userId, action: 'UPDATE', objectType: 'EventRegistration', objectId: id, oldValue: before, newValue: body })
  return NextResponse.json({ registration: updated })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { id } = await params
  const before = await db.eventRegistration.findUnique({ where: { id } })
  if (!before) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  // Only the owner or admin can cancel
  if (before.userId !== auth.session.userId && !canManage(auth.session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const updated = await db.eventRegistration.update({ where: { id }, data: { status: 'CANCELLED' } })
  await audit({ actorId: auth.session.userId, action: 'CANCEL', objectType: 'EventRegistration', objectId: id, oldValue: before })
  return NextResponse.json({ registration: updated })
}

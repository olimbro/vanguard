import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

// POST /api/sync — bulk sync offline attendance records
// body: { records: [{ offlineUuid, eventId, memberId, status, method, checkInTime, deviceIdentifier, notes }] }
export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const body = await req.json()
  const { records } = body
  if (!Array.isArray(records)) return NextResponse.json({ error: 'records array required' }, { status: 400 })

  const results: any[] = []
  const gamification = await import('@/lib/gamification')

  for (const rec of records) {
    try {
      // Check for duplicate by offlineUuid
      const existing = await db.attendanceRecord.findFirst({ where: { offlineUuid: rec.offlineUuid } })
      if (existing) {
        results.push({ offlineUuid: rec.offlineUuid, status: 'duplicate', record: existing })
        continue
      }
      // Also check by eventId+memberId
      const existingPair = await db.attendanceRecord.findUnique({
        where: { eventId_memberId: { eventId: rec.eventId, memberId: rec.memberId } },
      })
      if (existingPair && existingPair.status !== 'ABSENT') {
        results.push({ offlineUuid: rec.offlineUuid, status: 'duplicate', record: existingPair })
        continue
      }

      // Store the sync record
      await db.syncRecord.create({
        data: {
          userId: auth.session.userId,
          offlineUuid: rec.offlineUuid,
          eventId: rec.eventId,
          memberId: rec.memberId,
          status: 'SYNCED',
          payload: JSON.stringify(rec),
          syncedAt: new Date(),
        },
      })

      // Apply the attendance
      const record = await db.attendanceRecord.upsert({
        where: { eventId_memberId: { eventId: rec.eventId, memberId: rec.memberId } },
        create: {
          eventId: rec.eventId,
          memberId: rec.memberId,
          userId: auth.session.userId,
          status: rec.status || 'PRESENT',
          method: rec.method || 'OFFLINE',
          checkInTime: rec.checkInTime ? new Date(rec.checkInTime) : new Date(),
          deviceIdentifier: rec.deviceIdentifier,
          verificationStatus: 'VERIFIED',
          recordedById: auth.session.userId,
          syncStatus: 'SYNCED',
          offlineUuid: rec.offlineUuid,
          notes: rec.notes,
        },
        update: {
          status: rec.status || 'PRESENT',
          method: rec.method || 'OFFLINE',
          checkInTime: rec.checkInTime ? new Date(rec.checkInTime) : undefined,
          syncStatus: 'SYNCED',
          offlineUuid: rec.offlineUuid,
        },
      })

      // Award points if PRESENT or LATE
      if (record.status === 'PRESENT' || record.status === 'LATE') {
        const rules = await gamification.getPointRules()
        await gamification.awardPoints(rec.memberId, rules.ATTEND_CELL, 'ATTEND', {
          eventId: rec.eventId, userId: auth.session.userId, description: 'Synced offline attendance',
        })
        if (record.status === 'PRESENT') {
          const event = await db.event.findUnique({ where: { id: rec.eventId } })
          if (event && record.checkInTime && record.checkInTime <= event.startDate) {
            await gamification.awardPoints(rec.memberId, rules.ON_TIME, 'ON_TIME', {
              eventId: rec.eventId, userId: auth.session.userId, description: 'On-time bonus',
            })
          }
        }
      }

      // Recalculate
      await gamification.recalculateStreak(rec.memberId)
      await gamification.recalculateAttendancePercentage(rec.memberId)
      await gamification.recalculateEngagementScore(rec.memberId)
      await gamification.evaluateRank(rec.memberId)
      await gamification.evaluateBadges(rec.memberId)
      await gamification.evaluateChallenges(rec.memberId)

      results.push({ offlineUuid: rec.offlineUuid, status: 'synced', record })
    } catch (e: any) {
      results.push({ offlineUuid: rec.offlineUuid, status: 'error', error: e.message })
    }
  }

  await audit({ actorId: auth.session.userId, action: 'SYNC', objectType: 'AttendanceRecord', newValue: { count: records.length } })
  return NextResponse.json({ results })
}

// GET pending sync count
export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const pending = await db.syncRecord.count({ where: { userId: auth.session.userId, status: 'PENDING' } })
  return NextResponse.json({ pending })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'
import { getEngagementHealth } from '@/lib/gamification'

export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const isAdmin = canManage(auth.session.role) || auth.session.role === 'WORKER'

  if (isAdmin) {
    return adminDashboard(auth)
  }
  return memberDashboard(auth)
}

async function adminDashboard(auth: any) {
  const cellId = auth.cellId
  const cellFilter = cellId ? { cellId } : {}
  const inactivitySetting = await db.setting.findUnique({ where: { key: 'attendance.inactivity_threshold_weeks' } })
  const inactivityWeeks = inactivitySetting ? JSON.parse(inactivitySetting.value) : 3
  const cutoff = new Date(Date.now() - inactivityWeeks * 7 * 24 * 3600 * 1000)

  const [totalMembers, activeMembers, visitors, newMembers, totalEvents, attendanceToday, attendanceThisWeek, attendanceThisMonth, needingFollowUp, registrationsPending, cell] = await Promise.all([
    db.member.count({ where: { ...cellFilter, status: { not: 'ARCHIVED' } } }),
    db.member.count({ where: { ...cellFilter, status: { in: ['ACTIVE_MEMBER', 'REGULAR_MEMBER', 'WORKER', 'CELL_LEADER'] } } }),
    db.visitor.count({ where: { cellId: cellId || undefined } }),
    db.member.count({ where: { ...cellFilter, status: 'NEW_MEMBER' } }),
    db.event.count({ where: cellFilter }),
    db.attendanceRecord.count({ where: { event: { ...cellFilter, startDate: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } } } }),
    db.attendanceRecord.count({ where: { event: { ...cellFilter, startDate: { gte: new Date(Date.now() - 7 * 24 * 3600 * 1000) } } } }),
    db.attendanceRecord.count({ where: { event: { ...cellFilter, startDate: { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) } } } }),
    db.member.count({ where: { ...cellFilter, OR: [{ lastAttendanceAt: { lt: cutoff } }, { lastAttendanceAt: null }] } }),
    db.eventRegistration.count({ where: { event: cellFilter, status: 'PENDING' } }),
    cellId ? db.cell.findUnique({ where: { id: cellId }, include: { church: true } }) : null,
  ])

  // Inactive members (last attendance > 3 weeks ago)
  const inactiveMembers = await db.member.count({
    where: { ...cellFilter, status: { notIn: ['ARCHIVED', 'CELL_LEADER'] }, lastAttendanceAt: { lt: cutoff } },
  })

  // Attendance trend (last 8 weeks)
  const eightWeeksAgo = new Date(Date.now() - 8 * 7 * 24 * 3600 * 1000)
  const attendanceRecords = await db.attendanceRecord.findMany({
    where: { event: { ...cellFilter, startDate: { gte: eightWeeksAgo } } },
    include: { event: true },
  })
  const byWeek: Record<string, { week: string; present: number; total: number }> = {}
  for (const r of attendanceRecords) {
    const ev = r.event
    if (!ev) continue
    const weekKey = getWeekKey(ev.startDate)
    if (!byWeek[weekKey]) byWeek[weekKey] = { week: weekKey, present: 0, total: 0 }
    byWeek[weekKey].total += 1
    if (r.status === 'PRESENT' || r.status === 'LATE') byWeek[weekKey].present += 1
  }
  const attendanceTrend = Object.values(byWeek).sort((a, b) => a.week.localeCompare(b.week))

  // Member growth (last 6 months)
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)
  const recentMembers = await db.member.findMany({
    where: { ...cellFilter, dateJoinedCell: { gte: sixMonthsAgo } },
    select: { dateJoinedCell: true },
  })
  const byMonth: Record<string, number> = {}
  for (const m of recentMembers) {
    const k = `${m.dateJoinedCell.getFullYear()}-${String(m.dateJoinedCell.getMonth() + 1).padStart(2, '0')}`
    byMonth[k] = (byMonth[k] || 0) + 1
  }
  const memberGrowth = Object.entries(byMonth).map(([month, count]) => ({ month, count })).sort((a, b) => a.month.localeCompare(b.month))

  // Top members by points
  const topMembers = await db.member.findMany({
    where: { ...cellFilter, status: { not: 'ARCHIVED' } },
    orderBy: { currentPoints: 'desc' },
    take: 5,
    include: { currentRank: true, user: { select: { id: true, name: true } } },
  })

  // Members needing follow-up list
  const followUpList = await db.member.findMany({
    where: { ...cellFilter, status: { not: 'ARCHIVED' }, OR: [{ lastAttendanceAt: { lt: cutoff } }, { lastAttendanceAt: null }] },
    include: { currentRank: true, assignedWorker: { select: { id: true, name: true } } },
    take: 10,
    orderBy: { lastAttendanceAt: 'asc' },
  })

  // Recent activity (last 20 attendance records)
  const recentAttendance = await db.attendanceRecord.findMany({
    where: { event: cellFilter },
    include: { member: { select: { id: true, fullName: true } }, event: { select: { id: true, name: true } } },
    orderBy: { createdAt: 'desc' },
    take: 10,
  })

  // Upcoming events
  const upcomingEvents = await db.event.findMany({
    where: { ...cellFilter, startDate: { gte: new Date() }, status: { in: ['PUBLISHED', 'REGISTRATION_OPEN'] } },
    orderBy: { startDate: 'asc' },
    take: 5,
    include: { _count: { select: { registrations: true } } },
  })

  // Pinned announcements
  const announcements = await db.announcement.findMany({
    where: { cellId: cellId || undefined },
    orderBy: [{ isPinned: 'desc' }, { publishedAt: 'desc' }],
    take: 5,
    include: { author: { select: { id: true, name: true } } },
  })

  // Calculate averages
  const avgAttendancePct = totalMembers > 0
    ? (await db.member.aggregate({ where: { ...cellFilter, status: { not: 'ARCHIVED' } }, _avg: { attendancePercentage: true } }))._avg.attendancePercentage || 0
    : 0
  const avgEngagement = totalMembers > 0
    ? (await db.member.aggregate({ where: { ...cellFilter, status: { not: 'ARCHIVED' } }, _avg: { engagementScore: true } }))._avg.engagementScore || 0
    : 0

  // Dashboard alerts (section 64)
  const alerts = [
    needingFollowUp > 0 ? { color: 'red', icon: '🔴', text: `${needingFollowUp} member${needingFollowUp === 1 ? '' : 's'} need follow-up`, action: 'follow-up' } : null,
    registrationsPending > 0 ? { color: 'orange', icon: '🟠', text: `${registrationsPending} registration${registrationsPending === 1 ? '' : 's'} pending`, action: 'registrations' } : null,
    inactiveMembers > 0 ? { color: 'yellow', icon: '🟡', text: `${inactiveMembers} inactive member${inactiveMembers === 1 ? '' : 's'}`, action: 'inactive' } : null,
    visitors > 0 ? { color: 'blue', icon: '🔵', text: `${visitors} visitor${visitors === 1 ? '' : 's'} to follow up`, action: 'visitors' } : null,
  ].filter(Boolean)

  return NextResponse.json({
    type: 'admin',
    cell: cell ? { id: cell.id, name: cell.name, churchName: cell.church?.name, venue: cell.venue, meetingDay: cell.meetingDay, meetingTime: cell.meetingTime } : null,
    cards: {
      totalMembers, activeMembers, visitors, newMembers, totalEvents,
      attendanceToday, attendanceThisWeek, attendanceThisMonth,
      needingFollowUp, registrationsPending, inactiveMembers,
      avgAttendancePct: Math.round(avgAttendancePct * 10) / 10,
      avgEngagement: Math.round(avgEngagement * 10) / 10,
    },
    attendanceTrend,
    memberGrowth,
    topMembers: topMembers.map((m, i) => ({
      rank: i + 1, id: m.id, name: m.fullName,
      points: m.currentPoints, streak: m.currentStreak,
      rankName: m.currentRank?.name || 'Newcomer', rankIcon: m.currentRank?.icon || '🌱',
    })),
    followUpList: followUpList.map((m) => ({
      id: m.id, name: m.fullName, lastAttendance: m.lastAttendanceAt,
      engagementHealth: getEngagementHealth(m.engagementScore),
      assignedWorker: m.assignedWorker?.name,
    })),
    recentAttendance: recentAttendance.map((r) => ({
      id: r.id, member: r.member?.fullName, event: r.event?.name,
      status: r.status, method: r.method, when: r.createdAt,
    })),
    upcomingEvents: upcomingEvents.map((e) => ({
      id: e.id, name: e.name, startDate: e.startDate, venue: e.venue,
      registrationRequired: e.registrationRequired,
      registrations: e._count.registrations,
    })),
    announcements,
    alerts,
  })
}

async function memberDashboard(auth: any) {
  if (!auth.member) return NextResponse.json({ type: 'member', error: 'No member profile' })
  const memberId = auth.member.id
  const cellId = auth.member.cellId

  // My attendance stats
  const myAttendance = await db.attendanceRecord.findMany({
    where: { memberId },
    include: { event: true },
    orderBy: { createdAt: 'desc' },
  })
  const present = myAttendance.filter((r) => r.status === 'PRESENT' || r.status === 'LATE').length
  const attendancePct = myAttendance.length > 0 ? (present / myAttendance.length) * 100 : 0

  // Upcoming events for my cell
  const upcomingEvents = await db.event.findMany({
    where: { cellId, startDate: { gte: new Date() }, status: { in: ['PUBLISHED', 'REGISTRATION_OPEN'] } },
    orderBy: { startDate: 'asc' },
    take: 3,
    include: { _count: { select: { registrations: true } } },
  })

  // My badges
  const myBadges = await db.userBadge.findMany({
    where: { memberId },
    include: { badge: true },
    orderBy: { awardedAt: 'desc' },
  })

  // My recent point transactions
  const recentPoints = await db.pointTransaction.findMany({
    where: { memberId },
    orderBy: { createdAt: 'desc' },
    take: 10,
  })

  // My registrations
  const myRegistrations = await db.eventRegistration.findMany({
    where: { userId: auth.session.userId },
    include: { event: true },
    orderBy: { createdAt: 'desc' },
    take: 5,
  })

  // Announcements
  const announcements = await db.announcement.findMany({
    where: { cellId },
    orderBy: [{ isPinned: 'desc' }, { publishedAt: 'desc' }],
    take: 5,
    include: { author: { select: { id: true, name: true } } },
  })

  // Available challenges
  const challenges = await db.challenge.findMany({
    where: { isActive: true },
    include: { progress: { where: { memberId } } },
  })

  // Next meeting (most recent upcoming weekly cell meeting)
  const nextMeeting = upcomingEvents[0] || null

  return NextResponse.json({
    type: 'member',
    member: {
      id: auth.member.id,
      name: auth.member.fullName,
      preferredName: auth.member.preferredName,
      cellName: auth.member.cellName,
      status: auth.member.status,
      points: auth.member.points,
      streak: auth.member.streak,
      longestStreak: auth.member.longestStreak,
      attendancePct: auth.member.attendancePct,
      engagementScore: auth.member.engagementScore,
      rank: auth.member.rank,
    },
    cards: {
      totalEvents: myAttendance.length,
      eventsAttended: present,
      attendancePct: Math.round(attendancePct * 10) / 10,
      currentStreak: auth.member.streak,
      longestStreak: auth.member.longestStreak,
      points: auth.member.points,
      badges: myBadges.length,
    },
    nextMeeting: nextMeeting ? {
      id: nextMeeting.id, name: nextMeeting.name,
      startDate: nextMeeting.startDate, venue: nextMeeting.venue,
      startTime: nextMeeting.startTime, endTime: nextMeeting.endTime,
    } : null,
    upcomingEvents: upcomingEvents.map((e) => ({
      id: e.id, name: e.name, startDate: e.startDate, venue: e.venue,
      registrationRequired: e.registrationRequired,
      registered: myRegistrations.some((r) => r.eventId === e.id),
    })),
    myBadges: myBadges.map((b) => ({
      id: b.badge.id, name: b.badge.name, icon: b.badge.icon,
      color: b.badge.color, description: b.badge.description,
      awardedAt: b.awardedAt,
    })),
    recentPoints: recentPoints.map((p) => ({
      id: p.id, points: p.points, reason: p.reason, description: p.description, when: p.createdAt,
    })),
    myRegistrations: myRegistrations.map((r) => ({
      id: r.id, registrationNumber: r.registrationNumber,
      status: r.status, eventName: r.event?.name,
      eventDate: r.event?.startDate,
    })),
    announcements: announcements.map((a) => ({
      id: a.id, title: a.title, body: a.body,
      author: a.author?.name, publishedAt: a.publishedAt,
      isPinned: a.isPinned, category: a.category, priority: a.priority,
    })),
    challenges: challenges.map((c) => ({
      id: c.id, name: c.name, description: c.description,
      goalType: c.goalType, goalValue: c.goalValue,
      pointsReward: c.pointsReward,
      progress: c.progress[0]?.progress || 0,
      completed: c.progress[0]?.completed || false,
    })),
    recentAttendance: myAttendance.slice(0, 5).map((r) => ({
      id: r.id, event: r.event?.name, status: r.status,
      method: r.method, when: r.event?.startDate,
    })),
  })
}

function getWeekKey(d: Date): string {
  const date = new Date(d)
  const day = date.getDay()
  const diff = (day === 0 ? 6 : day - 1)
  date.setDate(date.getDate() - diff)
  return date.toISOString().split('T')[0]
}

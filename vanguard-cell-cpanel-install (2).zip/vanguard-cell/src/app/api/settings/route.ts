import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'
import { canManage } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

export async function GET() {
  const settings = await db.setting.findMany()
  const map: Record<string, any> = {}
  for (const s of settings) {
    try { map[s.key] = JSON.parse(s.value) } catch { map[s.key] = s.value }
  }
  return NextResponse.json({ settings: map })
}

export async function PATCH(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const body = await req.json()
  const { key, value, category } = body
  if (!key) return NextResponse.json({ error: 'key required' }, { status: 400 })
  const updated = await db.setting.upsert({
    where: { key },
    create: { key, value: JSON.stringify(value), category: category || 'GENERAL', updatedById: auth.session.userId },
    update: { value: JSON.stringify(value), category: category || 'GENERAL', updatedById: auth.session.userId },
  })
  await audit({ actorId: auth.session.userId, action: 'UPDATE', objectType: 'Setting', objectId: key, newValue: value })
  return NextResponse.json({ setting: updated })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

// GET conversations + messages for the current user
export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { searchParams } = new URL(req.url)
  const conversationId = searchParams.get('conversationId')
  
  if (conversationId) {
    // Return messages of a specific conversation
    const messages = await db.message.findMany({
      where: { conversationId, isDeleted: false },
      include: { sender: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'asc' },
      take: 200,
    })
    return NextResponse.json({ messages })
  }
  
  // Return all conversations for this user
  const conversations = await db.conversation.findMany({
    where: { participants: { some: { userId: auth.session.userId } } },
    include: {
      cell: { select: { id: true, name: true } },
      participants: { include: { user: { select: { id: true, name: true } } } },
      messages: { orderBy: { createdAt: 'desc' }, take: 1, include: { sender: { select: { id: true, name: true } } } },
    },
    orderBy: { updatedAt: 'desc' },
  })
  return NextResponse.json({ conversations })
}

// POST a new message
export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const body = await req.json()
  const { conversationId, body: text, messageType, attachmentUrl, replyToId } = body
  if (!conversationId || !text) return NextResponse.json({ error: 'conversationId and body required' }, { status: 400 })
  // Verify participant
  const participant = await db.conversationParticipant.findUnique({
    where: { conversationId_userId: { conversationId, userId: auth.session.userId } },
  })
  if (!participant) return NextResponse.json({ error: 'Not a participant' }, { status: 403 })
  const message = await db.message.create({
    data: { conversationId, senderId: auth.session.userId, body: text, messageType: messageType || 'TEXT', attachmentUrl, replyToId },
    include: { sender: { select: { id: true, name: true } } },
  })
  await db.conversation.update({ where: { id: conversationId }, data: { updatedAt: new Date() } })
  // Notify other participants
  const others = await db.conversationParticipant.findMany({
    where: { conversationId, userId: { not: auth.session.userId } },
    select: { userId: true },
  })
  for (const p of others) {
    await db.notification.create({
      data: {
        userId: p.userId,
        type: 'MESSAGE',
        title: `New message from ${auth.session.name}`,
        body: text.slice(0, 200),
        data: JSON.stringify({ conversationId, messageId: message.id }),
      },
    })
  }
  return NextResponse.json({ message }, { status: 201 })
}

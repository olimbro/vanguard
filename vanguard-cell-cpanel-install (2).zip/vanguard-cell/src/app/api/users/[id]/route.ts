import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'
import { can } from '@/lib/auth'
import { audit } from '@/lib/audit'

// PATCH /api/users/[id] — change role and/or status (SUPER_ADMIN only)
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!can(auth.session.role, 'MANAGE_USERS')) {
    return NextResponse.json({ error: 'Forbidden — requires MANAGE_USERS permission' }, { status: 403 })
  }
  const { id } = await params
  const body = await req.json()
  const { role, status } = body
  const before = await db.user.findUnique({ where: { id }, select: { id: true, role: true, status: true, name: true, email: true } })
  if (!before) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  // Prevent demoting the last active super admin
  if (before.role === 'SUPER_ADMIN' && before.status === 'ACTIVE') {
    const willLoseSuperAdmin = (role && role !== 'SUPER_ADMIN') || (status && status !== 'ACTIVE')
    if (willLoseSuperAdmin) {
      const activeSuperAdmins = await db.user.count({ where: { role: 'SUPER_ADMIN', status: 'ACTIVE' } })
      if (activeSuperAdmins <= 1) {
        return NextResponse.json(
          { error: 'Cannot demote the last active Super Admin. Promote another user to Super Admin first.' },
          { status: 400 }
        )
      }
    }
  }

  // Prevent self-demotion (you can't remove your own super admin)
  if (id === auth.session.userId && role && role !== 'SUPER_ADMIN' && before.role === 'SUPER_ADMIN') {
    return NextResponse.json(
      { error: 'You cannot remove your own Super Admin role. Ask another Super Admin to do this.' },
      { status: 400 }
    )
  }

  const data: any = {}
  if (role) data.role = role
  if (status) data.status = status
  const updated = await db.user.update({ where: { id }, data, select: { id: true, email: true, name: true, role: true, status: true } })
  await audit({
    actorId: auth.session.userId,
    action: 'PERMISSION_CHANGE',
    objectType: 'User',
    objectId: id,
    oldValue: { role: before.role, status: before.status },
    newValue: { role: role || before.role, status: status || before.status },
  })
  return NextResponse.json({ user: updated })
}

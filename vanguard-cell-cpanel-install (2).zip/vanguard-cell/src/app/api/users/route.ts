import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'
import { can } from '@/lib/auth'
import { audit } from '@/lib/audit'

// GET /api/users — list all users (SUPER_ADMIN only)
export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!can(auth.session.role, 'MANAGE_USERS')) {
    return NextResponse.json({ error: 'Forbidden — requires MANAGE_USERS permission' }, { status: 403 })
  }
  const { searchParams } = new URL(req.url)
  const search = searchParams.get('search')
  const role = searchParams.get('role')
  const where: any = {}
  if (role) where.role = role
  if (search) {
    where.OR = [
      { name: { contains: search } },
      { email: { contains: search } },
      { phone: { contains: search } },
    ]
  }
  const users = await db.user.findMany({
    where,
    select: {
      id: true, email: true, name: true, phone: true, role: true, status: true,
      twoFactorEnabled: true, emailVerifiedAt: true, lastLoginAt: true, createdAt: true,
      member: { include: { cell: { select: { id: true, name: true } }, currentRank: true } },
    },
    orderBy: { createdAt: 'desc' },
  })
  const superAdminCount = users.filter((u) => u.role === 'SUPER_ADMIN' && u.status === 'ACTIVE').length
  return NextResponse.json({ users, superAdminCount })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'

export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const notifications = await db.notification.findMany({
    where: { userId: auth.session.userId },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })
  const unreadCount = await db.notification.count({ where: { userId: auth.session.userId, isRead: false } })
  return NextResponse.json({ notifications, unreadCount })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { id } = await params
  const updated = await db.notification.update({
    where: { id },
    data: { isRead: true, readAt: new Date() },
  })
  return NextResponse.json({ notification: updated })
}

export async function POST(req: NextRequest) {
  // Mark all as read
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  await db.notification.updateMany({
    where: { userId: auth.session.userId, isRead: false },
    data: { isRead: true, readAt: new Date() },
  })
  return NextResponse.json({ ok: true })
}

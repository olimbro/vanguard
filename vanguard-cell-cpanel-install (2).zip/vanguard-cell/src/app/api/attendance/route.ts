import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canTakeAttendance } from '@/lib/api-auth'
import { audit } from '@/lib/audit'
import {
  awardPoints, recalculateStreak, evaluateRank, evaluateBadges,
  recalculateAttendancePercentage, recalculateEngagementScore, getPointRules,
} from '@/lib/gamification'
import { randomUUID } from 'crypto'

// GET /api/attendance?eventId=...&memberId=...
export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { searchParams } = new URL(req.url)
  const eventId = searchParams.get('eventId')
  const memberId = searchParams.get('memberId')
  const where: any = {}
  if (eventId) where.eventId = eventId
  if (memberId) where.memberId = memberId
  if (auth.session.role === 'MEMBER' && auth.member) where.memberId = auth.member.id
  const records = await db.attendanceRecord.findMany({
    where,
    include: { member: { include: { user: true } }, event: true, recordedBy: { select: { id: true, name: true } } },
    orderBy: { createdAt: 'desc' },
    take: 500,
  })
  return NextResponse.json({ records })
}

// POST /api/attendance  — mark attendance (admin manual / QR / PIN)
export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const body = await req.json()
  const { eventId, memberId, status, method, checkInTime, checkOutTime, deviceIdentifier, locationVerified, notes, offlineUuid, sync } = body
  if (!eventId || !memberId) return NextResponse.json({ error: 'eventId and memberId are required' }, { status: 400 })

  // Self check-in (members checking themselves in via QR/PIN)
  const isSelfCheckIn = method === 'SELF' || (method === 'QR' && auth.member?.id === memberId)
  if (!isSelfCheckIn && !canTakeAttendance(auth.session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  // Offline sync — check the offlineUuid for dedup
  if (offlineUuid) {
    const existing = await db.attendanceRecord.findFirst({ where: { offlineUuid } })
    if (existing) return NextResponse.json({ record: existing, duplicate: true })
  }

  // Find any existing record for this event+member
  const existing = await db.attendanceRecord.findUnique({
    where: { eventId_memberId: { eventId, memberId } },
  })
  if (existing && existing.status !== 'ABSENT') {
    // Don't overwrite a real attendance with another method's check-in
    return NextResponse.json({ record: existing, duplicate: true, message: 'Attendance already recorded' })
  }

  const event = await db.event.findUnique({ where: { id: eventId } })
  if (!event) return NextResponse.json({ error: 'Event not found' }, { status: 404 })

  const finalStatus = status || (existing?.status === 'ABSENT' ? 'PRESENT' : 'PRESENT')
  const record = await db.attendanceRecord.upsert({
    where: { eventId_memberId: { eventId, memberId } },
    create: {
      eventId, memberId,
      userId: auth.member?.id === memberId ? auth.session.userId : null,
      status: finalStatus,
      method: method || 'MANUAL',
      checkInTime: checkInTime ? new Date(checkInTime) : new Date(),
      checkOutTime: checkOutTime ? new Date(checkOutTime) : null,
      deviceIdentifier,
      locationVerified: !!locationVerified,
      verificationStatus: 'VERIFIED',
      recordedById: auth.session.userId,
      syncStatus: sync ? 'SYNCED' : 'SYNCED',
      offlineUuid: offlineUuid || null,
      notes,
    },
    update: {
      status: finalStatus,
      method: method || existing?.method || 'MANUAL',
      checkInTime: checkInTime ? new Date(checkInTime) : existing?.checkInTime || new Date(),
      checkOutTime: checkOutTime ? new Date(checkOutTime) : existing?.checkOutTime,
      deviceIdentifier: deviceIdentifier || existing?.deviceIdentifier,
      locationVerified: locationVerified ?? existing?.locationVerified,
      recordedById: auth.session.userId,
      notes: notes || existing?.notes,
    },
    include: { member: true },
  })

  // Update member's lastAttendanceAt
  await db.member.update({
    where: { id: memberId },
    data: { lastAttendanceAt: new Date() },
  })

  // Award points if PRESENT or LATE
  if (finalStatus === 'PRESENT' || finalStatus === 'LATE') {
    const rules = await getPointRules()
    await awardPoints(memberId, rules.ATTEND_CELL, 'ATTEND', {
      eventId, userId: auth.session.userId, description: `Attended ${event.name}`,
    })
    if (finalStatus === 'PRESENT' && record.checkInTime && event.startDate && record.checkInTime <= event.startDate) {
      await awardPoints(memberId, rules.ON_TIME, 'ON_TIME', {
        eventId, userId: auth.session.userId, description: 'On-time bonus',
      })
    }
  }

  // Recalculate everything
  await recalculateStreak(memberId)
  await recalculateAttendancePercentage(memberId)
  await recalculateEngagementScore(memberId)
  await evaluateRank(memberId)
  await evaluateBadges(memberId)
  const { evaluateChallenges } = await import('@/lib/gamification')
  await evaluateChallenges(memberId)

  // Check for streak milestones (4 and 8 weeks)
  const member = await db.member.findUnique({ where: { id: memberId } })
  const rules = await getPointRules()
  if (member) {
    if (member.currentStreak === 4) {
      await awardPoints(memberId, rules.STREAK_4, 'STREAK_4', { description: '4-week streak!' })
    } else if (member.currentStreak === 8) {
      await awardPoints(memberId, rules.STREAK_8, 'STREAK_8', { description: '8-week streak!' })
    }
  }

  await audit({ actorId: auth.session.userId, action: 'CREATE', objectType: 'AttendanceRecord', objectId: record.id, newValue: { eventId, memberId, status: finalStatus, method } })

  // Create notification for the member
  if (record.member?.userId) {
    await db.notification.create({
      data: {
        userId: record.member.userId,
        type: 'CHECK_IN',
        title: 'Attendance recorded',
        body: `Your attendance for ${event.name} has been recorded.`,
        data: JSON.stringify({ eventId, points: rules.ATTEND_CELL }),
      },
    })
  }

  return NextResponse.json({ record })
}

// PATCH — update existing attendance (e.g., admin correction, check-out)
export async function PATCH(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canTakeAttendance(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const body = await req.json()
  const { id, status, checkOutTime, notes } = body
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
  const before = await db.attendanceRecord.findUnique({ where: { id } })
  const updated = await db.attendanceRecord.update({
    where: { id },
    data: {
      status: status || undefined,
      checkOutTime: checkOutTime ? new Date(checkOutTime) : undefined,
      notes: notes || undefined,
    },
  })
  // Compute duration if check-out provided
  if (checkOutTime && updated.checkInTime) {
    const duration = Math.round((new Date(checkOutTime).getTime() - updated.checkInTime.getTime()) / 60000)
    await db.attendanceRecord.update({ where: { id }, data: { durationMinutes: duration } })
  }
  await audit({ actorId: auth.session.userId, action: 'UPDATE', objectType: 'AttendanceRecord', objectId: id, oldValue: before, newValue: body })
  return NextResponse.json({ record: updated })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canTakeAttendance } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canTakeAttendance(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { id } = await params
  const body = await req.json()
  const before = await db.followUp.findUnique({ where: { id } })
  if (!before) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  const { nextFollowUpAt, lastContactAt, ...rest } = body
  const updated = await db.followUp.update({
    where: { id },
    data: {
      ...rest,
      nextFollowUpAt: nextFollowUpAt ? new Date(nextFollowUpAt) : undefined,
      lastContactAt: lastContactAt ? new Date(lastContactAt) : new Date(),
    },
  })
  // If status closed and follow-up done, award points to worker (if worker is a member)
  if (rest.status === 'CLOSED' && before.status !== 'CLOSED') {
    const worker = await db.member.findUnique({ where: { userId: updated.assignedWorkerId || '' } })
    if (worker) {
      const { awardPoints, getPointRules } = await import('@/lib/gamification')
      const rules = await getPointRules()
      await awardPoints(worker.id, rules.FOLLOW_UP_DONE, 'FOLLOW_UP', { description: 'Follow-up completed', referenceId: id })
    }
  }
  await audit({ actorId: auth.session.userId, action: 'UPDATE', objectType: 'FollowUp', objectId: id, oldValue: before, newValue: body })
  return NextResponse.json({ followup: updated })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage, canTakeAttendance } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status')
  const assignedToMe = searchParams.get('mine') === 'true'
  const where: any = {}
  if (status) where.status = status
  if (assignedToMe) where.assignedWorkerId = auth.session.userId
  if (auth.session.role !== 'SUPER_ADMIN') {
    // restrict by cell
    where.subject = { cellId: auth.cellId }
  }
  const followups = await db.followUp.findMany({
    where,
    include: {
      subject: { include: { cell: true } },
      worker: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: 'desc' },
  })
  return NextResponse.json({ followups })
}

export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canTakeAttendance(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const body = await req.json()
  const { subjectMemberId, assignedWorkerId, priority, contactMethod, nextFollowUpAt, notes, status } = body
  if (!subjectMemberId) return NextResponse.json({ error: 'subjectMemberId required' }, { status: 400 })
  const followup = await db.followUp.create({
    data: {
      subjectMemberId,
      assignedWorkerId: assignedWorkerId || auth.session.userId,
      priority: priority || 'NORMAL',
      contactMethod,
      nextFollowUpAt: nextFollowUpAt ? new Date(nextFollowUpAt) : null,
      notes,
      status: status || 'NEW',
      lastContactAt: new Date(),
    },
  })
  await audit({ actorId: auth.session.userId, action: 'CREATE', objectType: 'FollowUp', objectId: followup.id, newValue: body })
  return NextResponse.json({ followup }, { status: 201 })
}

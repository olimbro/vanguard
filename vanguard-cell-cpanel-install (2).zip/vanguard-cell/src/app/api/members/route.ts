import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage, canViewAllMembers } from '@/lib/api-auth'
import { audit } from '@/lib/audit'

export async function GET(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status')
  const search = searchParams.get('search')
  const limit = parseInt(searchParams.get('limit') || '100')
  
  const where: any = {}
  if (auth.session.role !== 'SUPER_ADMIN') where.cellId = auth.cellId
  if (status) where.status = status
  if (search) {
    where.OR = [
      { fullName: { contains: search } },
      { email: { contains: search } },
      { phone: { contains: search } },
    ]
  }
  const members = await db.member.findMany({
    where,
    include: {
      user: { select: { id: true, email: true, phone: true, role: true, status: true } },
      cell: { select: { id: true, name: true } },
      currentRank: true,
      assignedWorker: { select: { id: true, name: true } },
      _count: { select: { attendanceRecords: true, badges: true } },
    },
    orderBy: { fullName: 'asc' },
    take: limit,
  })
  return NextResponse.json({ members })
}

export async function POST(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const body = await req.json()
  const { fullName, preferredName, email, phone, whatsapp, gender, dateOfBirth, address, location, occupation, emergencyContact, status, cellId, assignedWorkerId, notes, isMinor, guardianName, guardianConsent, photoUrl } = body
  if (!fullName || !cellId) return NextResponse.json({ error: 'Full name and cell are required' }, { status: 400 })
  
  // Create a user account for the member if email provided
  let userId: string | undefined
  if (email) {
    const existing = await db.user.findUnique({ where: { email } })
    if (existing) {
      userId = existing.id
    } else {
      const newUser = await db.user.create({
        data: {
          email,
          passwordHash: 'TEMP-' + Math.random().toString(36).slice(2), // password reset required on first login
          name: fullName,
          phone,
          role: 'MEMBER',
          status: 'ACTIVE',
        },
      })
      userId = newUser.id
    }
  }
  
  const member = await db.member.create({
    data: {
      userId: userId || 'no-user-' + Math.random().toString(36).slice(2),
      cellId,
      fullName,
      preferredName: preferredName || fullName.split(' ')[0],
      photoUrl,
      gender,
      dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
      phone,
      whatsapp,
      email,
      address,
      location,
      occupation,
      emergencyContact,
      status: status || 'NEW_MEMBER',
      assignedWorkerId,
      notes,
      isMinor: !!isMinor,
      guardianName,
      guardianConsent: !!guardianConsent,
      dateJoinedCell: new Date(),
    },
    include: { cell: true, currentRank: true },
  })
  await audit({ actorId: auth.session.userId, action: 'CREATE', objectType: 'Member', objectId: member.id, newValue: body })
  return NextResponse.json({ member }, { status: 201 })
}

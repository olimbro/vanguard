import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult, canManage } from '@/lib/api-auth'
import { audit } from '@/lib/audit'
import { recalculateAttendancePercentage, recalculateEngagementScore } from '@/lib/gamification'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  const { id } = await params
  const member = await db.member.findUnique({
    where: { id },
    include: {
      user: { select: { id: true, email: true, phone: true, role: true, status: true } },
      cell: true,
      currentRank: true,
      assignedWorker: { select: { id: true, name: true } },
      attendanceRecords: { include: { event: true }, orderBy: { createdAt: 'desc' }, take: 30 },
      badges: { include: { badge: true } },
      pointTransactions: { orderBy: { createdAt: 'desc' }, take: 30 },
      followUps: { include: { worker: { select: { id: true, name: true } } }, orderBy: { createdAt: 'desc' } },
      _count: { select: { attendanceRecords: true, badges: true } },
    },
  })
  if (!member) return NextResponse.json({ error: 'Member not found' }, { status: 404 })
  // Permission check: members can only see their own profile, workers+ can see all
  if (auth.session.role === 'MEMBER' && auth.member?.id !== id) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  return NextResponse.json({ member })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!canManage(auth.session.role) && auth.member?.id !== (await params).id) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const { id } = await params
  const body = await req.json()
  const before = await db.member.findUnique({ where: { id } })
  if (!before) return NextResponse.json({ error: 'Member not found' }, { status: 404 })
  const { dateOfBirth, dateJoinedCell, dateConverted, ...rest } = body
  const updated = await db.member.update({
    where: { id },
    data: {
      ...rest,
      dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : undefined,
      dateJoinedCell: dateJoinedCell ? new Date(dateJoinedCell) : undefined,
      dateConverted: dateConverted ? new Date(dateConverted) : undefined,
    },
  })
  await recalculateAttendancePercentage(id)
  await recalculateEngagementScore(id)
  await audit({ actorId: auth.session.userId, action: 'UPDATE', objectType: 'Member', objectId: id, oldValue: before, newValue: body })
  return NextResponse.json({ member: updated })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!['SUPER_ADMIN', 'CELL_ADMIN'].includes(auth.session.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const { id } = await params
  // Soft-delete: archive instead of hard delete
  const member = await db.member.update({ where: { id }, data: { status: 'ARCHIVED', accountStatus: 'ARCHIVED' } })
  await audit({ actorId: auth.session.userId, action: 'DELETE', objectType: 'Member', objectId: id, oldValue: member })
  return NextResponse.json({ ok: true })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, isAuthedResult } from '@/lib/api-auth'
import { can, getPermissionMatrix, refreshPermissionMatrix, DEFAULT_PERMISSIONS, ALL_PERMISSIONS, ALL_ROLES, ROLE_LABELS } from '@/lib/auth'
import { audit } from '@/lib/audit'

// GET /api/permissions — return the current permission matrix + metadata
export async function GET() {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!can(auth.session.role, 'MANAGE_PERMISSIONS')) {
    return NextResponse.json({ error: 'Forbidden — requires MANAGE_PERMISSIONS permission' }, { status: 403 })
  }
  return NextResponse.json({
    matrix: getPermissionMatrix(),
    roles: ALL_ROLES.map((r) => ({ value: r, label: ROLE_LABELS[r] })),
    permissions: ALL_PERMISSIONS,
    defaults: DEFAULT_PERMISSIONS,
  })
}

// PATCH /api/permissions — update the permission matrix (SUPER_ADMIN only)
// Body: { matrix: { ROLE: { PERMISSION: boolean } } }
export async function PATCH(req: NextRequest) {
  const auth = await requireAuth()
  if (!isAuthedResult(auth)) return auth
  if (!can(auth.session.role, 'MANAGE_PERMISSIONS')) {
    return NextResponse.json({ error: 'Forbidden — requires MANAGE_PERMISSIONS permission' }, { status: 403 })
  }
  const body = await req.json()
  const { matrix } = body
  if (!matrix || typeof matrix !== 'object') {
    return NextResponse.json({ error: 'matrix object required' }, { status: 400 })
  }
  // Validate and normalize: SUPER_ADMIN is always all-true (ignored if client tries to change)
  const normalized: Record<string, Record<string, boolean>> = {
    SUPER_ADMIN: Object.fromEntries(ALL_PERMISSIONS.map((p) => [p.key, true])),
  }
  for (const role of ALL_ROLES) {
    if (role === 'SUPER_ADMIN') continue
    normalized[role] = {}
    for (const perm of ALL_PERMISSIONS) {
      normalized[role][perm.key] = matrix[role]?.[perm.key] === true
    }
  }
  await db.setting.upsert({
    where: { key: 'permissions.matrix' },
    create: {
      key: 'permissions.matrix',
      value: JSON.stringify(normalized),
      category: 'PERMISSIONS',
      updatedById: auth.session.userId,
    },
    update: {
      value: JSON.stringify(normalized),
      category: 'PERMISSIONS',
      updatedById: auth.session.userId,
    },
  })
  // Refresh the in-memory cache so the new matrix takes effect immediately
  await refreshPermissionMatrix()
  await audit({
    actorId: auth.session.userId,
    action: 'PERMISSION_CHANGE',
    objectType: 'PermissionMatrix',
    objectId: 'permissions.matrix',
    newValue: normalized,
  })
  return NextResponse.json({ matrix: normalized })
}

'use client'
import { useState } from 'react'
import { api } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'

export function LoginScreen({ onLoggedIn }: { onLoggedIn: () => void }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const login = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) })
      toast({ title: 'Welcome back!', description: 'You are now logged in.' })
      onLoggedIn()
    } catch (e: any) {
      toast({ title: 'Login failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const register = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await api('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({ email, password, name, phone }),
      })
      toast({ title: 'Account created!', description: 'Welcome to Vanguard Cell. Your account starts as a Member — a cell leader can assign additional roles.' })
      onLoggedIn()
    } catch (e: any) {
      toast({ title: 'Registration failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const quickLogin = async (em: string) => {
    setEmail(em)
    setPassword('password123')
    setLoading(true)
    try {
      await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: em, password: 'password123' }) })
      onLoggedIn()
    } catch (e: any) {
      toast({ title: 'Login failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-[#0B2A5B] via-[#123F8C] to-[#0B2A5B]">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-[#E7B93E] to-[#D4AF37] flex items-center justify-center text-4xl font-bold text-[#0B2A5B] shadow-2xl">V</div>
          <h1 className="text-2xl font-bold text-white">Vanguard Cell</h1>
          <p className="text-white/70 text-sm mt-1">Christ Embassy — Vanguard Cell 1, Awka</p>
        </div>

        <Card className="border-0 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-[#0B2A5B]">Welcome</CardTitle>
            <CardDescription>Sign in or create an account</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="login">Sign In</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={login} className="space-y-3">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                  </div>
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                  </div>
                  <Button type="submit" className="w-full bg-[#0B2A5B] hover:bg-[#123F8C]" disabled={loading}>
                    {loading ? 'Signing in...' : 'Sign In'}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register">
                <form onSubmit={register} className="space-y-3">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone <span className="text-xs text-muted-foreground">(optional)</span></Label>
                    <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+234 ..." />
                  </div>
                  <div>
                    <Label htmlFor="email2">Email</Label>
                    <Input id="email2" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                  </div>
                  <div>
                    <Label htmlFor="password2">Password</Label>
                    <Input id="password2" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
                  </div>
                  <p className="text-xs text-muted-foreground bg-muted/40 p-2 rounded text-center">
                    New accounts start as <strong>Member</strong>. A Super Admin can assign additional roles after sign-up.
                  </p>
                  <Button type="submit" className="w-full bg-[#0B2A5B] hover:bg-[#123F8C]" disabled={loading}>
                    {loading ? 'Creating account...' : 'Create Account'}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            <div className="mt-6 pt-6 border-t">
              <p className="text-xs text-muted-foreground mb-2 text-center">Quick demo login</p>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" onClick={() => quickLogin('leader@vanguard.test')}>Cell Leader</Button>
                <Button variant="outline" size="sm" onClick={() => quickLogin('member1@vanguard.test')}>Member</Button>
                <Button variant="outline" size="sm" onClick={() => quickLogin('superadmin@vanguard.test')}>Super Admin</Button>
                <Button variant="outline" size="sm" onClick={() => quickLogin('worker1@vanguard.test')}>Worker</Button>
              </div>
            </div>
          </CardContent>
        </Card>
        <p className="text-center text-white/60 text-xs mt-6">WIN SOULS · BUILD PEOPLE · DEVELOP LEADERS · MULTIPLY CELLS</p>
      </div>
    </div>
  )
}

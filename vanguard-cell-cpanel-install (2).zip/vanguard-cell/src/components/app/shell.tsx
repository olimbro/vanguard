'use client'
import { useEffect } from 'react'
import { useApp, api } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  LayoutDashboard, Calendar, ClipboardCheck, Users, Trophy, MessageSquare,
  Megaphone, Bell, FileText, Settings as SettingsIcon, Shield, User,
  Flame, WifiOff, CloudOff, RefreshCw, LogOut, Menu, X, ShieldCheck
} from 'lucide-react'
import { useState } from 'react'
import { useToast } from '@/hooks/use-toast'

const ADMIN_NAV = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { key: 'events', label: 'Events', icon: Calendar },
  { key: 'attendance', label: 'Attendance', icon: ClipboardCheck },
  { key: 'members', label: 'Members', icon: Users },
  { key: 'visitors', label: 'Visitors', icon: User },
  { key: 'followup', label: 'Follow-Up', icon: Users },
  { key: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  { key: 'gamification', label: 'Gamification', icon: Flame },
  { key: 'messages', label: 'Messages', icon: MessageSquare },
  { key: 'announcements', label: 'Announcements', icon: Megaphone },
  { key: 'notifications', label: 'Notifications', icon: Bell },
  { key: 'calendar', label: 'Calendar', icon: Calendar },
  { key: 'reports', label: 'Reports', icon: FileText },
  { key: 'settings', label: 'Settings', icon: SettingsIcon },
  { key: 'audit', label: 'Audit Log', icon: Shield },
  { key: 'users', label: 'Users', icon: Users, superAdminOnly: true },
  { key: 'permissions', label: 'Permissions', icon: ShieldCheck, superAdminOnly: true },
  { key: 'profile', label: 'Profile', icon: User },
]

const MEMBER_NAV = [
  { key: 'dashboard', label: 'Home', icon: LayoutDashboard },
  { key: 'events', label: 'Events', icon: Calendar },
  { key: 'attendance', label: 'Check In', icon: ClipboardCheck },
  { key: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  { key: 'messages', label: 'Messages', icon: MessageSquare },
  { key: 'announcements', label: 'News', icon: Megaphone },
  { key: 'notifications', label: 'Alerts', icon: Bell },
  { key: 'profile', label: 'Profile', icon: User },
]

// Bottom nav (mobile) — 5 most-used
const MOBILE_NAV_ADMIN = [
  { key: 'dashboard', label: 'Home', icon: LayoutDashboard },
  { key: 'attendance', label: 'Attend', icon: ClipboardCheck },
  { key: 'members', label: 'Members', icon: Users },
  { key: 'messages', label: 'Chat', icon: MessageSquare },
  { key: 'profile', label: 'Profile', icon: User },
]
const MOBILE_NAV_MEMBER = [
  { key: 'dashboard', label: 'Home', icon: LayoutDashboard },
  { key: 'events', label: 'Events', icon: Calendar },
  { key: 'attendance', label: 'Check In', icon: ClipboardCheck },
  { key: 'leaderboard', label: 'Ranks', icon: Trophy },
  { key: 'profile', label: 'Profile', icon: User },
]

export function AppShell({ children, online }: { children: React.ReactNode; online: boolean }) {
  const { user, view, setView, pendingSyncCount } = useApp()
  const [unread, setUnread] = useState(0)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [syncing, setSyncing] = useState(false)
  const { toast } = useToast()

  const isAdmin = ['SUPER_ADMIN', 'CELL_ADMIN', 'ASSISTANT', 'WORKER'].includes(user?.role || '')
  const isSuperAdmin = user?.role === 'SUPER_ADMIN'
  // Filter out superAdminOnly items for non-super-admins
  const nav = (isAdmin ? ADMIN_NAV : MEMBER_NAV).filter((item: any) => !item.superAdminOnly || isSuperAdmin)
  const mobileNav = isAdmin ? MOBILE_NAV_ADMIN : MOBILE_NAV_MEMBER

  useEffect(() => {
    // Poll for unread notifications
    const fetchUnread = async () => {
      try {
        const data = await api('/api/notifications')
        setUnread(data.unreadCount || 0)
      } catch {}
    }
    fetchUnread()
    const interval = setInterval(fetchUnread, 30000)
    return () => clearInterval(interval)
  }, [])

  const logout = async () => {
    await api('/api/auth/logout', { method: 'POST' })
    window.location.reload()
  }

  const syncNow = async () => {
    setSyncing(true)
    try {
      const { syncOfflineQueue } = await import('@/lib/store')
      const r = await syncOfflineQueue()
      if (r.synced > 0) {
        toast({ title: `Synced ${r.synced} record${r.synced === 1 ? '' : 's'}`, description: 'Offline attendance has been uploaded.' })
        useApp.getState().setPendingSyncCount(0)
      } else {
        toast({ title: 'Nothing to sync' })
      }
    } catch (e: any) {
      toast({ title: 'Sync failed', description: e.message, variant: 'destructive' })
    } finally {
      setSyncing(false)
    }
  }

  const initials = user?.name?.split(' ').map((n: string) => n[0]).slice(0, 2).join('') || 'U'

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50/30 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-sidebar text-sidebar-foreground fixed inset-y-0 left-0 z-30">
        <div className="p-5 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#E7B93E] to-[#D4AF37] flex items-center justify-center text-xl font-bold text-[#0B2A5B]">V</div>
            <div>
              <div className="font-bold text-sm">Vanguard Cell</div>
              <div className="text-xs text-sidebar-foreground/60">Christ Embassy · Awka</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5 scrollbar-thin">
          {nav.map((item) => {
            const Icon = item.icon
            const active = view === item.key
            return (
              <button
                key={item.key}
                onClick={() => setView(item.key as any)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                  active
                    ? 'bg-sidebar-primary text-sidebar-primary-foreground font-semibold'
                    : 'text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
                {item.key === 'notifications' && unread > 0 && (
                  <Badge variant="destructive" className="ml-auto h-5 px-1.5 text-xs">{unread}</Badge>
                )}
              </button>
            )
          })}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <div className="flex items-center gap-2 mb-2">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-[#123F8C] text-white text-xs">{initials}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold truncate">{user?.name}</div>
              <div className="text-xs text-sidebar-foreground/60 truncate">{user?.role.replace('_', ' ')}</div>
            </div>
            <Button variant="ghost" size="icon" onClick={logout} className="h-8 w-8 text-sidebar-foreground/70 hover:text-sidebar-foreground">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </aside>

      {/* Mobile drawer */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-40">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-72 bg-sidebar text-sidebar-foreground flex flex-col">
            <div className="p-4 border-b border-sidebar-border flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#E7B93E] to-[#D4AF37] flex items-center justify-center text-sm font-bold text-[#0B2A5B]">V</div>
                <span className="font-bold text-sm">Vanguard Cell</span>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(false)} className="text-sidebar-foreground">
                <X className="h-4 w-4" />
              </Button>
            </div>
            <nav className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">
              {nav.map((item) => {
                const Icon = item.icon
                const active = view === item.key
                return (
                  <button
                    key={item.key}
                    onClick={() => { setView(item.key as any); setSidebarOpen(false) }}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm ${
                      active ? 'bg-sidebar-primary text-sidebar-primary-foreground font-semibold' : 'text-sidebar-foreground/80 hover:bg-sidebar-accent'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </button>
                )
              })}
              <button onClick={logout} className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-sidebar-foreground/80 hover:bg-sidebar-accent">
                <LogOut className="h-4 w-4" /> Sign out
              </button>
            </nav>
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        {/* Top header */}
        <header className="sticky top-0 z-20 bg-white/90 backdrop-blur border-b lg:static lg:bg-transparent lg:border-0 lg:backdrop-blur-none">
          <div className="flex items-center justify-between px-4 py-3 lg:px-8 lg:py-5">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
                <Menu className="h-5 w-5" />
              </Button>
              <div className="lg:hidden flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#0B2A5B] to-[#123F8C] flex items-center justify-center text-xs font-bold text-[#E7B93E]">V</div>
                <span className="font-bold text-sm text-[#0B2A5B]">Vanguard Cell</span>
              </div>
              <h1 className="hidden lg:block text-xl font-bold text-[#0B2A5B] capitalize">{view}</h1>
            </div>
            <div className="flex items-center gap-2">
              {!online && (
                <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                  <WifiOff className="h-3 w-3 mr-1" /> Offline
                </Badge>
              )}
              {pendingSyncCount > 0 && (
                <Button size="sm" variant="outline" onClick={syncNow} disabled={syncing} className="bg-amber-50 text-amber-700 border-amber-200">
                  <CloudOff className="h-3 w-3 mr-1" />
                  {syncing ? 'Syncing...' : `${pendingSyncCount} pending`}
                </Button>
              )}
              <Button variant="ghost" size="icon" onClick={() => setView('notifications')} className="relative">
                <Bell className="h-5 w-5" />
                {unread > 0 && <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-red-500" />}
              </Button>
              <Avatar className="h-9 w-9 hidden sm:flex cursor-pointer" onClick={() => setView('profile')}>
                <AvatarFallback className="bg-[#0B2A5B] text-white text-xs">{initials}</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 py-4 lg:px-8 lg:py-6 pb-24 lg:pb-8">{children}</main>

        {/* Mobile bottom nav */}
        <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-white border-t safe-bottom">
          <div className="grid grid-cols-5 max-w-md mx-auto">
            {mobileNav.map((item) => {
              const Icon = item.icon
              const active = view === item.key
              return (
                <button
                  key={item.key}
                  onClick={() => setView(item.key as any)}
                  className={`flex flex-col items-center justify-center gap-1 py-2.5 px-1 ${
                    active ? 'text-[#0B2A5B]' : 'text-gray-400'
                  }`}
                >
                  <div className={`p-1 rounded-lg ${active ? 'bg-blue-50' : ''}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="text-[10px] font-medium">{item.label}</span>
                </button>
              )
            })}
          </div>
        </nav>
      </div>
    </div>
  )
}

'use client'
import { useEffect, useState } from 'react'
import { api, useApp } from '@/lib/store'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { UserPlus, Mail, Phone, Calendar } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { formatDistanceToNow } from 'date-fns'

const STATUS_COLORS: Record<string, string> = {
  NEW: '#D4AF37', CONTACTED: '#0EA5E9', FOLLOW_UP_REQUIRED: '#F97316',
  ENGAGED: '#22C55E', ACTIVE: '#22C55E', INACTIVE: '#EF4444', ESCALATED: '#DC2626', CLOSED: '#9CA3AF',
}

export function VisitorsView() {
  const [visitors, setVisitors] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    try {
      const data = await api('/api/visitors')
      setVisitors(data.visitors || [])
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const convert = async (id: string) => {
    try {
      await api(`/api/visitors/${id}`, { method: 'POST' })
      toast({ title: 'Visitor converted!', description: 'A new member account has been created.' })
      load()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-[#0B2A5B]">Visitors</h2>
      {loading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-20 bg-muted/30 rounded-xl animate-pulse" />)}</div>
      ) : visitors.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">No visitors recorded yet.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {visitors.map((v) => (
            <Card key={v.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold">{v.fullName}</span>
                      <Badge variant="outline" style={{ color: STATUS_COLORS[v.followUpStatus], borderColor: STATUS_COLORS[v.followUpStatus] + '40' }}>
                        {v.followUpStatus.replace(/_/g, ' ').toLowerCase()}
                      </Badge>
                      {v.convertedAt && <Badge className="bg-[#22C55E] text-white">Converted</Badge>}
                    </div>
                    <div className="text-xs text-muted-foreground space-y-0.5">
                      {v.email && <div className="flex items-center gap-1"><Mail className="h-3 w-3" /> {v.email}</div>}
                      {v.phone && <div className="flex items-center gap-1"><Phone className="h-3 w-3" /> {v.phone}</div>}
                      {v.invitedByMember && <div>Invited by: {v.invitedByMember.fullName}</div>}
                      <div className="flex items-center gap-1"><Calendar className="h-3 w-3" /> First visit: {formatDistanceToNow(new Date(v.firstVisitDate), { addSuffix: true })}</div>
                    </div>
                  </div>
                  {!v.convertedAt && v.followUpStatus !== 'CLOSED' && (
                    <Button size="sm" variant="outline" onClick={() => convert(v.id)}>
                      <UserPlus className="h-3 w-3 mr-1" /> Convert to Member
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

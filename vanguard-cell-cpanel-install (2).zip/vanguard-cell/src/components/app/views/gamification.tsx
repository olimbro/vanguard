'use client'
import { useEffect, useState } from 'react'
import { api } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Trophy, Award, Target, Zap, Flame } from 'lucide-react'

export function GamificationView() {
  const [ranks, setRanks] = useState<any[]>([])
  const [badges, setBadges] = useState<any[]>([])

  useEffect(() => {
    api('/api/ranks').then((d) => {
      setRanks(d.ranks || [])
      setBadges(d.badges || [])
    })
  }, [])

  return (
    <div className="space-y-4">
      <Card className="border-0 bg-gradient-to-r from-[#0B2A5B] to-[#123F8C] text-white">
        <CardContent className="p-6">
          <Trophy className="h-8 w-8 text-[#E7B93E] mb-2" />
          <h2 className="text-xl font-bold">Gamification</h2>
          <p className="text-white/80 text-sm mt-1">Points, ranks, and badges encourage participation. They do NOT measure spirituality, salvation, or personal worth.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Trophy className="h-4 w-4" /> Ranks</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-2">
            {ranks.map((r) => (
              <div key={r.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/20">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-2xl" style={{ backgroundColor: r.color + '20', border: `2px solid ${r.color}` }}>
                  {r.icon}
                </div>
                <div className="flex-1">
                  <div className="font-semibold">{r.name}</div>
                  <div className="text-xs text-muted-foreground">Level {r.level} · requires {r.minPoints}+ points</div>
                </div>
                <Badge style={{ backgroundColor: r.color, color: 'white' }}>L{r.level}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Award className="h-4 w-4" /> Badges</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {badges.map((b) => (
              <div key={b.id} className="flex flex-col items-center text-center p-4 rounded-xl" style={{ backgroundColor: b.color + '10' }}>
                <div className="w-14 h-14 rounded-full flex items-center justify-center text-2xl mb-2" style={{ backgroundColor: b.color + '20', border: `2px solid ${b.color}` }}>
                  {b.icon}
                </div>
                <div className="font-semibold text-sm">{b.name}</div>
                <div className="text-xs text-muted-foreground mt-1">{b.description}</div>
                <Badge variant="ghost" className="mt-2">+{b.pointsReward} pts</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Target className="h-4 w-4" /> Points Rules</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2 text-sm">
            {[
              ['Attend cell meeting', '+10', Flame],
              ['On time', '+5', Zap],
              ['Register for event', '+2', Target],
              ['Attend registered event', '+10', Flame],
              ['Invite a guest', '+10', Award],
              ['Outreach participation', '+15', Target],
              ['Complete training', '+20', Award],
              ['4-week streak', '+25', Flame],
              ['8-week streak', '+50', Flame],
              ['Complete challenge', '+10', Trophy],
            ].map(([label, pts, Icon]: any, i) => (
              <div key={i} className="flex items-center gap-2 p-2 bg-muted/20 rounded">
                <Icon className="h-4 w-4 text-[#D4AF37]" />
                <span className="flex-1">{label}</span>
                <Badge variant="outline" className="text-[#D4AF37] border-[#D4AF37]">{pts}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

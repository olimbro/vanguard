'use client'
import { useEffect, useState } from 'react'
import { useApp, api } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Search, UserPlus, Phone, Mail, MapPin, Flame, Trophy, ChevronRight } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { formatDistanceToNow } from 'date-fns'

const STATUS_COLORS: Record<string, string> = {
  ACTIVE_MEMBER: '#22C55E',
  REGULAR_MEMBER: '#0EA5E9',
  NEW_MEMBER: '#D4AF37',
  WORKER: '#123F8C',
  CELL_LEADER: '#0B2A5B',
  INACTIVE: '#EF4444',
  TEMPORARILY_AWAY: '#F97316',
  ARCHIVED: '#9CA3AF',
  VISITOR: '#A855F7',
}

export function MembersView() {
  const { user } = useApp()
  const [members, setMembers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [showAdd, setShowAdd] = useState(false)
  const [selected, setSelected] = useState<any>(null)
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    try {
      const data = await api(`/api/members?search=${encodeURIComponent(search)}&status=${statusFilter === 'ALL' ? '' : statusFilter}`)
      setMembers(data.members || [])
    } catch (e: any) {
      toast({ title: 'Failed to load', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [statusFilter])

  const isAdmin = ['SUPER_ADMIN', 'CELL_ADMIN', 'ASSISTANT', 'WORKER'].includes(user?.role || '')

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, email, or phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && load()}
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full md:w-44"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Statuses</SelectItem>
            <SelectItem value="ACTIVE_MEMBER">Active Member</SelectItem>
            <SelectItem value="REGULAR_MEMBER">Regular Member</SelectItem>
            <SelectItem value="NEW_MEMBER">New Member</SelectItem>
            <SelectItem value="WORKER">Worker</SelectItem>
            <SelectItem value="CELL_LEADER">Cell Leader</SelectItem>
            <SelectItem value="INACTIVE">Inactive</SelectItem>
            <SelectItem value="TEMPORARILY_AWAY">Temporarily Away</SelectItem>
          </SelectContent>
        </Select>
        {isAdmin && (
          <Button onClick={() => setShowAdd(true)} className="bg-[#0B2A5B] hover:bg-[#123F8C]">
            <UserPlus className="h-4 w-4 mr-1" /> Add Member
          </Button>
        )}
      </div>

      {loading ? (
        <div className="grid gap-3">{[...Array(5)].map((_, i) => <div key={i} className="h-20 bg-muted/30 rounded-xl animate-pulse" />)}</div>
      ) : members.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">No members found.</CardContent></Card>
      ) : (
        <div className="grid gap-2">
          {members.map((m) => (
            <Card key={m.id} className="premium-card cursor-pointer" onClick={() => setSelected(m)}>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#0B2A5B] to-[#123F8C] text-white flex items-center justify-center font-bold text-sm shrink-0">
                  {m.fullName.split(' ').map((n: string) => n[0]).slice(0, 2).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold truncate">{m.fullName}</span>
                    <Badge variant="outline" style={{ color: STATUS_COLORS[m.status], borderColor: STATUS_COLORS[m.status] + '40', backgroundColor: STATUS_COLORS[m.status] + '10' }}>
                      {m.status.replace(/_/g, ' ').toLowerCase()}
                    </Badge>
                    {m.currentRank && (
                      <Badge variant="ghost" className="text-xs">{m.currentRank.icon} {m.currentRank.name}</Badge>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1 flex flex-wrap gap-x-3 gap-y-1">
                    {m.email && <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> {m.email}</span>}
                    {m.phone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> {m.phone}</span>}
                    {m.lastAttendanceAt && <span>Last seen: {formatDistanceToNow(new Date(m.lastAttendanceAt), { addSuffix: true })}</span>}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-sm font-bold text-[#D4AF37]">{m.currentPoints} pts</div>
                  <div className="text-xs text-muted-foreground flex items-center justify-end gap-1"><Flame className="h-3 w-3 text-orange-500" /> {m.currentStreak}</div>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <AddMemberDialog open={showAdd} onOpenChange={setShowAdd} onCreated={load} />
      {selected && <MemberDetailDialog member={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}

function AddMemberDialog({ open, onOpenChange, onCreated }: any) {
  const { toast } = useToast()
  const { user } = useApp()
  const [form, setForm] = useState({
    fullName: '', preferredName: '', email: '', phone: '', whatsapp: '',
    gender: 'MALE', dateOfBirth: '', address: '', occupation: '',
    emergencyContact: '', status: 'NEW_MEMBER', notes: '',
  })

  const submit = async () => {
    try {
      await api('/api/members', {
        method: 'POST',
        body: JSON.stringify({ ...form, cellId: user?.member?.cellId }),
      })
      toast({ title: 'Member added', description: `${form.fullName} has been added.` })
      setForm({ fullName: '', preferredName: '', email: '', phone: '', whatsapp: '', gender: 'MALE', dateOfBirth: '', address: '', occupation: '', emergencyContact: '', status: 'NEW_MEMBER', notes: '' })
      onOpenChange(false)
      onCreated()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Add New Member</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Label>Full Name *</Label>
            <Input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </div>
          <div>
            <Label>Preferred Name</Label>
            <Input value={form.preferredName} onChange={(e) => setForm({ ...form, preferredName: e.target.value })} />
          </div>
          <div>
            <Label>Gender</Label>
            <Select value={form.gender} onValueChange={(v) => setForm({ ...form, gender: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="MALE">Male</SelectItem>
                <SelectItem value="FEMALE">Female</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Email</Label>
            <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <Label>Phone</Label>
            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div>
            <Label>WhatsApp</Label>
            <Input value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value })} />
          </div>
          <div>
            <Label>Date of Birth</Label>
            <Input type="date" value={form.dateOfBirth} onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })} />
          </div>
          <div className="col-span-2">
            <Label>Address</Label>
            <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </div>
          <div>
            <Label>Occupation</Label>
            <Input value={form.occupation} onChange={(e) => setForm({ ...form, occupation: e.target.value })} />
          </div>
          <div>
            <Label>Emergency Contact</Label>
            <Input value={form.emergencyContact} onChange={(e) => setForm({ ...form, emergencyContact: e.target.value })} />
          </div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="NEW_MEMBER">New Member</SelectItem>
                <SelectItem value="ACTIVE_MEMBER">Active Member</SelectItem>
                <SelectItem value="REGULAR_MEMBER">Regular Member</SelectItem>
                <SelectItem value="WORKER">Worker</SelectItem>
                <SelectItem value="CELL_LEADER">Cell Leader</SelectItem>
                <SelectItem value="VISITOR">Visitor</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label>Notes</Label>
            <Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit} className="bg-[#0B2A5B] hover:bg-[#123F8C]">Add Member</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function MemberDetailDialog({ member, onClose }: any) {
  const [detail, setDetail] = useState<any>(null)
  const { toast } = useToast()

  useEffect(() => {
    api(`/api/members/${member.id}`).then((d) => setDetail(d.member)).catch(() => onClose())
  }, [member.id])

  if (!detail) return <Dialog open={true} onOpenChange={onClose}><DialogContent><div className="animate-pulse h-64" /></DialogContent></Dialog>

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{detail.fullName}</DialogTitle></DialogHeader>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#0B2A5B] to-[#123F8C] text-white flex items-center justify-center font-bold">
                {detail.fullName.split(' ').map((n: string) => n[0]).slice(0, 2).join('')}
              </div>
              <div>
                <Badge variant="outline" style={{ color: STATUS_COLORS[detail.status], borderColor: STATUS_COLORS[detail.status] + '40' }}>
                  {detail.status.replace(/_/g, ' ').toLowerCase()}
                </Badge>
                {detail.currentRank && (
                  <div className="text-sm mt-1">{detail.currentRank.icon} {detail.currentRank.name}</div>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="p-2 bg-muted/30 rounded-lg">
                <div className="text-xs text-muted-foreground">Points</div>
                <div className="font-bold text-[#D4AF37]">{detail.currentPoints}</div>
              </div>
              <div className="p-2 bg-muted/30 rounded-lg">
                <div className="text-xs text-muted-foreground">Streak</div>
                <div className="font-bold">🔥 {detail.currentStreak}</div>
              </div>
              <div className="p-2 bg-muted/30 rounded-lg">
                <div className="text-xs text-muted-foreground">Attendance</div>
                <div className="font-bold">{Math.round(detail.attendancePercentage)}%</div>
              </div>
              <div className="p-2 bg-muted/30 rounded-lg">
                <div className="text-xs text-muted-foreground">Engagement</div>
                <div className="font-bold">{Math.round(detail.engagementScore)}%</div>
              </div>
            </div>
            <div className="text-sm space-y-1">
              {detail.email && <div className="flex items-center gap-2"><Mail className="h-3 w-3 text-muted-foreground" /> {detail.email}</div>}
              {detail.phone && <div className="flex items-center gap-2"><Phone className="h-3 w-3 text-muted-foreground" /> {detail.phone}</div>}
              {detail.address && <div className="flex items-center gap-2"><MapPin className="h-3 w-3 text-muted-foreground" /> {detail.address}</div>}
            </div>
          </div>
          <div className="space-y-3">
            <div>
              <h4 className="font-semibold text-sm mb-2">Recent Attendance</h4>
              <div className="space-y-1 max-h-32 overflow-y-auto scrollbar-thin">
                {detail.attendanceRecords?.slice(0, 8).map((r: any) => (
                  <div key={r.id} className="flex items-center justify-between text-xs p-1.5 bg-muted/20 rounded">
                    <span className="truncate">{r.event?.name}</span>
                    <Badge variant="outline" className="text-xs">{r.status}</Badge>
                  </div>
                )) || <p className="text-xs text-muted-foreground">No attendance records</p>}
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-2">Badges ({detail.badges?.length || 0})</h4>
              <div className="flex flex-wrap gap-2">
                {detail.badges?.map((b: any) => (
                  <div key={b.id} className="flex items-center gap-1 p-1.5 rounded-lg" style={{ backgroundColor: b.badge.color + '15' }}>
                    <span>{b.badge.icon}</span>
                    <span className="text-xs">{b.badge.name}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-2">Recent Points</h4>
              <div className="space-y-1 max-h-32 overflow-y-auto scrollbar-thin">
                {detail.pointTransactions?.slice(0, 8).map((p: any) => (
                  <div key={p.id} className="flex justify-between text-xs p-1.5 bg-muted/20 rounded">
                    <span className="truncate">{p.description || p.reason}</span>
                    <span className={p.points > 0 ? 'text-green-600 font-bold' : 'text-red-500 font-bold'}>+{p.points}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

'use client'
import { useEffect, useState } from 'react'
import { useApp, api } from '@/lib/store'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Calendar, Plus, MapPin, Clock, Users, Ticket, X, QrCode, ChevronRight } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

const EVENT_TYPES = [
  'WEEKLY_CELL_MEETING', 'SUNDAY_SERVICE', 'SPECIAL_FELLOWSHIP', 'PRAYER_MEETING',
  'OUTREACH', 'EVANGELISM', 'LEADERSHIP_MEETING', 'TRAINING', 'BIBLE_STUDY',
  'YOUTH_MEETING', 'SOCIAL_FELLOWSHIP', 'CONFERENCE', 'OTHER',
]

const STATUS_COLORS: Record<string, string> = {
  DRAFT: '#9CA3AF',
  PUBLISHED: '#0EA5E9',
  REGISTRATION_OPEN: '#22C55E',
  REGISTRATION_CLOSED: '#F97316',
  ONGOING: '#D4AF37',
  COMPLETED: '#6B7280',
  CANCELLED: '#DC2626',
}

export function EventsView() {
  const { user, setView, setSelectedEventId } = useApp()
  const [events, setEvents] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<'upcoming' | 'past'>('upcoming')
  const [showCreate, setShowCreate] = useState(false)
  const [selected, setSelected] = useState<any>(null)
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    try {
      const data = await api(`/api/events?${tab}=true`)
      setEvents(data.events || [])
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [tab])

  const isAdmin = ['SUPER_ADMIN', 'CELL_ADMIN', 'ASSISTANT'].includes(user?.role || '')

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex gap-1 bg-muted/40 p-1 rounded-lg">
          <Button size="sm" variant={tab === 'upcoming' ? 'default' : 'ghost'} onClick={() => setTab('upcoming')}>Upcoming</Button>
          <Button size="sm" variant={tab === 'past' ? 'default' : 'ghost'} onClick={() => setTab('past')}>Past</Button>
        </div>
        {isAdmin && (
          <Button onClick={() => setShowCreate(true)} className="bg-[#0B2A5B] hover:bg-[#123F8C]">
            <Plus className="h-4 w-4 mr-1" /> Create Event
          </Button>
        )}
      </div>

      {loading ? (
        <div className="space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="h-32 bg-muted/30 rounded-xl animate-pulse" />)}</div>
      ) : events.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">No {tab} events.</CardContent></Card>
      ) : (
        <div className="space-y-3">
          {events.map((e) => (
            <Card key={e.id} className="premium-card cursor-pointer" onClick={() => setSelected(e)}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-[#0B2A5B] to-[#123F8C] text-white flex flex-col items-center justify-center shrink-0">
                    <span className="text-xs font-medium">{new Date(e.startDate).toLocaleDateString('en-GB', { month: 'short' }).toUpperCase()}</span>
                    <span className="text-lg font-bold leading-tight">{new Date(e.startDate).getDate()}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className="font-semibold truncate">{e.name}</h3>
                        <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-muted-foreground">
                          <Badge variant="outline" style={{ color: STATUS_COLORS[e.status], borderColor: STATUS_COLORS[e.status] + '40' }}>
                            {e.status.replace(/_/g, ' ').toLowerCase()}
                          </Badge>
                          {e.registrationRequired && <Badge variant="ghost" className="text-xs"><Ticket className="h-3 w-3 mr-1" /> Registration</Badge>}
                          <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {e.startTime}</span>
                          {e.venue && <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {e.venue}</span>}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        {e.registrationRequired && (
                          <div className="text-xs">
                            <div className="font-bold text-[#D4AF37]">{e._count?.registrations || 0}</div>
                            <div className="text-muted-foreground">registered</div>
                          </div>
                        )}
                        <div className="text-xs mt-1">
                          <div className="font-bold">{e._count?.attendanceRecords || 0}</div>
                          <div className="text-muted-foreground">attended</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 mt-1" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <CreateEventDialog open={showCreate} onOpenChange={setShowCreate} onCreated={load} />
      {selected && <EventDetailDialog event={selected} onClose={() => setSelected(null)} onTakeAttendance={() => { setSelectedEventId(selected.id); setView('attendance'); setSelected(null) }} />}
    </div>
  )
}

function CreateEventDialog({ open, onOpenChange, onCreated }: any) {
  const { toast } = useToast()
  const { user } = useApp()
  const [form, setForm] = useState({
    name: '', description: '', eventType: 'WEEKLY_CELL_MEETING',
    startDate: '', endDate: '', startTime: '16:00', endTime: '18:00',
    venue: '', address: '', capacity: '', registrationRequired: false,
    registrationDeadline: '', isPublic: false, accessRule: 'MEMBERS_ONLY',
    enablePin: true, enableQr: true, enableGeolocation: false, geoRadiusMeters: 100,
  })
  const [fields, setFields] = useState<any[]>([])

  const submit = async () => {
    try {
      const payload: any = {
        ...form,
        cellId: user?.member?.cellId,
        capacity: form.capacity ? parseInt(form.capacity) : null,
        startDate: new Date(form.startDate + 'T' + form.startTime),
        endDate: form.endDate ? new Date(form.endDate + 'T' + form.endTime) : null,
        registrationDeadline: form.registrationDeadline ? new Date(form.registrationDeadline) : null,
        registrationFields: form.registrationRequired ? fields : [],
      }
      await api('/api/events', { method: 'POST', body: JSON.stringify(payload) })
      toast({ title: 'Event created!' })
      onOpenChange(false)
      onCreated()
      setForm({ name: '', description: '', eventType: 'WEEKLY_CELL_MEETING', startDate: '', endDate: '', startTime: '16:00', endTime: '18:00', venue: '', address: '', capacity: '', registrationRequired: false, registrationDeadline: '', isPublic: false, accessRule: 'MEMBERS_ONLY', enablePin: true, enableQr: true, enableGeolocation: false, geoRadiusMeters: 100 })
      setFields([])
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  const addField = () => setFields([...fields, { label: '', fieldKey: `field_${fields.length}`, fieldType: 'TEXT', required: false, order: fields.length }])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Create Event</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label>Event Name *</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g., Vanguard Cell Saturday Meeting" />
          </div>
          <div>
            <Label>Description</Label>
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Event Type</Label>
              <Select value={form.eventType} onValueChange={(v) => setForm({ ...form, eventType: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{EVENT_TYPES.map((t) => <SelectItem key={t} value={t}>{t.replace(/_/g, ' ').toLowerCase()}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Capacity</Label>
              <Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Start Date *</Label>
              <Input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
            </div>
            <div>
              <Label>Start Time</Label>
              <Input type="time" value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Venue</Label><Input value={form.venue} onChange={(e) => setForm({ ...form, venue: e.target.value })} /></div>
            <div><Label>Address</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
          </div>
          <div className="space-y-2 p-3 bg-muted/30 rounded-lg">
            <div className="flex items-center justify-between">
              <Label>Registration Required</Label>
              <Switch checked={form.registrationRequired} onCheckedChange={(v) => setForm({ ...form, registrationRequired: v })} />
            </div>
            <div className="flex items-center justify-between">
              <Label>Public Event</Label>
              <Switch checked={form.isPublic} onCheckedChange={(v) => setForm({ ...form, isPublic: v })} />
            </div>
            <div className="flex items-center justify-between">
              <Label>Enable PIN Check-in</Label>
              <Switch checked={form.enablePin} onCheckedChange={(v) => setForm({ ...form, enablePin: v })} />
            </div>
            <div className="flex items-center justify-between">
              <Label>Enable QR Check-in</Label>
              <Switch checked={form.enableQr} onCheckedChange={(v) => setForm({ ...form, enableQr: v })} />
            </div>
            <div>
              <Label>Access Rule</Label>
              <Select value={form.accessRule} onValueChange={(v) => setForm({ ...form, accessRule: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ANYONE">Anyone</SelectItem>
                  <SelectItem value="MEMBERS_ONLY">Members Only</SelectItem>
                  <SelectItem value="WORKERS_ONLY">Workers Only</SelectItem>
                  <SelectItem value="LEADERS_ONLY">Leaders Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          {form.registrationRequired && (
            <div className="p-3 bg-amber-50/50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <Label className="font-semibold">Registration Fields</Label>
                <Button size="sm" variant="outline" onClick={addField}><Plus className="h-3 w-3 mr-1" /> Add Field</Button>
              </div>
              {fields.map((f, i) => (
                <div key={i} className="grid grid-cols-12 gap-2">
                  <Input className="col-span-5" placeholder="Label" value={f.label} onChange={(e) => { const arr = [...fields]; arr[i].label = e.target.value; setFields(arr) }} />
                  <Select value={f.fieldType} onValueChange={(v) => { const arr = [...fields]; arr[i].fieldType = v; setFields(arr) }}>
                    <SelectTrigger className="col-span-4"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="TEXT">Text</SelectItem>
                      <SelectItem value="TEXTAREA">Long Text</SelectItem>
                      <SelectItem value="EMAIL">Email</SelectItem>
                      <SelectItem value="PHONE">Phone</SelectItem>
                      <SelectItem value="NUMBER">Number</SelectItem>
                      <SelectItem value="DATE">Date</SelectItem>
                      <SelectItem value="SELECT">Dropdown</SelectItem>
                      <SelectItem value="RADIO">Radio</SelectItem>
                      <SelectItem value="CHECKBOX">Checkbox</SelectItem>
                      <SelectItem value="CONSENT">Consent</SelectItem>
                    </SelectContent>
                  </Select>
                  <label className="col-span-2 flex items-center gap-1 text-xs">
                    <input type="checkbox" checked={f.required} onChange={(e) => { const arr = [...fields]; arr[i].required = e.target.checked; setFields(arr) }} /> Req
                  </label>
                  <Button size="icon" variant="ghost" className="col-span-1" onClick={() => setFields(fields.filter((_, idx) => idx !== i))}><X className="h-3 w-3" /></Button>
                </div>
              ))}
              <p className="text-xs text-muted-foreground">Note: name, phone, and email fields are added automatically.</p>
            </div>
          )}
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit} className="bg-[#0B2A5B] hover:bg-[#123F8C]">Create Event</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function EventDetailDialog({ event, onClose, onTakeAttendance }: any) {
  const [detail, setDetail] = useState<any>(null)
  const [qrToken, setQrToken] = useState<string | null>(null)
  const [pin, setPin] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    api(`/api/events/${event.id}`).then((d) => setDetail(d.event))
  }, [event.id])

  const generateQR = async () => {
    try {
      const data = await api('/api/scan', { method: 'POST', body: JSON.stringify({ eventId: event.id }) })
      setQrToken(data.token)
      setPin(data.pin)
      toast({ title: 'QR + PIN generated', description: `PIN: ${data.pin} (expires in 5 min)` })
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  // Simple QR visual using QRServer API (or render a placeholder)
  const qrUrl = qrToken ? `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrToken)}` : null

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{event.name}</DialogTitle></DialogHeader>
        {detail && (
          <div className="space-y-4">
            {detail.description && <p className="text-sm text-muted-foreground">{detail.description}</p>}
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2"><Calendar className="h-4 w-4 text-muted-foreground" /> {new Date(detail.startDate).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>
              <div className="flex items-center gap-2"><Clock className="h-4 w-4 text-muted-foreground" /> {detail.startTime} - {detail.endTime}</div>
              {detail.venue && <div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-muted-foreground" /> {detail.venue}</div>}
              {detail.address && <div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-muted-foreground" /> {detail.address}</div>}
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" style={{ color: STATUS_COLORS[detail.status], borderColor: STATUS_COLORS[detail.status] + '40' }}>{detail.status.replace(/_/g, ' ').toLowerCase()}</Badge>
              {detail.registrationRequired && <Badge variant="ghost"><Ticket className="h-3 w-3 mr-1" /> Registration required</Badge>}
              {detail.capacity && <Badge variant="ghost"><Users className="h-3 w-3 mr-1" /> Cap: {detail.capacity}</Badge>}
              {detail.enablePin && <Badge variant="ghost">PIN enabled</Badge>}
              {detail.enableQr && <Badge variant="ghost"><QrCode className="h-3 w-3 mr-1" /> QR enabled</Badge>}
            </div>
            {detail.registrationFields?.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold mb-2">Registration Form Fields</h4>
                <div className="space-y-1">
                  {detail.registrationFields.map((f: any) => (
                    <div key={f.id} className="text-xs flex items-center justify-between p-1.5 bg-muted/20 rounded">
                      <span>{f.label}</span>
                      <span className="text-muted-foreground">{f.fieldType}{f.required ? ' *' : ''}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="flex gap-2 flex-wrap">
              <Button onClick={onTakeAttendance} className="bg-[#0B2A5B] hover:bg-[#123F8C]">
                <Calendar className="h-4 w-4 mr-1" /> Open Live Event Mode
              </Button>
              {detail.enableQr && (
                <Button variant="outline" onClick={generateQR}>
                  <QrCode className="h-4 w-4 mr-1" /> Generate QR/PIN
                </Button>
              )}
            </div>
            {qrUrl && (
              <div className="flex flex-col items-center p-4 bg-muted/30 rounded-lg">
                <img src={qrUrl} alt="Event QR Code" className="w-48 h-48 rounded-lg bg-white p-2" />
                <p className="text-xs text-muted-foreground mt-2">Scan to check in · PIN: <span className="font-bold text-[#0B2A5B]">{pin}</span></p>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

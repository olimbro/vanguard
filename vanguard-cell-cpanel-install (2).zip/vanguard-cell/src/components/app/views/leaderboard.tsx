'use client'
import { useEffect, useState } from 'react'
import { api } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Trophy, Medal, Flame } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

export function LeaderboardView() {
  const [period, setPeriod] = useState<'WEEKLY' | 'MONTHLY' | 'QUARTERLY' | 'ALL_TIME'>('MONTHLY')
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    api(`/api/leaderboard?period=${period}`).then((d) => {
      setData(d.leaderboard || [])
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [period])

  const medalColor = (i: number) => i === 0 ? '#D4AF37' : i === 1 ? '#9CA3AF' : i === 2 ? '#CD7F32' : '#0B2A5B'

  return (
    <div className="space-y-4">
      <Card className="border-0 bg-gradient-to-r from-[#0B2A5B] to-[#123F8C] text-white">
        <CardContent className="p-6">
          <Trophy className="h-8 w-8 text-[#E7B93E] mb-2" />
          <h2 className="text-xl font-bold">Leaderboard</h2>
          <p className="text-white/80 text-sm mt-1">Rankings measure recorded participation and engagement only. They do not measure spirituality, salvation, spiritual maturity or personal worth.</p>
        </CardContent>
      </Card>

      <Tabs value={period} onValueChange={(v) => setPeriod(v as any)}>
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="WEEKLY">Weekly</TabsTrigger>
          <TabsTrigger value="MONTHLY">Monthly</TabsTrigger>
          <TabsTrigger value="QUARTERLY">Quarterly</TabsTrigger>
          <TabsTrigger value="ALL_TIME">All-Time</TabsTrigger>
        </TabsList>
      </Tabs>

      {loading ? (
        <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-16 bg-muted/30 rounded-xl animate-pulse" />)}</div>
      ) : data.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">No data for this period yet.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {data.map((m, i) => (
            <Card key={m.memberId} className={`premium-card ${i < 3 ? 'border-l-4' : ''}`} style={{ borderLeftColor: i < 3 ? medalColor(i) : 'transparent' }}>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0" style={{ backgroundColor: medalColor(i) + '20', color: medalColor(i) }}>
                  {i < 3 ? <Medal className="h-5 w-5" /> : i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold truncate">{m.name}</div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">{m.rankIcon} {m.rankName}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-[#D4AF37]">{m.points}</div>
                  <div className="text-xs text-muted-foreground">points</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

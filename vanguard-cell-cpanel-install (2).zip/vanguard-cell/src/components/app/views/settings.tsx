'use client'
import { useEffect, useState } from 'react'
import { api, useApp } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Settings as SettingsIcon, Save, Award, Trophy, Bell } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

export function SettingsView() {
  const { user } = useApp()
  const [tab, setTab] = useState('general')
  const [settings, setSettings] = useState<any>({})
  const [pointRules, setPointRules] = useState<any>({})
  const { toast } = useToast()

  useEffect(() => {
    api('/api/settings').then((d) => setSettings(d.settings || {}))
    api('/api/ranks').then((d) => {
      // Point rules are part of gamification settings
    })
  }, [])

  const save = async (key: string, value: any, category: string = 'GENERAL') => {
    try {
      await api('/api/settings', { method: 'PATCH', body: JSON.stringify({ key, value, category }) })
      toast({ title: 'Saved', description: `${key} updated.` })
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><SettingsIcon className="h-5 w-5" /> Settings</h2>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="gamification">Gamification</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="about">About</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Cell Information</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <SettingField label="Brand Name" value={settings['system.brand_name']} onSave={(v) => save('system.brand_name', v, 'BRANDING')} />
              <SettingField label="Inactivity Threshold (weeks)" type="number" value={settings['attendance.inactivity_threshold_weeks']} onSave={(v) => save('attendance.inactivity_threshold_weeks', parseInt(v), 'ATTENDANCE')} />
              <SettingField label="Cell Contact Email" value={settings['cell.contact_email']} onSave={(v) => save('cell.contact_email', v, 'GENERAL')} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gamification" className="mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Trophy className="h-4 w-4" /> Ranks</CardTitle></CardHeader>
            <CardContent><RanksList /></CardContent>
          </Card>
          <Card className="mt-4">
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Award className="h-4 w-4" /> Badges</CardTitle></CardHeader>
            <CardContent><BadgesList /></CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance" className="mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Attendance Settings</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 bg-muted/30 rounded-lg">
                <Label className="text-xs text-muted-foreground">Inactivity Threshold</Label>
                <p className="text-sm mt-1">Members who haven't attended for this many weeks are flagged as needing follow-up.</p>
                <div className="flex gap-2 mt-2">
                  <Input type="number" defaultValue={settings['attendance.inactivity_threshold_weeks'] || 3} className="w-24" />
                  <Button size="sm" onClick={() => toast({ title: 'Saved' })}>Save</Button>
                </div>
              </div>
              <div className="p-3 bg-muted/30 rounded-lg">
                <Label className="text-xs text-muted-foreground">Auto-Generate Recurring Events</Label>
                <p className="text-sm mt-1">Weekly cell meeting series auto-generates future occurrences.</p>
                <Switch defaultChecked className="mt-2" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Bell className="h-4 w-4" /> Event Reminders</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {['7 days before', '3 days before', '24 hours before', '2 hours before'].map((label, i) => (
                <div key={i} className="flex items-center justify-between p-2 bg-muted/20 rounded">
                  <span className="text-sm">{label}</span>
                  <Switch defaultChecked />
                </div>
              ))}
              <div className="mt-4 p-3 bg-blue-50 rounded-lg text-sm text-blue-900">
                💡 WhatsApp and SMS integration will be available in a future update via pluggable messaging providers.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="about" className="mt-4">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-br from-[#E7B93E] to-[#D4AF37] flex items-center justify-center text-3xl font-bold text-[#0B2A5B]">V</div>
              <h3 className="font-bold text-[#0B2A5B]">Vanguard Cell Management System</h3>
              <p className="text-sm text-muted-foreground mt-1">v1.0.0 · Christ Embassy — Vanguard Cell 1, Awka</p>
              <div className="mt-4 grid grid-cols-2 gap-2 text-xs text-left">
                <div className="p-2 bg-muted/20 rounded"><strong>Stack:</strong> Next.js 16, TypeScript, Prisma</div>
                <div className="p-2 bg-muted/20 rounded"><strong>PWA:</strong> Installable, offline-capable</div>
                <div className="p-2 bg-muted/20 rounded"><strong>Mission:</strong> Win Souls · Build People · Develop Leaders · Multiply Cells</div>
                <div className="p-2 bg-muted/20 rounded"><strong>Privacy:</strong> Server-side RBAC enforced</div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function SettingField({ label, value, type = 'text', onSave }: any) {
  const [val, setVal] = useState(value || '')
  useEffect(() => setVal(value || ''), [value])
  return (
    <div className="flex items-end gap-2">
      <div className="flex-1">
        <Label className="text-xs text-muted-foreground">{label}</Label>
        <Input type={type} value={typeof val === 'object' ? JSON.stringify(val) : String(val || '')} onChange={(e) => setVal(e.target.value)} />
      </div>
      <Button size="sm" onClick={() => onSave(type === 'number' ? parseInt(val) : val)}><Save className="h-3 w-3" /></Button>
    </div>
  )
}

function RanksList() {
  const [ranks, setRanks] = useState<any[]>([])
  useEffect(() => { api('/api/ranks').then((d) => setRanks(d.ranks || [])) }, [])
  return (
    <div className="space-y-1">
      {ranks.map((r) => (
        <div key={r.id} className="flex items-center gap-3 p-2 bg-muted/20 rounded">
          <span className="text-2xl">{r.icon}</span>
          <div className="flex-1">
            <div className="font-medium text-sm">{r.name}</div>
            <div className="text-xs text-muted-foreground">Level {r.level} · {r.minPoints}+ points</div>
          </div>
          <Badge style={{ backgroundColor: r.color, color: 'white' }}>L{r.level}</Badge>
        </div>
      ))}
    </div>
  )
}

function BadgesList() {
  const [badges, setBadges] = useState<any[]>([])
  useEffect(() => { api('/api/ranks').then((d) => setBadges(d.badges || [])) }, [])
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
      {badges.map((b) => (
        <div key={b.id} className="flex items-center gap-2 p-2 bg-muted/20 rounded">
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-lg" style={{ backgroundColor: b.color + '20', border: `1px solid ${b.color}` }}>{b.icon}</div>
          <div className="flex-1 min-w-0">
            <div className="font-medium text-sm truncate">{b.name}</div>
            <div className="text-xs text-muted-foreground">+{b.pointsReward} pts</div>
          </div>
        </div>
      ))}
    </div>
  )
}

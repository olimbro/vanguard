'use client'
import { useEffect, useState } from 'react'
import { api } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Shield, Search } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

export function AuditView() {
  const [logs, setLogs] = useState<any[]>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api('/api/audit?limit=200').then((d) => {
      setLogs(d.logs || [])
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  const filtered = logs.filter((l) =>
    !search || l.action.toLowerCase().includes(search.toLowerCase()) ||
    l.objectType.toLowerCase().includes(search.toLowerCase()) ||
    l.actor?.name?.toLowerCase().includes(search.toLowerCase())
  )

  const actionColor: Record<string, string> = {
    CREATE: '#22C55E', UPDATE: '#0EA5E9', DELETE: '#EF4444', LOGIN: '#9CA3AF', LOGOUT: '#9CA3AF', SYNC: '#D4AF37', CONVERT: '#7C3AED', CANCEL: '#F97316',
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><Shield className="h-5 w-5" /> Audit Log</h2>
      <div className="relative">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search by action, object, or actor..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
      </div>
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-8 text-center text-muted-foreground">Loading audit logs...</div>
          ) : filtered.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">No logs found.</div>
          ) : (
            <div className="max-h-[70vh] overflow-y-auto scrollbar-thin">
              {filtered.map((l) => (
                <div key={l.id} className="flex items-center gap-3 p-3 border-b last:border-0 hover:bg-muted/30">
                  <Badge variant="outline" style={{ color: actionColor[l.action], borderColor: actionColor[l.action] + '40' }}>{l.action}</Badge>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm">
                      <span className="font-medium">{l.actor?.name || 'System'}</span>
                      <span className="text-muted-foreground"> · {l.action.toLowerCase()} · {l.objectType}</span>
                      {l.objectId && <span className="text-muted-foreground text-xs"> · {l.objectId.slice(-8)}</span>}
                    </div>
                    <div className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(l.createdAt), { addSuffix: true })} · {l.ipAddress || 'no IP'}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

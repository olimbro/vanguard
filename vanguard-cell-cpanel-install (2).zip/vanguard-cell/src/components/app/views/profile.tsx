'use client'
import { useEffect, useState } from 'react'
import { api, useApp } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { User, Mail, Phone, Save, LogOut } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

export function ProfileView() {
  const { user, setUser } = useApp()
  const [form, setForm] = useState({ name: user?.name || '', phone: user?.phone || '', preferredName: user?.member?.preferredName || '' })
  const { toast } = useToast()

  const logout = async () => {
    await api('/api/auth/logout', { method: 'POST' })
    window.location.reload()
  }

  const save = async () => {
    try {
      // Update user details via members endpoint if member exists
      if (user?.member?.id) {
        await api(`/api/members/${user.member.id}`, {
          method: 'PATCH',
          body: JSON.stringify({ preferredName: form.preferredName, fullName: form.name }),
        })
      }
      toast({ title: 'Profile updated' })
      // Refresh
      const data = await api('/api/auth/me')
      setUser(data.user)
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  const initials = user?.name?.split(' ').map((n: string) => n[0]).slice(0, 2).join('') || 'U'

  return (
    <div className="space-y-4 max-w-2xl">
      <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><User className="h-5 w-5" /> Profile</h2>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <Avatar className="h-20 w-20">
              <AvatarFallback className="bg-gradient-to-br from-[#0B2A5B] to-[#123F8C] text-white text-2xl">{initials}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-bold text-lg">{user?.name}</h3>
              <Badge variant="outline" className="mt-1">{user?.role.replace(/_/g, ' ').toLowerCase()}</Badge>
              {user?.member?.rank && (
                <div className="mt-1 text-sm text-muted-foreground">{user.member.rank.icon} {user.member.rank.name}</div>
              )}
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <Label>Full Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <Label>Preferred Name</Label>
              <Input value={form.preferredName} onChange={(e) => setForm({ ...form, preferredName: e.target.value })} />
            </div>
            <div>
              <Label>Email</Label>
              <Input value={user?.email || ''} disabled className="bg-muted/30" />
              <p className="text-xs text-muted-foreground mt-1">Email cannot be changed.</p>
            </div>
            <div>
              <Label>Phone</Label>
              <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
          </div>

          {user?.member && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 pt-4 border-t">
              <div className="text-center p-2 bg-muted/20 rounded">
                <div className="text-xs text-muted-foreground">Points</div>
                <div className="text-lg font-bold text-[#D4AF37]">{user.member.points}</div>
              </div>
              <div className="text-center p-2 bg-muted/20 rounded">
                <div className="text-xs text-muted-foreground">Streak</div>
                <div className="text-lg font-bold">🔥 {user.member.streak}</div>
              </div>
              <div className="text-center p-2 bg-muted/20 rounded">
                <div className="text-xs text-muted-foreground">Attendance</div>
                <div className="text-lg font-bold">{Math.round(user.member.attendancePct)}%</div>
              </div>
              <div className="text-center p-2 bg-muted/20 rounded">
                <div className="text-xs text-muted-foreground">Engagement</div>
                <div className="text-lg font-bold">{Math.round(user.member.engagementScore)}%</div>
              </div>
            </div>
          )}

          <div className="flex justify-between gap-2 mt-6">
            <Button variant="outline" onClick={logout} className="text-red-600"><LogOut className="h-4 w-4 mr-1" /> Sign Out</Button>
            <Button onClick={save} className="bg-[#0B2A5B] hover:bg-[#123F8C]"><Save className="h-4 w-4 mr-1" /> Save Changes</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Privacy & Data</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex items-center justify-between p-2 bg-muted/20 rounded">
            <span>Notification preferences</span>
            <Button size="sm" variant="ghost">Manage</Button>
          </div>
          <div className="flex items-center justify-between p-2 bg-muted/20 rounded">
            <span>Export my data</span>
            <Button size="sm" variant="ghost">Request</Button>
          </div>
          <div className="flex items-center justify-between p-2 bg-red-50 rounded">
            <span className="text-red-700">Delete my account</span>
            <Button size="sm" variant="ghost" className="text-red-600">Request</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

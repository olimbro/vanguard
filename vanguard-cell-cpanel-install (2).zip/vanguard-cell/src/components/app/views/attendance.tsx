'use client'
import { useEffect, useState, useRef } from 'react'
import { useApp, api, queueOfflineAttendance, getOfflineQueue } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ClipboardCheck, QrCode, KeyRound, Search, Check, WifiOff, RefreshCw, X, Users, ScanLine } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

const STATUS_OPTIONS = [
  { value: 'PRESENT', label: 'Present', color: '#22C55E' },
  { value: 'LATE', label: 'Late', color: '#F97316' },
  { value: 'ABSENT', label: 'Absent', color: '#EF4444' },
  { value: 'EXCUSED', label: 'Excused', color: '#9CA3AF' },
  { value: 'VISITOR', label: 'Visitor', color: '#A855F7' },
]

export function AttendanceView() {
  const { user, selectedEventId, setView, pendingSyncCount, setPendingSyncCount } = useApp()
  const [events, setEvents] = useState<any[]>([])
  const [activeEventId, setActiveEventId] = useState<string | null>(selectedEventId)
  const [liveData, setLiveData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [mode, setMode] = useState<'live' | 'manual' | 'pin' | 'qr' | 'scan'>('live')
  const [search, setSearch] = useState('')
  const { toast } = useToast()

  const isAdmin = ['SUPER_ADMIN', 'CELL_ADMIN', 'ASSISTANT', 'WORKER'].includes(user?.role || '')

  useEffect(() => {
    api('/api/events?upcoming=true&limit=20').then((d) => {
      // Also include today's events
      const today = new Date().setHours(0, 0, 0, 0)
      const sorted = [...(d.events || [])].sort((a, b) => Math.abs(new Date(a.startDate).getTime() - Date.now()) - Math.abs(new Date(b.startDate).getTime() - Date.now()))
      setEvents(sorted)
      setLoading(false)
      // Auto-select closest event if not set
      if (!activeEventId && sorted.length > 0) {
        setActiveEventId(sorted[0].id)
      }
    }).catch(() => setLoading(false))
  }, [])

  const loadLive = async () => {
    if (!activeEventId) return
    try {
      const data = await api(`/api/events/${activeEventId}/live`)
      setLiveData(data)
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  useEffect(() => {
    if (activeEventId && isAdmin) loadLive()
  }, [activeEventId])

  // For members: show check-in screen
  if (!isAdmin) {
    return <MemberCheckIn events={events} />
  }

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading events...</div>

  return (
    <div className="space-y-4">
      {/* Event selector */}
      <Card>
        <CardContent className="p-4">
          <Label className="text-xs text-muted-foreground">Active Event</Label>
          <Select value={activeEventId || ''} onValueChange={setActiveEventId}>
            <SelectTrigger className="mt-1"><SelectValue placeholder="Select event" /></SelectTrigger>
            <SelectContent>
              {events.map((e) => (
                <SelectItem key={e.id} value={e.id}>
                  {e.name} · {new Date(e.startDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })} {e.startTime}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {!activeEventId ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">Select an event to take attendance.</CardContent></Card>
      ) : (
        <>
          {/* Live stats */}
          {liveData && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <StatBox label="Registered" value={liveData.stats.registered} icon={Users} color="#0B2A5B" />
              <StatBox label="Attended" value={liveData.stats.attended} icon={Check} color="#22C55E" />
              <StatBox label="Remaining" value={liveData.stats.remaining ?? '—'} icon={ClipboardCheck} color="#D4AF37" />
              <StatBox label="Attendance %" value={`${liveData.stats.attendancePct}%`} icon={ClipboardCheck} color="#123F8C" />
              <StatBox label="Total Members" value={liveData.stats.total} icon={Users} color="#0EA5E9" />
            </div>
          )}

          {/* Tabs */}
          <Tabs value={mode} onValueChange={(v) => setMode(v as any)}>
            <TabsList className="grid grid-cols-4 w-full">
              <TabsTrigger value="live"><ClipboardCheck className="h-4 w-4 mr-1" /> Manual</TabsTrigger>
              <TabsTrigger value="qr"><QrCode className="h-4 w-4 mr-1" /> QR Code</TabsTrigger>
              <TabsTrigger value="pin"><KeyRound className="h-4 w-4 mr-1" /> PIN</TabsTrigger>
              <TabsTrigger value="scan"><ScanLine className="h-4 w-4 mr-1" /> Lookup</TabsTrigger>
            </TabsList>

            <TabsContent value="live" className="mt-4">
              <ManualAttendance liveData={liveData} search={search} setSearch={setSearch} onMarked={loadLive} />
            </TabsContent>
            <TabsContent value="qr" className="mt-4">
              <QRDisplay eventId={activeEventId} />
            </TabsContent>
            <TabsContent value="pin" className="mt-4">
              <PINDisplay eventId={activeEventId} />
            </TabsContent>
            <TabsContent value="scan" className="mt-4">
              <RegistrationLookup eventId={activeEventId} onUpdated={loadLive} />
            </TabsContent>
          </Tabs>

          {/* Recent check-ins */}
          {liveData?.recentCheckIns?.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">Recent Check-ins</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-1 max-h-60 overflow-y-auto scrollbar-thin">
                  {liveData.recentCheckIns.map((r: any) => (
                    <div key={r.id} className="flex items-center justify-between text-sm p-2 bg-muted/20 rounded">
                      <span className="font-medium">{r.member?.fullName}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{r.status}</Badge>
                        <span className="text-xs text-muted-foreground">{r.method}</span>
                        <span className="text-xs text-muted-foreground">{new Date(r.checkInTime).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  )
}

function StatBox({ label, value, icon: Icon, color }: any) {
  return (
    <Card><CardContent className="p-3">
      <div className="flex items-center gap-1.5 mb-1">
        <Icon className="h-3 w-3" style={{ color }} />
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <div className="text-xl font-bold" style={{ color }}>{value}</div>
    </CardContent></Card>
  )
}

function ManualAttendance({ liveData, search, setSearch, onMarked }: any) {
  const { user } = useApp()
  const [marking, setMarking] = useState<string | null>(null)
  const { toast } = useToast()

  if (!liveData) return <div className="text-center text-muted-foreground py-8">Loading...</div>

  const members = liveData.members || []
  const filtered = members.filter((m: any) =>
    m.name.toLowerCase().includes(search.toLowerCase()) || m.preferredName?.toLowerCase().includes(search.toLowerCase())
  )

  const markAttendance = async (memberId: string, status: string) => {
    setMarking(memberId)
    try {
      const isOnline = navigator.onLine
      if (isOnline) {
        await api('/api/attendance', {
          method: 'POST',
          body: JSON.stringify({
            eventId: liveData.event.id,
            memberId,
            status,
            method: 'MANUAL',
          }),
        })
      } else {
        // Queue offline
        const offlineUuid = crypto.randomUUID()
        await queueOfflineAttendance({
          offlineUuid,
          eventId: liveData.event.id,
          memberId,
          status,
          method: 'OFFLINE',
          checkInTime: new Date().toISOString(),
          deviceIdentifier: navigator.userAgent,
        })
        useApp.getState().setPendingSyncCount((await getOfflineQueue()).length)
        toast({ title: 'Queued offline', description: 'Will sync when back online.' })
      }
      toast({ title: 'Attendance recorded', description: `${status}` })
      onMarked()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setMarking(null)
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="relative mb-3">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search members..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="space-y-2 max-h-[60vh] overflow-y-auto scrollbar-thin">
          {filtered.map((m: any) => {
            const attendance = m.attendance
            return (
              <div key={m.id} className="flex items-center gap-3 p-2 rounded-lg bg-muted/20 hover:bg-muted/40">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#0B2A5B] to-[#123F8C] text-white flex items-center justify-center text-xs font-bold shrink-0">
                  {m.name.split(' ').map((n: string) => n[0]).slice(0, 2).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{m.name}</div>
                  <div className="text-xs text-muted-foreground">{m.status.replace(/_/g, ' ').toLowerCase()}</div>
                </div>
                {attendance ? (
                  <Badge variant="outline" style={{ color: STATUS_OPTIONS.find((s) => s.value === attendance.status)?.color }}>{attendance.status}</Badge>
                ) : (
                  <div className="flex gap-1">
                    {STATUS_OPTIONS.slice(0, 3).map((s) => (
                      <Button
                        key={s.value}
                        size="sm"
                        variant="outline"
                        disabled={marking === m.id}
                        onClick={() => markAttendance(m.id, s.value)}
                        className="h-8 px-2 text-xs"
                        style={{ borderColor: s.color + '40', color: s.color }}
                      >
                        {s.label}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            )
          })}
          {filtered.length === 0 && <div className="text-center text-muted-foreground py-4 text-sm">No members match.</div>}
        </div>
      </CardContent>
    </Card>
  )
}

function QRDisplay({ eventId }: { eventId: string }) {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const generate = async () => {
    setLoading(true)
    try {
      const d = await api('/api/scan', { method: 'POST', body: JSON.stringify({ eventId }) })
      setData(d)
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { generate() }, [eventId])

  if (!data) return <div className="text-center py-8 text-muted-foreground">Generating QR code...</div>

  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(data.token)}`

  return (
    <Card>
      <CardContent className="p-6 flex flex-col items-center">
        <div className="text-center mb-3">
          <h3 className="font-bold text-[#0B2A5B]">{data.eventName}</h3>
          <p className="text-xs text-muted-foreground">Display this QR for members to scan and check in</p>
        </div>
        <div className="bg-white p-3 rounded-2xl shadow-lg">
          <img src={qrUrl} alt="Event QR" className="w-64 h-64" />
        </div>
        <div className="mt-3 flex items-center gap-2">
          <Badge className="bg-[#0B2A5B]">PIN: {data.pin}</Badge>
          <Badge variant="outline">Expires in 5 min</Badge>
        </div>
        <Button variant="outline" size="sm" onClick={generate} disabled={loading} className="mt-3">
          <RefreshCw className="h-3 w-3 mr-1" /> Refresh
        </Button>
      </CardContent>
    </Card>
  )
}

function PINDisplay({ eventId }: { eventId: string }) {
  const [pin, setPin] = useState<string | null>(null)
  const { toast } = useToast()

  const generate = async () => {
    try {
      const d = await api('/api/scan', { method: 'POST', body: JSON.stringify({ eventId }) })
      setPin(d.pin)
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  useEffect(() => { generate() }, [eventId])

  if (!pin) return <div className="text-center py-8 text-muted-foreground">Generating PIN...</div>

  return (
    <Card>
      <CardContent className="p-6 flex flex-col items-center">
        <KeyRound className="h-12 w-12 text-[#D4AF37] mb-3" />
        <h3 className="font-bold text-[#0B2A5B] mb-1">Event PIN</h3>
        <p className="text-xs text-muted-foreground text-center mb-4">Members enter this 4-digit PIN in their app to check in</p>
        <div className="text-6xl font-bold tracking-[0.3em] text-[#0B2A5B] bg-[#D4AF37]/10 px-8 py-4 rounded-2xl">{pin}</div>
      </CardContent>
    </Card>
  )
}

function RegistrationLookup({ eventId, onUpdated }: any) {
  const [query, setQuery] = useState('')
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const lookup = async () => {
    if (!query) return
    setLoading(true)
    try {
      const data = await api(`/api/registrations/${encodeURIComponent(query)}`)
      setResult(data.registration)
    } catch (e: any) {
      setResult(null)
      toast({ title: 'Not found', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const checkIn = async () => {
    if (!result) return
    try {
      await api(`/api/registrations/${result.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'ATTENDED' }),
      })
      toast({ title: 'Checked in!', description: `${result.guestName || result.user?.name} is now marked as attended.` })
      setResult(null)
      setQuery('')
      onUpdated()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <Card>
      <CardContent className="p-4">
        <Label>Look up by registration number or QR token</Label>
        <div className="flex gap-2 mt-1">
          <Input placeholder="e.g., VP-00042 or scan QR" value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && lookup()} />
          <Button onClick={lookup} disabled={loading}><Search className="h-4 w-4" /></Button>
        </div>
        {result && (
          <div className="mt-4 p-4 bg-muted/30 rounded-lg">
            <div className="flex items-start justify-between mb-2">
              <div>
                <div className="font-bold">{result.guestName || result.user?.name}</div>
                <div className="text-xs text-muted-foreground">#{result.registrationNumber}</div>
              </div>
              <Badge variant={result.status === 'ATTENDED' ? 'default' : 'outline'}>{result.status}</Badge>
            </div>
            {result.user?.email && <div className="text-sm text-muted-foreground">{result.user.email}</div>}
            {result.values?.length > 0 && (
              <div className="mt-2 space-y-1">
                {result.values.map((v: any) => (
                  <div key={v.id} className="text-xs flex justify-between"><span className="text-muted-foreground">{v.field?.label}:</span> <span>{v.value}</span></div>
                ))}
              </div>
            )}
            {result.status !== 'ATTENDED' && (
              <Button onClick={checkIn} className="mt-3 bg-[#22C55E] hover:bg-green-600 w-full">
                <Check className="h-4 w-4 mr-1" /> Check In
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function MemberCheckIn({ events }: { events: any[] }) {
  const [tab, setTab] = useState<'pin' | 'qr'>('pin')
  const [pin, setPin] = useState('')
  const [scanned, setScanned] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()
  const { user } = useApp()

  const checkInWithPin = async () => {
    if (!pin || pin.length !== 4) {
      toast({ title: 'Invalid PIN', description: 'Enter the 4-digit event PIN.', variant: 'destructive' })
      return
    }
    const event = events[0] // Use the most relevant upcoming event
    if (!event) {
      toast({ title: 'No active event', description: 'No event available for check-in.', variant: 'destructive' })
      return
    }
    setLoading(true)
    try {
      const result = await api('/api/checkin', {
        method: 'POST',
        body: JSON.stringify({ method: 'PIN', pin, eventId: event.id }),
      })
      setScanned(result)
      toast({ title: `Checked in: ${result.status}`, description: `+${result.points} points earned!` })
    } catch (e: any) {
      toast({ title: 'Check-in failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <Card className="border-0 bg-gradient-to-r from-[#0B2A5B] to-[#123F8C] text-white">
        <CardContent className="p-6">
          <h2 className="text-xl font-bold mb-1">Check In</h2>
          <p className="text-white/80 text-sm">Ask your cell leader for the event PIN, or scan the event QR code.</p>
        </CardContent>
      </Card>

      {events[0] && (
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Active event for check-in</div>
            <div className="font-bold text-[#0B2A5B]">{events[0].name}</div>
            <div className="text-sm text-muted-foreground">{new Date(events[0].startDate).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })} · {events[0].startTime}</div>
          </CardContent>
        </Card>
      )}

      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList className="grid grid-cols-2 w-full">
          <TabsTrigger value="pin"><KeyRound className="h-4 w-4 mr-1" /> PIN</TabsTrigger>
          <TabsTrigger value="qr"><QrCode className="h-4 w-4 mr-1" /> QR Scan</TabsTrigger>
        </TabsList>
        <TabsContent value="pin" className="mt-4">
          <Card>
            <CardContent className="p-6">
              <Label>Enter Event PIN</Label>
              <Input
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="0000"
                className="text-3xl text-center tracking-[0.5em] font-bold mt-1"
                inputMode="numeric"
              />
              <Button onClick={checkInWithPin} disabled={loading} className="w-full mt-4 bg-[#0B2A5B] hover:bg-[#123F8C]">
                {loading ? 'Checking in...' : 'Check In'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="qr" className="mt-4">
          <Card>
            <CardContent className="p-6 text-center">
              <QrCode className="h-20 w-20 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground mb-4">QR scanning requires a separate QR scanner app. Once you scan the event QR, the URL will trigger check-in automatically.</p>
              <p className="text-xs text-muted-foreground">Ask your cell leader to display the event QR code in Live Event Mode.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {scanned && (
        <Card className="border-2 border-[#22C55E]">
          <CardContent className="p-6 text-center">
            <Check className="h-12 w-12 text-[#22C55E] mx-auto mb-2" />
            <h3 className="font-bold text-lg text-[#22C55E]">Check-in Confirmed</h3>
            <p className="text-sm text-muted-foreground mt-1">Status: {scanned.status}</p>
            <p className="text-2xl font-bold text-[#D4AF37] mt-2">+{scanned.points} points</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

'use client'
import { useEffect, useState, useRef } from 'react'
import { api } from '@/lib/store'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { MessageSquare, Send } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { formatDistanceToNow } from 'date-fns'

export function MessagesView() {
  const [conversations, setConversations] = useState<any[]>([])
  const [active, setActive] = useState<any>(null)
  const [messages, setMessages] = useState<any[]>([])
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()
  const endRef = useRef<HTMLDivElement>(null)

  const loadConversations = async () => {
    try {
      const data = await api('/api/messages')
      setConversations(data.conversations || [])
      if (!active && data.conversations?.length > 0) setActive(data.conversations[0])
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const loadMessages = async () => {
    if (!active) return
    try {
      const data = await api(`/api/messages?conversationId=${active.id}`)
      setMessages(data.messages || [])
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), 100)
    } catch {}
  }

  useEffect(() => { loadConversations() }, [])
  useEffect(() => {
    if (active) {
      const interval = setInterval(loadMessages, 5000)
      loadMessages()
      return () => clearInterval(interval)
    }
  }, [active?.id])

  const send = async () => {
    if (!text.trim() || !active) return
    try {
      await api('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ conversationId: active.id, body: text }),
      })
      setText('')
      loadMessages()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading conversations...</div>

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><MessageSquare className="h-5 w-5" /> Messages</h2>
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Conversation list */}
        <Card className="lg:col-span-1">
          <CardContent className="p-3">
            <div className="space-y-1 max-h-[60vh] overflow-y-auto scrollbar-thin">
              {conversations.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setActive(c)}
                  className={`w-full text-left p-3 rounded-lg ${active?.id === c.id ? 'bg-[#0B2A5B] text-white' : 'hover:bg-muted'}`}
                >
                  <div className="font-semibold text-sm truncate">{c.name || c.cell?.name || 'Conversation'}</div>
                  {c.messages?.[0] && (
                    <div className={`text-xs truncate mt-0.5 ${active?.id === c.id ? 'text-white/70' : 'text-muted-foreground'}`}>
                      {c.messages[0].sender?.name}: {c.messages[0].body}
                    </div>
                  )}
                </button>
              ))}
              {conversations.length === 0 && <p className="text-sm text-muted-foreground p-3">No conversations.</p>}
            </div>
          </CardContent>
        </Card>

        {/* Chat area */}
        <Card className="lg:col-span-2 flex flex-col h-[60vh]">
          {active ? (
            <>
              <div className="p-3 border-b font-semibold text-sm">{active.name || active.cell?.name}</div>
              <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-thin">
                {messages.map((m) => (
                  <div key={m.id} className={`flex ${m.senderId === active?.participants?.[0]?.userId ? 'justify-start' : 'justify-end'}`}>
                    <div className={`max-w-[75%] p-2.5 rounded-lg ${m.sender?.name === 'You' ? 'bg-[#0B2A5B] text-white' : 'bg-muted'}`}>
                      <div className="text-xs font-medium mb-0.5 opacity-70">{m.sender?.name}</div>
                      <div className="text-sm">{m.body}</div>
                      <div className="text-xs opacity-60 mt-0.5">{formatDistanceToNow(new Date(m.createdAt), { addSuffix: true })}</div>
                    </div>
                  </div>
                ))}
                <div ref={endRef} />
              </div>
              <div className="p-3 border-t flex gap-2">
                <Input
                  placeholder="Type a message..."
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && send()}
                />
                <Button onClick={send} className="bg-[#0B2A5B] hover:bg-[#123F8C]"><Send className="h-4 w-4" /></Button>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm">Select a conversation</div>
          )}
        </Card>
      </div>
    </div>
  )
}

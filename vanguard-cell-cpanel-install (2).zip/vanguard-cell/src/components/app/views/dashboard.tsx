'use client'
import { useEffect, useState } from 'react'
import { useApp, api } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Users, Calendar, Trophy, Flame, TrendingUp, AlertCircle, UserPlus, Megaphone, ClipboardCheck, FileText, Bell } from 'lucide-react'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { formatDistanceToNow } from 'date-fns'

export function DashboardView() {
  const { user, setView } = useApp()
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api('/api/dashboard').then((d) => {
      setData(d)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  if (loading) return <DashboardSkeleton />
  if (!data) return <div className="text-center text-muted-foreground py-12">Failed to load dashboard</div>

  if (data.type === 'member') return <MemberDashboard data={data} />
  return <AdminDashboard data={data} />
}

function AdminDashboard({ data }: { data: any }) {
  const { setView } = useApp()
  const cards = data.cards || {}
  const cell = data.cell

  return (
    <div className="space-y-6">
      {/* Welcome banner */}
      <Card className="border-0 bg-gradient-to-r from-[#0B2A5B] to-[#123F8C] text-white">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <p className="text-white/70 text-sm">{cell?.churchName || 'Christ Embassy'} · {cell?.name || 'Vanguard Cell 1'}</p>
              <h2 className="text-2xl font-bold mt-1">Welcome back, leader 👋</h2>
              <p className="text-white/80 text-sm mt-1">Weekly meeting: {cell?.meetingDay?.toLowerCase()?.charAt(0).toUpperCase() + cell?.meetingDay?.slice(1).toLowerCase()} at {cell?.meetingTime} · {cell?.venue}</p>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button size="sm" variant="secondary" className="bg-[#E7B93E] text-[#0B2A5B] hover:bg-[#D4AF37]" onClick={() => setView('attendance')}>
                <ClipboardCheck className="h-4 w-4 mr-1" /> Take Attendance
              </Button>
              <Button size="sm" variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20" onClick={() => setView('events')}>
                <Calendar className="h-4 w-4 mr-1" /> New Event
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Alerts */}
      {data.alerts?.length > 0 && (
        <div className="space-y-2">
          {data.alerts.map((a: any, i: number) => (
            <Card key={i} className="border-l-4" style={{ borderLeftColor: a.color === 'red' ? '#DC2626' : a.color === 'orange' ? '#F97316' : a.color === 'yellow' ? '#EAB308' : '#0EA5E9' }}>
              <CardContent className="p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span>{a.icon}</span>
                  <span className="text-sm font-medium">{a.text}</span>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setView(a.action === 'follow-up' || a.action === 'inactive' ? 'followup' : a.action === 'visitors' ? 'visitors' : a.action === 'registrations' ? 'events' : 'dashboard')}>
                  View
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <StatCard icon={Users} label="Members" value={cards.totalMembers} color="#0B2A5B" sub={`${cards.activeMembers} active`} />
        <StatCard icon={UserPlus} label="Visitors" value={cards.visitors} color="#0EA5E9" sub={`${cards.newMembers} new`} />
        <StatCard icon={Calendar} label="Events" value={cards.totalEvents} color="#123F8C" sub={`${cards.attendanceToday} today`} />
        <StatCard icon={Trophy} label="Attendance" value={`${cards.avgAttendancePct}%`} color="#D4AF37" sub={`${cards.attendanceThisWeek} this wk`} />
        <StatCard icon={AlertCircle} label="Follow-Up" value={cards.needingFollowUp} color="#DC2626" sub={`${cards.inactiveMembers} inactive`} />
        <StatCard icon={Flame} label="Engagement" value={`${cards.avgEngagement}%`} color="#22C55E" sub="cell avg" />
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Attendance Trend (8 weeks)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={data.attendanceTrend}>
                <XAxis dataKey="week" tick={{ fontSize: 10 }} tickFormatter={(v) => v.slice(5)} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Line type="monotone" dataKey="present" stroke="#0B2A5B" strokeWidth={2} name="Present" />
                <Line type="monotone" dataKey="total" stroke="#D4AF37" strokeWidth={2} name="Total" strokeDasharray="4 4" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Member Growth (6 months)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={data.memberGrowth}>
                <XAxis dataKey="month" tick={{ fontSize: 10 }} tickFormatter={(v) => v.slice(5)} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#123F8C" name="New Members" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Quick actions */}
      <Card>
        <CardHeader><CardTitle className="text-base">Quick Actions</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <Button variant="outline" onClick={() => setView('attendance')} className="justify-start"><ClipboardCheck className="h-4 w-4 mr-2" /> Take Attendance</Button>
            <Button variant="outline" onClick={() => setView('members')} className="justify-start"><Users className="h-4 w-4 mr-2" /> Add Member</Button>
            <Button variant="outline" onClick={() => setView('events')} className="justify-start"><Calendar className="h-4 w-4 mr-2" /> New Event</Button>
            <Button variant="outline" onClick={() => setView('announcements')} className="justify-start"><Megaphone className="h-4 w-4 mr-2" /> Announce</Button>
            <Button variant="outline" onClick={() => setView('reports')} className="justify-start"><FileText className="h-4 w-4 mr-2" /> Generate Report</Button>
            <Button variant="outline" onClick={() => setView('leaderboard')} className="justify-start"><Trophy className="h-4 w-4 mr-2" /> View Leaderboard</Button>
            <Button variant="outline" onClick={() => setView('followup')} className="justify-start"><AlertCircle className="h-4 w-4 mr-2" /> Follow-Up</Button>
            <Button variant="outline" onClick={() => setView('messages')} className="justify-start"><Megaphone className="h-4 w-4 mr-2" /> Messages</Button>
          </div>
        </CardContent>
      </Card>

      {/* Lists */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Members Needing Follow-Up</CardTitle></CardHeader>
          <CardContent>
            {data.followUpList?.length === 0 ? (
              <p className="text-sm text-muted-foreground">All caught up! No follow-ups needed.</p>
            ) : (
              <div className="space-y-2">
                {data.followUpList?.slice(0, 5).map((m: any) => (
                  <div key={m.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50">
                    <div>
                      <div className="font-medium text-sm">{m.name}</div>
                      <div className="text-xs text-muted-foreground">Last seen: {m.lastAttendance ? formatDistanceToNow(new Date(m.lastAttendance), { addSuffix: true }) : 'Never'}</div>
                    </div>
                    <Badge style={{ backgroundColor: m.engagementHealth.color, color: 'white' }}>{m.engagementHealth.label}</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Top Members</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {data.topMembers?.map((m: any) => (
                <div key={m.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{m.rankIcon}</span>
                    <div>
                      <div className="font-medium text-sm">#{m.rank} {m.name}</div>
                      <div className="text-xs text-muted-foreground">{m.rankName}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-sm text-[#D4AF37]">{m.points} pts</div>
                    <div className="text-xs text-muted-foreground">🔥 {m.streak}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent activity */}
      <Card>
        <CardHeader><CardTitle className="text-base">Recent Check-ins</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-72 overflow-y-auto scrollbar-thin">
            {data.recentAttendance?.length === 0 ? (
              <p className="text-sm text-muted-foreground">No recent attendance.</p>
            ) : data.recentAttendance?.map((r: any) => (
              <div key={r.id} className="flex items-center justify-between text-sm py-1.5 border-b last:border-0">
                <div>
                  <span className="font-medium">{r.member}</span>
                  <span className="text-muted-foreground"> · {r.event}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={r.status === 'PRESENT' ? 'default' : r.status === 'LATE' ? 'secondary' : 'outline'}>{r.status}</Badge>
                  <span className="text-xs text-muted-foreground">{r.method}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function MemberDashboard({ data }: { data: any }) {
  const { setView, user } = useApp()
  const m = data.member
  const cards = data.cards

  return (
    <div className="space-y-6">
      {/* Hero */}
      <Card className="border-0 bg-gradient-to-r from-[#0B2A5B] to-[#123F8C] text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/70 text-sm">Welcome back,</p>
              <h2 className="text-2xl font-bold">{m.preferredName || m.name} {m.rank?.icon && <span className="ml-2">{m.rank.icon}</span>}</h2>
              <p className="text-white/80 text-sm mt-1">{m.rank?.name} · {m.cellName}</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-[#E7B93E]">{m.points}</div>
              <div className="text-xs text-white/70">points</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Calendar} label="Events Attended" value={cards.eventsAttended} color="#0B2A5B" sub={`of ${cards.totalEvents}`} />
        <StatCard icon={Trophy} label="Attendance" value={`${cards.attendancePct}%`} color="#D4AF37" sub="personal rate" />
        <StatCard icon={Flame} label="Current Streak" value={`${cards.currentStreak}🔥`} color="#F97316" sub={`best: ${cards.longestStreak}`} />
        <StatCard icon={Bell} label="Badges" value={cards.badges} color="#22C55E" sub="earned" />
      </div>

      {/* Next meeting */}
      {data.nextMeeting && (
        <Card className="border-2 border-[#D4AF37]/30 bg-gradient-to-br from-amber-50 to-yellow-50/50">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="h-4 w-4 text-[#D4AF37]" />
              <span className="text-xs font-semibold text-[#D4AF37] uppercase tracking-wide">Next Meeting</span>
            </div>
            <h3 className="font-bold text-[#0B2A5B] text-lg">{data.nextMeeting.name}</h3>
            <p className="text-sm text-muted-foreground mt-1">
              {new Date(data.nextMeeting.startDate).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })} at {data.nextMeeting.startTime}
              {data.nextMeeting.venue && ` · ${data.nextMeeting.venue}`}
            </p>
            <Button className="mt-3 bg-[#0B2A5B] hover:bg-[#123F8C]" size="sm" onClick={() => setView('attendance')}>
              <ClipboardCheck className="h-4 w-4 mr-1" /> Check In
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Badges */}
      <Card>
        <CardHeader><CardTitle className="text-base">My Badges</CardTitle></CardHeader>
        <CardContent>
          {data.myBadges?.length === 0 ? (
            <p className="text-sm text-muted-foreground">No badges earned yet. Attend events to start earning!</p>
          ) : (
            <div className="flex flex-wrap gap-3">
              {data.myBadges?.map((b: any) => (
                <div key={b.id} className="flex flex-col items-center text-center w-20">
                  <div className="w-14 h-14 rounded-full flex items-center justify-center text-2xl" style={{ backgroundColor: b.color + '20', border: `2px solid ${b.color}` }}>
                    {b.icon}
                  </div>
                  <div className="text-xs font-medium mt-1">{b.name}</div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Challenges */}
      <Card>
        <CardHeader><CardTitle className="text-base">Active Challenges</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-3">
            {data.challenges?.map((c: any) => (
              <div key={c.id} className="p-3 rounded-lg bg-muted/30">
                <div className="flex items-center justify-between mb-1">
                  <div>
                    <div className="font-medium text-sm">{c.name}</div>
                    <div className="text-xs text-muted-foreground">{c.description}</div>
                  </div>
                  <Badge variant={c.completed ? 'default' : 'outline'} className={c.completed ? 'bg-[#22C55E]' : ''}>
                    {c.completed ? 'Done!' : `+${c.pointsReward} pts`}
                  </Badge>
                </div>
                <div className="w-full bg-muted h-2 rounded-full overflow-hidden">
                  <div className="h-full bg-[#D4AF37]" style={{ width: `${Math.min(100, (c.progress / c.goalValue) * 100)}%` }} />
                </div>
                <div className="text-xs text-muted-foreground mt-1">{c.progress} / {c.goalValue}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent activity */}
      <Card>
        <CardHeader><CardTitle className="text-base">Recent Activity</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-72 overflow-y-auto scrollbar-thin">
            {data.recentPoints?.map((p: any) => (
              <div key={p.id} className="flex items-center justify-between text-sm py-1.5 border-b last:border-0">
                <div>
                  <div className="font-medium">{p.description || p.reason}</div>
                  <div className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(p.when), { addSuffix: true })}</div>
                </div>
                <span className={`font-bold ${p.points > 0 ? 'text-[#22C55E]' : 'text-red-500'}`}>
                  {p.points > 0 ? '+' : ''}{p.points}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Announcements */}
      {data.announcements?.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Latest Announcements</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.announcements.slice(0, 3).map((a: any) => (
                <div key={a.id} className="p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center gap-2 mb-1">
                    {a.isPinned && <Badge className="bg-[#D4AF37] text-white text-xs">Pinned</Badge>}
                    <span className="font-medium text-sm">{a.title}</span>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">{a.body}</p>
                  <p className="text-xs text-muted-foreground mt-1">— {a.author}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function StatCard({ icon: Icon, label, value, color, sub }: any) {
  return (
    <Card className="premium-card">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ backgroundColor: color + '15' }}>
            <Icon className="h-3.5 w-3.5" style={{ color }} />
          </div>
          <span className="text-xs text-muted-foreground">{label}</span>
        </div>
        <div className="text-2xl font-bold" style={{ color }}>{value}</div>
        {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
      </CardContent>
    </Card>
  )
}

function DashboardSkeleton() {
  return (
    <div className="space-y-4">
      <div className="h-32 bg-muted/50 rounded-2xl animate-pulse" />
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {[...Array(6)].map((_, i) => <div key={i} className="h-24 bg-muted/30 rounded-xl animate-pulse" />)}
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="h-64 bg-muted/30 rounded-xl animate-pulse" />
        <div className="h-64 bg-muted/30 rounded-xl animate-pulse" />
      </div>
    </div>
  )
}

'use client'
import { useEffect, useState } from 'react'
import { api } from '@/lib/store'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ChevronLeft, ChevronRight, Calendar as CalIcon } from 'lucide-react'

const STATUS_COLORS: Record<string, string> = {
  DRAFT: '#9CA3AF', PUBLISHED: '#0EA5E9', REGISTRATION_OPEN: '#22C55E',
  REGISTRATION_CLOSED: '#F97316', ONGOING: '#D4AF37', COMPLETED: '#6B7280', CANCELLED: '#DC2626',
}

export function CalendarView() {
  const [events, setEvents] = useState<any[]>([])
  const [current, setCurrent] = useState(new Date())

  useEffect(() => {
    api('/api/events?limit=200').then((d) => setEvents(d.events || []))
  }, [])

  const year = current.getFullYear()
  const month = current.getMonth()
  const firstDay = new Date(year, month, 1)
  const lastDay = new Date(year, month + 1, 0)
  const startPad = (firstDay.getDay() + 6) % 7 // Mon-first
  const daysInMonth = lastDay.getDate()

  const today = new Date()
  const isToday = (d: number) => year === today.getFullYear() && month === today.getMonth() && d === today.getDate()
  const eventsOnDay = (d: number) => events.filter((e) => {
    const ed = new Date(e.startDate)
    return ed.getFullYear() === year && ed.getMonth() === month && ed.getDate() === d
  })

  const prev = () => setCurrent(new Date(year, month - 1, 1))
  const next = () => setCurrent(new Date(year, month + 1, 1))

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><CalIcon className="h-5 w-5" /> Calendar</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={prev}><ChevronLeft className="h-4 w-4" /></Button>
          <span className="font-semibold w-32 text-center">{current.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}</span>
          <Button variant="outline" size="icon" onClick={next}><ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
              <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-1">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: startPad }).map((_, i) => <div key={`pad-${i}`} />)}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1
              const dayEvents = eventsOnDay(day)
              const today_ = isToday(day)
              return (
                <div key={day} className={`min-h-16 p-1 rounded-lg border ${today_ ? 'border-[#D4AF37] bg-amber-50' : 'border-muted'}`}>
                  <div className={`text-xs ${today_ ? 'font-bold text-[#D4AF37]' : 'text-muted-foreground'}`}>{day}</div>
                  {dayEvents.slice(0, 2).map((e) => (
                    <div key={e.id} className="text-[10px] mt-0.5 p-1 rounded truncate" style={{ backgroundColor: (STATUS_COLORS[e.status] || '#9CA3AF') + '20', color: STATUS_COLORS[e.status] }}>
                      {e.startTime} {e.name}
                    </div>
                  ))}
                  {dayEvents.length > 2 && <div className="text-[10px] text-muted-foreground">+{dayEvents.length - 2} more</div>}
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h3 className="font-semibold text-sm mb-2">Upcoming Events</h3>
          <div className="space-y-1">
            {events.filter((e) => new Date(e.startDate) >= new Date()).slice(0, 5).map((e) => (
              <div key={e.id} className="flex items-center justify-between p-2 bg-muted/20 rounded text-sm">
                <div>
                  <div className="font-medium">{e.name}</div>
                  <div className="text-xs text-muted-foreground">{new Date(e.startDate).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })} · {e.startTime}</div>
                </div>
                <Badge variant="outline" style={{ color: STATUS_COLORS[e.status], borderColor: STATUS_COLORS[e.status] + '40' }}>{e.status.replace(/_/g, ' ').toLowerCase()}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

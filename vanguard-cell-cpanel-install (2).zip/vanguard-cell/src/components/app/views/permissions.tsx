'use client'
import { useEffect, useState } from 'react'
import { api } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Shield, Save, RotateCcw, Lock } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

const ROLE_LABELS: Record<string, string> = {
  SUPER_ADMIN: 'Super Admin',
  CELL_ADMIN: 'Cell Admin',
  ASSISTANT: 'Assistant',
  WORKER: 'Worker',
  MEMBER: 'Member',
  VISITOR: 'Visitor',
}

const ROLE_COLORS: Record<string, string> = {
  SUPER_ADMIN: '#7C3AED',
  CELL_ADMIN: '#0B2A5B',
  ASSISTANT: '#123F8C',
  WORKER: '#0EA5E9',
  MEMBER: '#22C55E',
  VISITOR: '#9CA3AF',
}

const CATEGORY_ORDER = ['User Management', 'Cell Operations', 'Events & Attendance', 'Communication', 'Reports & Admin']

export function PermissionsView() {
  const [matrix, setMatrix] = useState<Record<string, Record<string, boolean>>>({})
  const [original, setOriginal] = useState<Record<string, Record<string, boolean>>>({})
  const [roles, setRoles] = useState<any[]>([])
  const [permissions, setPermissions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    try {
      const data = await api('/api/permissions')
      setMatrix(JSON.parse(JSON.stringify(data.matrix)))
      setOriginal(JSON.parse(JSON.stringify(data.matrix)))
      setRoles(data.roles)
      setPermissions(data.permissions)
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const toggle = (role: string, perm: string, value: boolean) => {
    setMatrix((m) => ({ ...m, [role]: { ...m[role], [perm]: value } }))
  }

  const save = async () => {
    setSaving(true)
    try {
      await api('/api/permissions', { method: 'PATCH', body: JSON.stringify({ matrix }) })
      setOriginal(JSON.parse(JSON.stringify(matrix)))
      toast({ title: 'Permissions saved', description: 'The new permission matrix is now live.' })
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  const reset = () => {
    setMatrix(JSON.parse(JSON.stringify(original)))
    toast({ title: 'Reverted', description: 'Unsaved changes have been discarded.' })
  }

  const hasChanges = JSON.stringify(matrix) !== JSON.stringify(original)

  // Group permissions by category
  const byCategory: Record<string, any[]> = {}
  for (const p of permissions) {
    if (!byCategory[p.category]) byCategory[p.category] = []
    byCategory[p.category].push(p)
  }

  const configurableRoles = roles.filter((r) => r.value !== 'SUPER_ADMIN')

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading permission matrix...</div>

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><Shield className="h-5 w-5" /> Role Permissions</h2>
        <div className="flex gap-2">
          {hasChanges && <Button variant="outline" size="sm" onClick={reset}><RotateCcw className="h-4 w-4 mr-1" /> Revert</Button>}
          <Button size="sm" onClick={save} disabled={!hasChanges || saving} className="bg-[#0B2A5B] hover:bg-[#123F8C]">
            <Save className="h-4 w-4 mr-1" /> {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </div>

      <Card className="border-l-4 border-l-[#7C3AED]">
        <CardContent className="p-3 flex items-center gap-2 text-sm">
          <Lock className="h-4 w-4 text-[#7C3AED]" />
          <span><strong>Super Admin</strong> always has every permission — this column is locked and cannot be changed.</span>
        </CardContent>
      </Card>

      {/* Permission matrix by category */}
      {CATEGORY_ORDER.map((cat) => (
        <Card key={cat}>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{cat}</CardTitle>
          </CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/30">
                  <th className="text-left p-3 sticky left-0 bg-muted/30 min-w-[200px]">Permission</th>
                  {roles.map((r) => (
                    <th key={r.value} className="p-2 text-center min-w-[110px]">
                      <div className="flex flex-col items-center gap-1">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ backgroundColor: ROLE_COLORS[r.value] }}>
                          {r.label.charAt(0)}
                        </div>
                        <span className="text-xs">{r.label}</span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(byCategory[cat] || []).map((perm) => (
                  <tr key={perm.key} className="border-b last:border-0 hover:bg-muted/10">
                    <td className="p-3 sticky left-0 bg-background">
                      <div className="font-medium">{perm.label}</div>
                      <div className="text-xs text-muted-foreground">{perm.description}</div>
                    </td>
                    {roles.map((r) => {
                      const isSuperAdmin = r.value === 'SUPER_ADMIN'
                      const checked = isSuperAdmin ? true : matrix[r.value]?.[perm.key] === true
                      return (
                        <td key={r.value} className="p-2 text-center">
                          {isSuperAdmin ? (
                            <Badge variant="ghost" className="bg-[#7C3AED]/10 text-[#7C3AED]"><Lock className="h-3 w-3 mr-1" /> Always</Badge>
                          ) : (
                            <Switch checked={checked} onCheckedChange={(v) => toggle(r.value, perm.key, v)} />
                          )}
                        </td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      ))}

      {hasChanges && (
        <Card className="border-l-4 border-l-amber-400 sticky bottom-4">
          <CardContent className="p-3 flex items-center justify-between">
            <span className="text-sm font-medium">You have unsaved changes.</span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={reset}>Discard</Button>
              <Button size="sm" onClick={save} disabled={saving} className="bg-[#0B2A5B] hover:bg-[#123F8C]">
                <Save className="h-4 w-4 mr-1" /> Save Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

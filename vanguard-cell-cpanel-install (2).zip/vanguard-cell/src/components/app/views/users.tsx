'use client'
import { useEffect, useState } from 'react'
import { api, useApp } from '@/lib/store'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Users as UsersIcon, Search, Shield, AlertTriangle, Mail, Phone, Clock } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { formatDistanceToNow } from 'date-fns'

const ROLES = [
  { value: 'SUPER_ADMIN', label: 'Super Admin', color: '#7C3AED' },
  { value: 'CELL_ADMIN', label: 'Cell Admin / Leader', color: '#0B2A5B' },
  { value: 'ASSISTANT', label: 'Assistant', color: '#123F8C' },
  { value: 'WORKER', label: 'Worker', color: '#0EA5E9' },
  { value: 'MEMBER', label: 'Member', color: '#22C55E' },
  { value: 'VISITOR', label: 'Visitor', color: '#9CA3AF' },
]

const STATUSES = [
  { value: 'ACTIVE', label: 'Active', color: '#22C55E' },
  { value: 'SUSPENDED', label: 'Suspended', color: '#EF4444' },
  { value: 'INACTIVE', label: 'Inactive', color: '#9CA3AF' },
  { value: 'PENDING', label: 'Pending', color: '#F97316' },
]

export function UsersView() {
  const { user: currentUser, setView } = useApp()
  const [users, setUsers] = useState<any[]>([])
  const [superAdminCount, setSuperAdminCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('ALL')
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (search) params.set('search', search)
      if (roleFilter !== 'ALL') params.set('role', roleFilter)
      const data = await api(`/api/users?${params.toString()}`)
      setUsers(data.users || [])
      setSuperAdminCount(data.superAdminCount || 0)
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [roleFilter])

  const changeRole = async (userId: string, role: string, currentRole: string, currentStatus: string) => {
    if (role === currentRole) return
    try {
      await api(`/api/users/${userId}`, { method: 'PATCH', body: JSON.stringify({ role }) })
      toast({ title: 'Role updated', description: `User is now ${ROLES.find((r) => r.value === role)?.label}.` })
      load()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  const changeStatus = async (userId: string, status: string, currentStatus: string) => {
    if (status === currentStatus) return
    try {
      await api(`/api/users/${userId}`, { method: 'PATCH', body: JSON.stringify({ status }) })
      toast({ title: 'Status updated', description: `User is now ${status.toLowerCase()}.` })
      load()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><UsersIcon className="h-5 w-5" /> User Management</h2>
        <Button variant="outline" size="sm" onClick={() => setView('permissions')}>
          <Shield className="h-4 w-4 mr-1" /> Role Permissions
        </Button>
      </div>

      {/* Super admin count warning */}
      <Card className={superAdminCount === 1 ? 'border-l-4 border-l-[#7C3AED]' : superAdminCount === 0 ? 'border-l-4 border-l-red-500' : 'border-l-4 border-l-amber-400'}>
        <CardContent className="p-3 flex items-center gap-3">
          <Shield className={`h-5 w-5 ${superAdminCount === 0 ? 'text-red-500' : superAdminCount === 1 ? 'text-[#7C3AED]' : 'text-amber-500'}`} />
          <div className="flex-1 text-sm">
            {superAdminCount === 0 && <span className="text-red-700 font-medium">⚠️ No active Super Admin! Promote a user to Super Admin immediately.</span>}
            {superAdminCount === 1 && <span className="text-[#7C3AED]"><strong>1 active Super Admin</strong> — consider promoting a backup for safety.</span>}
            {superAdminCount > 1 && <span className="text-amber-700">{superAdminCount} active Super Admins. Only assign this role to trusted leaders.</span>}
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search by name, email, or phone..." value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && load()} className="pl-9" />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-full md:w-48"><SelectValue placeholder="All roles" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Roles</SelectItem>
            {ROLES.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button onClick={load} variant="outline"><Search className="h-4 w-4" /></Button>
      </div>

      {/* Users list */}
      {loading ? (
        <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-20 bg-muted/30 rounded-xl animate-pulse" />)}</div>
      ) : users.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">No users found.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {users.map((u) => {
            const roleInfo = ROLES.find((r) => r.value === u.role) || ROLES[4]
            const statusInfo = STATUSES.find((s) => s.value === u.status) || STATUSES[0]
            const isSelf = u.id === currentUser?.id
            const isLastSuperAdmin = u.role === 'SUPER_ADMIN' && u.status === 'ACTIVE' && superAdminCount <= 1
            return (
              <Card key={u.id} className={isSelf ? 'border-l-4 border-l-[#0B2A5B]' : ''}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-11 h-11 rounded-full flex items-center justify-center text-white font-bold text-sm shrink-0" style={{ backgroundColor: roleInfo.color }}>
                      {u.name?.split(' ').map((n: string) => n[0]).slice(0, 2).join('') || '?'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold">{u.name}</span>
                        {isSelf && <Badge variant="outline" className="text-xs">You</Badge>}
                        {u.member?.currentRank && <Badge variant="ghost" className="text-xs">{u.member.currentRank.icon} {u.member.currentRank.name}</Badge>}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1 flex flex-wrap gap-x-3 gap-y-0.5">
                        <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> {u.email}</span>
                        {u.phone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> {u.phone}</span>}
                        {u.member?.cell && <span>📍 {u.member.cell.name}</span>}
                        {u.lastLoginAt && <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> Last seen {formatDistanceToNow(new Date(u.lastLoginAt), { addSuffix: true })}</span>}
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">Member status: {u.member?.status?.replace(/_/g, ' ').toLowerCase() || 'No member profile'}</div>
                    </div>
                    <div className="flex flex-col gap-2 shrink-0 w-40">
                      <Select value={u.role} onValueChange={(v) => changeRole(u.id, v, u.role, u.status)} disabled={isLastSuperAdmin}>
                        <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {ROLES.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <Select value={u.status} onValueChange={(v) => changeStatus(u.id, v, u.status)} disabled={isLastSuperAdmin}>
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      {isLastSuperAdmin && <span className="text-[10px] text-amber-600 text-center">Last Super Admin</span>}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}

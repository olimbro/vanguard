'use client'
import { useEffect, useState } from 'react'
import { api, useApp } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { FileText, Download, BarChart3 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'

const REPORTS = [
  { type: 'attendance', name: 'Attendance Report', description: 'Filter attendance by event, date range, member, or status.', color: '#0B2A5B' },
  { type: 'engagement', name: 'Member Engagement', description: 'Show attendance, engagement score, rank, points, streak.', color: '#123F8C' },
  { type: 'growth', name: 'Growth Report', description: 'New members, visitors, conversions, active vs inactive.', color: '#22C55E' },
  { type: 'follow-up', name: 'Follow-Up Report', description: 'People needing follow-up, overdue, completed.', color: '#D4AF37' },
  { type: 'leaderboard', name: 'Leaderboard Report', description: 'Ranking, points, badges, participation.', color: '#E7B93E' },
  { type: 'event-performance', name: 'Event Performance', description: 'Registrations, attendance, no-shows per event.', color: '#0EA5E9' },
  { type: 'monthly-engagement', name: 'Monthly Engagement Report', description: 'Comprehensive monthly cell engagement summary.', color: '#7C3AED' },
]

export function ReportsView() {
  const [activeReport, setActiveReport] = useState<string | null>(null)
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const { toast } = useToast()

  const run = async (type: string, format = 'json') => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (from) params.set('from', from)
      if (to) params.set('to', to)
      params.set('format', format)
      const url = `/api/reports/${type}?${params.toString()}`
      if (format === 'csv') {
        window.open(url, '_blank')
      } else {
        const d = await api(url)
        setData(d)
        setActiveReport(type)
      }
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><BarChart3 className="h-5 w-5" /> Reports</h2>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {REPORTS.map((r) => (
          <Card key={r.type} className={`premium-card cursor-pointer ${activeReport === r.type ? 'border-2' : ''}`} style={{ borderColor: activeReport === r.type ? r.color : undefined }} onClick={() => run(r.type)}>
            <CardContent className="p-4">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-2" style={{ backgroundColor: r.color + '15' }}>
                <FileText className="h-4 w-4" style={{ color: r.color }} />
              </div>
              <div className="font-semibold text-sm">{r.name}</div>
              <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{r.description}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {activeReport && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              <span>{REPORTS.find((r) => r.type === activeReport)?.name}</span>
              <Button size="sm" variant="outline" onClick={() => run(activeReport, 'csv')}>
                <Download className="h-3 w-3 mr-1" /> Export CSV
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
              <div><Label className="text-xs">From</Label><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
              <div><Label className="text-xs">To</Label><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
              <div className="col-span-2 flex items-end"><Button onClick={() => run(activeReport)} disabled={loading} className="bg-[#0B2A5B] hover:bg-[#123F8C]">Refresh</Button></div>
            </div>
            <ReportRenderer type={activeReport} data={data} loading={loading} />
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function ReportRenderer({ type, data, loading }: any) {
  if (loading) return <div className="text-center py-8 text-muted-foreground">Generating report...</div>
  if (!data) return null

  if (type === 'monthly-engagement') {
    const r = data
    return (
      <div className="space-y-4">
        <div className="text-center p-4 bg-gradient-to-br from-[#0B2A5B] to-[#123F8C] text-white rounded-lg">
          <h3 className="text-lg font-bold">{r.Cell}</h3>
          <p className="text-sm text-white/80">{r.Church} · {r.Period}</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Object.entries(r).filter(([k]) => !['Cell', 'Church', 'Period'].includes(k)).map(([k, v]: any) => (
            <div key={k} className="p-3 bg-muted/30 rounded-lg text-center">
              <div className="text-xs text-muted-foreground">{k.replace(/([A-Z])/g, ' $1').trim()}</div>
              <div className="text-xl font-bold text-[#0B2A5B]">{String(v)}</div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (type === 'engagement') {
    const members = data.members || []
    return (
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="text-left border-b">
            <th className="p-2">Name</th><th className="p-2">Status</th><th className="p-2">Attendance</th>
            <th className="p-2">Engagement</th><th className="p-2">Rank</th><th className="p-2">Points</th><th className="p-2">Streak</th>
          </tr></thead>
          <tbody>
            {members.map((m: any, i: number) => (
              <tr key={i} className="border-b hover:bg-muted/20">
                <td className="p-2 font-medium">{m.Name}</td><td className="p-2 text-xs">{m.Status.replace(/_/g, ' ').toLowerCase()}</td>
                <td className="p-2">{m.AttendancePct}%</td><td className="p-2">{m.EngagementScore}%</td>
                <td className="p-2 text-xs">{m.Rank}</td><td className="p-2 font-bold text-[#D4AF37]">{m.Points}</td>
                <td className="p-2">🔥 {m.Streak}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )
  }

  if (type === 'leaderboard') {
    const leaderboard = data.leaderboard || []
    return (
      <div className="space-y-2">
        {leaderboard.map((m: any, i: number) => (
          <div key={i} className="flex items-center gap-3 p-2 rounded-lg bg-muted/20">
            <span className="font-bold w-8">{m.Rank}</span>
            <span className="flex-1 font-medium">{m.Name}</span>
            <span className="text-sm text-muted-foreground">{m.RankName}</span>
            <span className="font-bold text-[#D4AF37]">{m.Points} pts</span>
          </div>
        ))}
      </div>
    )
  }

  if (type === 'growth') {
    const r = data
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {Object.entries(r).map(([k, v]: any) => (
          <div key={k} className="p-4 bg-muted/30 rounded-lg">
            <div className="text-xs text-muted-foreground">{k.replace(/([A-Z])/g, ' $1').trim()}</div>
            <div className="text-2xl font-bold text-[#0B2A5B]">{String(v)}</div>
          </div>
        ))}
      </div>
    )
  }

  if (type === 'event-performance') {
    const events = data.events || []
    return (
      <div className="space-y-2">
        {events.map((e: any, i: number) => (
          <div key={i} className="p-3 bg-muted/20 rounded-lg">
            <div className="flex justify-between mb-1">
              <span className="font-medium text-sm">{e.Event}</span>
              <span className="text-xs text-muted-foreground">{e.Date}</span>
            </div>
            <div className="grid grid-cols-4 gap-2 text-xs">
              <div><span className="text-muted-foreground">Registered:</span> <strong>{e.Registered}</strong></div>
              <div><span className="text-muted-foreground">Attended:</span> <strong>{e.Attended}</strong></div>
              <div><span className="text-muted-foreground">No-show:</span> <strong>{e.NoShow}</strong></div>
              <div><span className="text-muted-foreground">Rate:</span> <strong>{e.AttendancePct}%</strong></div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (type === 'attendance') {
    const records = data.records || []
    return (
      <div className="space-y-1 max-h-96 overflow-y-auto scrollbar-thin">
        {records.slice(0, 50).map((r: any, i: number) => (
          <div key={i} className="flex items-center justify-between p-2 bg-muted/20 rounded text-sm">
            <div>
              <div className="font-medium">{r.member?.fullName}</div>
              <div className="text-xs text-muted-foreground">{r.event?.name} · {r.event?.startDate?.split('T')[0]}</div>
            </div>
            <span className="text-xs">{r.status} · {r.method}</span>
          </div>
        ))}
      </div>
    )
  }

  if (type === 'follow-up') {
    const followups = data.followups || []
    return (
      <div className="space-y-1">
        {followups.map((f: any, i: number) => (
          <div key={i} className="p-2 bg-muted/20 rounded text-sm flex justify-between">
            <div><strong>{f.Member}</strong> · {f.Worker}</div>
            <div className="text-xs text-muted-foreground">{f.Status} · {f.Priority}</div>
          </div>
        ))}
      </div>
    )
  }

  return <div className="text-center text-muted-foreground">Report rendered.</div>
}

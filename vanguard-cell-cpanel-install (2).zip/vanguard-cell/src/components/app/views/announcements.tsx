'use client'
import { useEffect, useState } from 'react'
import { api } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Megaphone, Plus, Pin } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { useApp } from '@/lib/store'
import { formatDistanceToNow } from 'date-fns'

export function AnnouncementsView() {
  const { user } = useApp()
  const [announcements, setAnnouncements] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreate, setShowCreate] = useState(false)
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    try {
      const data = await api('/api/announcements')
      setAnnouncements(data.announcements || [])
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const isAdmin = ['SUPER_ADMIN', 'CELL_ADMIN', 'ASSISTANT'].includes(user?.role || '')

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-[#0B2A5B]">Announcements</h2>
        {isAdmin && <Button onClick={() => setShowCreate(true)} className="bg-[#0B2A5B] hover:bg-[#123F8C]"><Plus className="h-4 w-4 mr-1" /> New</Button>}
      </div>

      {loading ? (
        <div className="space-y-3">{[...Array(3)].map((_, i) => <div key={i} className="h-32 bg-muted/30 rounded-xl animate-pulse" />)}</div>
      ) : announcements.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">No announcements yet.</CardContent></Card>
      ) : (
        <div className="space-y-3">
          {announcements.map((a) => (
            <Card key={a.id} className={a.isPinned ? 'border-l-4 border-l-[#D4AF37]' : ''}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    {a.isPinned && <Pin className="h-3 w-3 text-[#D4AF37]" />}
                    <h3 className="font-bold">{a.title}</h3>
                  </div>
                  <Badge variant="outline" className={
                    a.priority === 'URGENT' ? 'border-red-200 text-red-700 bg-red-50' :
                    a.priority === 'HIGH' ? 'border-orange-200 text-orange-700 bg-orange-50' : ''
                  }>{a.priority}</Badge>
                </div>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{a.body}</p>
                <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
                  <Badge variant="ghost">{a.category}</Badge>
                  <span>·</span>
                  <span>by {a.author?.name}</span>
                  <span>·</span>
                  <span>{formatDistanceToNow(new Date(a.publishedAt), { addSuffix: true })}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <CreateAnnouncementDialog open={showCreate} onOpenChange={setShowCreate} onCreated={load} />
    </div>
  )
}

function CreateAnnouncementDialog({ open, onOpenChange, onCreated }: any) {
  const { toast } = useToast()
  const { user } = useApp()
  const [form, setForm] = useState({ title: '', body: '', category: 'CELL', priority: 'NORMAL', isPinned: false })

  const submit = async () => {
    try {
      await api('/api/announcements', {
        method: 'POST',
        body: JSON.stringify({ ...form, cellId: user?.member?.cellId }),
      })
      toast({ title: 'Announcement posted!' })
      setForm({ title: '', body: '', category: 'CELL', priority: 'NORMAL', isPinned: false })
      onOpenChange(false)
      onCreated()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>New Announcement</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
          <div><Label>Message</Label><Textarea rows={4} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="CELL">Cell</SelectItem>
                  <SelectItem value="EVENT">Event</SelectItem>
                  <SelectItem value="URGENT">Urgent</SelectItem>
                  <SelectItem value="REMINDER">Reminder</SelectItem>
                  <SelectItem value="FOLLOW_UP">Follow-up</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Priority</Label>
              <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="LOW">Low</SelectItem>
                  <SelectItem value="NORMAL">Normal</SelectItem>
                  <SelectItem value="HIGH">High</SelectItem>
                  <SelectItem value="URGENT">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.isPinned} onChange={(e) => setForm({ ...form, isPinned: e.target.checked })} />
            Pin this announcement
          </label>
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit} className="bg-[#0B2A5B] hover:bg-[#123F8C]">Post</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

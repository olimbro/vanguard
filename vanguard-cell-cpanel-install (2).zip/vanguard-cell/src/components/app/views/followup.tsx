'use client'
import { useEffect, useState } from 'react'
import { api, useApp } from '@/lib/store'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Users, AlertCircle, Clock, CheckCircle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { formatDistanceToNow, format } from 'date-fns'

const STATUS_COLORS: Record<string, string> = {
  NEW: '#D4AF37', CONTACTED: '#0EA5E9', FOLLOW_UP_REQUIRED: '#F97316',
  ENGAGED: '#22C55E', ACTIVE: '#22C55E', INACTIVE: '#EF4444', ESCALATED: '#DC2626', CLOSED: '#9CA3AF',
}

export function FollowUpView() {
  const [followups, setFollowups] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('ALL')
  const [showAdd, setShowAdd] = useState(false)
  const { toast } = useToast()

  const load = async () => {
    setLoading(true)
    try {
      const data = await api('/api/followups')
      setFollowups(data.followups || [])
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const updateStatus = async (id: string, status: string) => {
    try {
      await api(`/api/followups/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) })
      toast({ title: 'Updated' })
      load()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  const filtered = filter === 'ALL' ? followups : followups.filter((f) => f.status === filter)
  const overdue = followups.filter((f) => f.nextFollowUpAt && new Date(f.nextFollowUpAt) < new Date() && f.status !== 'CLOSED')

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><Users className="h-5 w-5" /> Follow-Up</h2>
        <Button onClick={() => setShowAdd(true)} className="bg-[#0B2A5B] hover:bg-[#123F8C]">New Follow-Up</Button>
      </div>

      {overdue.length > 0 && (
        <Card className="border-l-4 border-l-red-500">
          <CardContent className="p-3 flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-red-500" />
            <span className="text-sm font-medium">{overdue.length} overdue follow-up{overdue.length === 1 ? '' : 's'}</span>
          </CardContent>
        </Card>
      )}

      <Select value={filter} onValueChange={setFilter}>
        <SelectTrigger className="w-full md:w-48"><SelectValue placeholder="Filter" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="ALL">All</SelectItem>
          <SelectItem value="NEW">New</SelectItem>
          <SelectItem value="CONTACTED">Contacted</SelectItem>
          <SelectItem value="FOLLOW_UP_REQUIRED">Follow-up Required</SelectItem>
          <SelectItem value="ENGAGED">Engaged</SelectItem>
          <SelectItem value="CLOSED">Closed</SelectItem>
        </SelectContent>
      </Select>

      {loading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-24 bg-muted/30 rounded-xl animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">No follow-ups in this category.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((f) => (
            <Card key={f.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <div className="font-semibold">{f.subject?.fullName}</div>
                    <div className="text-xs text-muted-foreground">Worker: {f.worker?.name || 'Unassigned'}</div>
                  </div>
                  <Badge style={{ backgroundColor: STATUS_COLORS[f.status], color: 'white' }}>{f.status.replace(/_/g, ' ').toLowerCase()}</Badge>
                </div>
                {f.notes && <p className="text-sm text-muted-foreground mb-2">{f.notes}</p>}
                <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                  <span>Priority: <Badge variant="outline">{f.priority}</Badge></span>
                  {f.lastContactAt && <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> Last: {formatDistanceToNow(new Date(f.lastContactAt), { addSuffix: true })}</span>}
                  {f.nextFollowUpAt && <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> Next: {format(new Date(f.nextFollowUpAt), 'dd MMM')}</span>}
                </div>
                <div className="flex gap-1 mt-3">
                  {f.status !== 'CLOSED' && (
                    <>
                      <Button size="sm" variant="outline" onClick={() => updateStatus(f.id, 'CONTACTED')}>Mark Contacted</Button>
                      <Button size="sm" variant="outline" onClick={() => updateStatus(f.id, 'ENGAGED')}>Mark Engaged</Button>
                      <Button size="sm" variant="outline" onClick={() => updateStatus(f.id, 'CLOSED')}><CheckCircle className="h-3 w-3 mr-1" /> Close</Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <NewFollowUpDialog open={showAdd} onOpenChange={setShowAdd} onCreated={load} />
    </div>
  )
}

function NewFollowUpDialog({ open, onOpenChange, onCreated }: any) {
  const [members, setMembers] = useState<any[]>([])
  const [form, setForm] = useState({ subjectMemberId: '', priority: 'NORMAL', notes: '', nextFollowUpAt: '' })
  const { toast } = useToast()

  useEffect(() => {
    api('/api/members').then((d) => setMembers(d.members || []))
  }, [])

  const submit = async () => {
    try {
      await api('/api/followups', { method: 'POST', body: JSON.stringify(form) })
      toast({ title: 'Follow-up created' })
      setForm({ subjectMemberId: '', priority: 'NORMAL', notes: '', nextFollowUpAt: '' })
      onOpenChange(false)
      onCreated()
    } catch (e: any) {
      toast({ title: 'Failed', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>New Follow-Up</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label>Member</Label>
            <Select value={form.subjectMemberId} onValueChange={(v) => setForm({ ...form, subjectMemberId: v })}>
              <SelectTrigger><SelectValue placeholder="Select member" /></SelectTrigger>
              <SelectContent>
                {members.map((m) => <SelectItem key={m.id} value={m.id}>{m.fullName}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Priority</Label>
            <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="LOW">Low</SelectItem>
                <SelectItem value="NORMAL">Normal</SelectItem>
                <SelectItem value="HIGH">High</SelectItem>
                <SelectItem value="URGENT">Urgent</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div><Label>Next Follow-up Date</Label><Input type="date" value={form.nextFollowUpAt} onChange={(e) => setForm({ ...form, nextFollowUpAt: e.target.value })} /></div>
          <div><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit} className="bg-[#0B2A5B] hover:bg-[#123F8C]">Create</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

'use client'
import { useEffect, useState } from 'react'
import { api } from '@/lib/store'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Bell, Check } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

const TYPE_COLORS: Record<string, string> = {
  EVENT_REMINDER: '#0EA5E9', REGISTRATION_CONFIRMED: '#22C55E', BADGE_EARNED: '#D4AF37',
  STREAK: '#F97316', MESSAGE: '#123F8C', ANNOUNCEMENT: '#7C3AED', FOLLOW_UP_DUE: '#EF4444', CHECK_IN: '#22C55E',
  GENERIC: '#9CA3AF',
}

export function NotificationsView() {
  const [notifications, setNotifications] = useState<any[]>([])
  const [unread, setUnread] = useState(0)
  const [loading, setLoading] = useState(true)

  const load = async () => {
    try {
      const data = await api('/api/notifications')
      setNotifications(data.notifications || [])
      setUnread(data.unreadCount || 0)
    } catch {} finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const markRead = async (id: string) => {
    try {
      await api(`/api/notifications/${id}`, { method: 'PATCH' })
      load()
    } catch {}
  }

  const markAllRead = async () => {
    await api('/api/notifications', { method: 'POST' })
    load()
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-[#0B2A5B] flex items-center gap-2"><Bell className="h-5 w-5" /> Notifications {unread > 0 && <Badge variant="destructive">{unread}</Badge>}</h2>
        {unread > 0 && <Button variant="outline" onClick={markAllRead}><Check className="h-4 w-4 mr-1" /> Mark all read</Button>}
      </div>

      {loading ? (
        <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-16 bg-muted/30 rounded-xl animate-pulse" />)}</div>
      ) : notifications.length === 0 ? (
        <Card><CardContent className="p-8 text-center text-muted-foreground">No notifications.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {notifications.map((n) => (
            <Card key={n.id} className={n.isRead ? '' : 'border-l-4 border-l-[#0B2A5B]'}>
              <CardContent className="p-3 flex items-start gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: (TYPE_COLORS[n.type] || '#9CA3AF') + '20' }}>
                  <Bell className="h-4 w-4" style={{ color: TYPE_COLORS[n.type] || '#9CA3AF' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`text-sm ${n.isRead ? 'font-normal' : 'font-bold'}`}>{n.title}</span>
                    {!n.isRead && <span className="h-2 w-2 rounded-full bg-blue-500" />}
                  </div>
                  {n.body && <p className="text-xs text-muted-foreground mt-0.5">{n.body}</p>}
                  <div className="text-xs text-muted-foreground mt-1">{formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}</div>
                </div>
                {!n.isRead && <Button size="sm" variant="ghost" onClick={() => markRead(n.id)}>Mark read</Button>}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

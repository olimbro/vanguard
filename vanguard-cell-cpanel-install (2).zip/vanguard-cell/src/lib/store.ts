'use client'
import { create } from 'zustand'

export type ViewKey =
  | 'dashboard'
  | 'events'
  | 'attendance'
  | 'members'
  | 'visitors'
  | 'followup'
  | 'leaderboard'
  | 'gamification'
  | 'messages'
  | 'announcements'
  | 'notifications'
  | 'reports'
  | 'settings'
  | 'audit'
  | 'profile'
  | 'calendar'
  | 'documents'

interface AppState {
  view: ViewKey
  setView: (v: ViewKey) => void
  selectedEventId: string | null
  setSelectedEventId: (id: string | null) => void
  selectedMemberId: string | null
  setSelectedMemberId: (id: string | null) => void
  user: any | null
  setUser: (u: any | null) => void
  loading: boolean
  setLoading: (b: boolean) => void
  pendingSyncCount: number
  setPendingSyncCount: (n: number) => void
}

export const useApp = create<AppState>((set) => ({
  view: 'dashboard',
  setView: (view) => set({ view }),
  selectedEventId: null,
  setSelectedEventId: (selectedEventId) => set({ selectedEventId }),
  selectedMemberId: null,
  setSelectedMemberId: (selectedMemberId) => set({ selectedMemberId }),
  user: null,
  setUser: (user) => set({ user }),
  loading: true,
  setLoading: (loading) => set({ loading }),
  pendingSyncCount: 0,
  setPendingSyncCount: (pendingSyncCount) => set({ pendingSyncCount }),
}))

// Fetch helper
export async function api(path: string, opts?: RequestInit) {
  const res = await fetch(path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(opts?.headers || {}) },
    credentials: 'include',
  })
  if (res.status === 401) {
    useApp.getState().setUser(null)
    throw new Error('Unauthorized')
  }
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.error || 'Request failed')
  return data
}

// IndexedDB offline attendance store
export async function openOfflineDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('vanguard_offline_attendance', 1)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains('attendance')) {
        db.createObjectStore('attendance', { keyPath: 'offlineUuid' })
      }
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

export async function queueOfflineAttendance(record: any) {
  const db = await openOfflineDB()
  const tx = db.transaction('attendance', 'readwrite')
  await new Promise<void>((resolve, reject) => {
    const req = tx.objectStore('attendance').put(record)
    req.onsuccess = () => resolve()
    req.onerror = () => reject(req.error)
  })
}

export async function getOfflineQueue(): Promise<any[]> {
  const db = await openOfflineDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('attendance', 'readonly')
    const req = tx.objectStore('attendance').getAll()
    req.onsuccess = () => resolve(req.result || [])
    req.onerror = () => reject(req.error)
  })
}

export async function clearOfflineQueueItem(offlineUuid: string) {
  const db = await openOfflineDB()
  const tx = db.transaction('attendance', 'readwrite')
  await new Promise<void>((resolve, reject) => {
    const req = tx.objectStore('attendance').delete(offlineUuid)
    req.onsuccess = () => resolve()
    req.onerror = () => reject(req.error)
  })
}

export async function syncOfflineQueue() {
  const queue = await getOfflineQueue()
  if (queue.length === 0) return { synced: 0, errors: 0 }
  const res = await api('/api/sync', {
    method: 'POST',
    body: JSON.stringify({ records: queue }),
  })
  let synced = 0, errors = 0
  for (const r of res.results || []) {
    if (r.status === 'synced' || r.status === 'duplicate') {
      await clearOfflineQueueItem(r.offlineUuid)
      synced++
    } else {
      errors++
    }
  }
  return { synced, errors }
}

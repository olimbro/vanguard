import { db } from './db'
import { headers } from 'next/headers'

export async function audit(opts: {
  actorId?: string
  action: string
  objectType: string
  objectId?: string
  oldValue?: any
  newValue?: any
}) {
  const h = await headers()
  const ip = h.get('x-forwarded-for') || h.get('x-real-ip') || undefined
  const ua = h.get('user-agent') || undefined
  await db.auditLog.create({
    data: {
      actorId: opts.actorId,
      action: opts.action,
      objectType: opts.objectType,
      objectId: opts.objectId,
      oldValue: opts.oldValue ? JSON.stringify(opts.oldValue) : null,
      newValue: opts.newValue ? JSON.stringify(opts.newValue) : null,
      ipAddress: ip,
      userAgent: ua,
    },
  })
}

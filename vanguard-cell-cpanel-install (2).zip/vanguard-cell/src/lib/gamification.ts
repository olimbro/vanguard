import { db } from './db'

// ============================================================
// GAMIFICATION ENGINE
// All scoring weights are configurable via Setting table.
// Default values match the spec (sections 22-25).
// ============================================================

export interface PointRules {
  ATTEND_CELL: number
  ON_TIME: number
  REGISTER_EVENT: number
  ATTEND_REGISTERED: number
  INVITE_GUEST: number
  OUTREACH: number
  TRAINING: number
  STREAK_4: number
  STREAK_8: number
  CHALLENGE_COMPLETE: number
  FOLLOW_UP_DONE: number
  SERVICE: number
}

export const DEFAULT_POINT_RULES: PointRules = {
  ATTEND_CELL: 10,
  ON_TIME: 5,
  REGISTER_EVENT: 2,
  ATTEND_REGISTERED: 10,
  INVITE_GUEST: 10,
  OUTREACH: 15,
  TRAINING: 20,
  STREAK_4: 25,
  STREAK_8: 50,
  CHALLENGE_COMPLETE: 10,
  FOLLOW_UP_DONE: 5,
  SERVICE: 10,
}

export async function getPointRules(): Promise<PointRules> {
  const setting = await db.setting.findUnique({ where: { key: 'gamification.point_rules' } })
  if (!setting) return DEFAULT_POINT_RULES
  try {
    return { ...DEFAULT_POINT_RULES, ...JSON.parse(setting.value) }
  } catch {
    return DEFAULT_POINT_RULES
  }
}

export async function savePointRules(rules: Partial<PointRules>, updatedById?: string) {
  const current = await getPointRules()
  const merged = { ...current, ...rules }
  await db.setting.upsert({
    where: { key: 'gamification.point_rules' },
    create: { key: 'gamification.point_rules', value: JSON.stringify(merged), category: 'GAMIFICATION', updatedById },
    update: { value: JSON.stringify(merged), updatedById },
  })
}

// ============================================================
// POINTS
// ============================================================

export async function awardPoints(
  memberId: string,
  points: number,
  reason: string,
  opts: { userId?: string; eventId?: string; referenceId?: string; description?: string } = {}
) {
  if (points === 0) return
  const tx = await db.pointTransaction.create({
    data: {
      memberId,
      userId: opts.userId,
      points,
      reason,
      description: opts.description,
      eventId: opts.eventId,
      referenceId: opts.referenceId,
    },
  })
  // Update cached totals on member
  await db.member.update({
    where: { id: memberId },
    data: { currentPoints: { increment: points } },
  })
  return tx
}

// ============================================================
// STREAKS
// ============================================================

export async function recalculateStreak(memberId: string) {
  // Get attendance records ordered by event start date, only PRESENT/LATE
  const records = await db.attendanceRecord.findMany({
    where: { memberId, status: { in: ['PRESENT', 'LATE'] } },
    include: { event: true },
    orderBy: { event: { startDate: 'asc' } },
  })
  if (records.length === 0) {
    await db.member.update({ where: { id: memberId }, data: { currentStreak: 0, longestStreak: 0 } })
    return { current: 0, longest: 0 }
  }
  // Sort by event startDate ascending
  const sorted = [...records].sort((a, b) => {
    const aTime = a.event?.startDate?.getTime() || 0
    const bTime = b.event?.startDate?.getTime() || 0
    return aTime - bTime
  })
  // Compute consecutive attendance: break when there's a gap > 14 days OR no records between two consecutive weekly meetings.
  let current = 1
  let longest = 1
  let running = 1
  for (let i = 1; i < sorted.length; i++) {
    const prev = sorted[i - 1].event?.startDate
    const curr = sorted[i].event?.startDate
    if (!prev || !curr) continue
    const diffDays = (curr.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24)
    if (diffDays <= 14) {
      running += 1
    } else {
      running = 1
    }
    if (running > longest) longest = running
  }
  // For "current", count from the most recent backwards
  let currStreak = 1
  for (let i = sorted.length - 1; i > 0; i--) {
    const prev = sorted[i - 1].event?.startDate
    const curr = sorted[i].event?.startDate
    if (!prev || !curr) break
    const diffDays = (curr.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24)
    if (diffDays <= 14) currStreak += 1
    else break
  }
  // If last attendance was more than 14 days ago, current streak = 0
  const lastEventDate = sorted[sorted.length - 1].event?.startDate
  if (lastEventDate) {
    const daysSince = (Date.now() - lastEventDate.getTime()) / (1000 * 60 * 60 * 24)
    if (daysSince > 21) currStreak = 0
  }
  await db.member.update({
    where: { id: memberId },
    data: { currentStreak: currStreak, longestStreak: Math.max(longest, currStreak) },
  })
  return { current: currStreak, longest: Math.max(longest, currStreak) }
}

// ============================================================
// RANKS
// ============================================================

export const DEFAULT_RANKS = [
  { level: 1, name: 'Newcomer', minPoints: 0, color: '#6B7280', icon: '🌱' },
  { level: 2, name: 'Participant', minPoints: 50, color: '#0EA5E9', icon: '👣' },
  { level: 3, name: 'Committed', minPoints: 150, color: '#123F8C', icon: '🤝' },
  { level: 4, name: 'Active', minPoints: 300, color: '#0B2A5B', icon: '⚡' },
  { level: 5, name: 'Faithful', minPoints: 500, color: '#D4AF37', icon: '🔥' },
  { level: 6, name: 'Champion', minPoints: 800, color: '#E7B93E', icon: '🏆' },
  { level: 7, name: 'Vanguard', minPoints: 1200, color: '#7C3AED', icon: '🚀' },
]

export async function seedDefaultRanks() {
  for (const r of DEFAULT_RANKS) {
    await db.rank.upsert({
      where: { level: r.level },
      create: r,
      update: { name: r.name, minPoints: r.minPoints, color: r.color, icon: r.icon },
    })
  }
}

export async function evaluateRank(memberId: string) {
  const member = await db.member.findUnique({ where: { id: memberId } })
  if (!member) return null
  const ranks = await db.rank.findMany({ orderBy: { minPoints: 'asc' } })
  if (ranks.length === 0) return null
  let earnedRank = ranks[0]
  for (const r of ranks) {
    if (member.currentPoints >= r.minPoints) earnedRank = r
  }
  if (member.currentRankId !== earnedRank.id) {
    await db.member.update({ where: { id: memberId }, data: { currentRankId: earnedRank.id } })
  }
  return earnedRank
}

// ============================================================
// BADGES
// ============================================================

export const DEFAULT_BADGES = [
  { name: 'First Step', slug: 'first-step', icon: '🏅', color: '#10B981', description: 'Attended your first event.', pointsReward: 5, criteria: JSON.stringify({ type: 'ATTEND_COUNT', value: 1 }) },
  { name: 'Faithful', slug: 'faithful', icon: '🔥', color: '#D4AF37', description: 'Attended 4 consecutive meetings.', pointsReward: 25, criteria: JSON.stringify({ type: 'STREAK', value: 4 }) },
  { name: 'Consistent', slug: 'consistent', icon: '🎯', color: '#E7B93E', description: 'Attended 8 consecutive meetings.', pointsReward: 50, criteria: JSON.stringify({ type: 'STREAK', value: 8 }) },
  { name: 'Committed', slug: 'committed', icon: '⭐', color: '#123F8C', description: 'Maintained 90%+ attendance over 8+ events.', pointsReward: 50, criteria: JSON.stringify({ type: 'ATTENDANCE_RATE', value: 90, minEvents: 8 }) },
  { name: 'Welcomer', slug: 'welcomer', icon: '🤝', color: '#0EA5E9', description: 'Successfully brought a registered guest.', pointsReward: 10, criteria: JSON.stringify({ type: 'INVITED_GUEST' }) },
  { name: 'Learner', slug: 'learner', icon: '📖', color: '#7C3AED', description: 'Completed a training activity.', pointsReward: 20, criteria: JSON.stringify({ type: 'TRAINING_COMPLETE' }) },
  { name: 'Prayer Champion', slug: 'prayer-champion', icon: '🙏', color: '#0B2A5B', description: 'Participated in designated prayer activities.', pointsReward: 15, criteria: JSON.stringify({ type: 'ACTIVITY_TYPE', value: 'PRAYER', count: 3 }) },
  { name: 'Growing', slug: 'growing', icon: '🌱', color: '#22C55E', description: 'Completed the new-member journey.', pointsReward: 15, criteria: JSON.stringify({ type: 'NEW_MEMBER_JOURNEY' }) },
  { name: 'Vanguard', slug: 'vanguard', icon: '🚀', color: '#D4AF37', description: 'Reached the Vanguard rank.', pointsReward: 0, criteria: JSON.stringify({ type: 'RANK', value: 7 }) },
]

export async function seedDefaultBadges() {
  for (const b of DEFAULT_BADGES) {
    await db.badge.upsert({
      where: { slug: b.slug },
      create: b,
      update: { name: b.name, description: b.description, icon: b.icon, color: b.color, pointsReward: b.pointsReward, criteria: b.criteria },
    })
  }
}

export async function awardBadge(memberId: string, badgeId: string, awardedById?: string) {
  const existing = await db.userBadge.findUnique({
    where: { memberId_badgeId: { memberId, badgeId } },
  })
  if (existing) return existing
  const ub = await db.userBadge.create({ data: { memberId, badgeId, awardedById } })
  const badge = await db.badge.findUnique({ where: { id: badgeId } })
  if (badge && badge.pointsReward > 0) {
    await awardPoints(memberId, badge.pointsReward, 'BADGE', { description: `Badge earned: ${badge.name}` })
  }
  return ub
}

export async function evaluateBadges(memberId: string) {
  const member = await db.member.findUnique({
    where: { id: memberId },
    include: {
      attendanceRecords: { include: { event: true } },
      badges: true,
      activities: true,
    },
  })
  if (!member) return
  const allBadges = await db.badge.findMany({ where: { isActive: true } })
  for (const badge of allBadges) {
    const already = member.badges.some((b) => b.badgeId === badge.id)
    if (already) continue
    let criteria: any = {}
    try { criteria = JSON.parse(badge.criteria || '{}') } catch {}
    let shouldAward = false
    if (criteria.type === 'ATTEND_COUNT') {
      shouldAward = member.attendanceRecords.length >= (criteria.value || 1)
    } else if (criteria.type === 'STREAK') {
      shouldAward = member.longestStreak >= (criteria.value || 0)
    } else if (criteria.type === 'ATTENDANCE_RATE') {
      const total = member.attendanceRecords.length
      if (total >= (criteria.minEvents || 0)) {
        const present = member.attendanceRecords.filter((r) => r.status === 'PRESENT' || r.status === 'LATE').length
        const rate = total > 0 ? (present / total) * 100 : 0
        shouldAward = rate >= (criteria.value || 90)
      }
    } else if (criteria.type === 'INVITED_GUEST') {
      // Look at visitor records
      const visitors = await db.visitor.count({ where: { invitedByMemberId: memberId } })
      shouldAward = visitors > 0
    } else if (criteria.type === 'TRAINING_COMPLETE') {
      shouldAward = member.activities.some((a) => a.activity?.activityType === 'TRAINING')
    } else if (criteria.type === 'ACTIVITY_TYPE') {
      const count = member.activities.filter((p) => p.activity?.activityType === criteria.value).length
      shouldAward = count >= (criteria.count || 1)
    } else if (criteria.type === 'RANK') {
      const rank = await db.rank.findUnique({ where: { id: member.currentRankId || '' } })
      shouldAward = !!rank && rank.level >= (criteria.value || 7)
    }
    if (shouldAward) {
      await awardBadge(memberId, badge.id)
    }
  }
}

// ============================================================
// ATTENDANCE PERCENTAGE + ENGAGEMENT SCORE
// ============================================================

export async function recalculateAttendancePercentage(memberId: string) {
  const records = await db.attendanceRecord.findMany({ where: { memberId } })
  if (records.length === 0) {
    await db.member.update({ where: { id: memberId }, data: { attendancePercentage: 0 } })
    return 0
  }
  const present = records.filter((r) => r.status === 'PRESENT' || r.status === 'LATE').length
  const pct = (present / records.length) * 100
  await db.member.update({ where: { id: memberId }, data: { attendancePercentage: pct } })
  return pct
}

const DEFAULT_ENGAGEMENT_WEIGHTS = {
  attendance: 0.4,
  participation: 0.2,
  registration: 0.1,
  timely: 0.1,
  outreach: 0.1,
  followUp: 0.1,
}

export async function recalculateEngagementScore(memberId: string) {
  const member = await db.member.findUnique({
    where: { id: memberId },
    include: { attendanceRecords: true, activities: true, pointTransactions: true },
  })
  if (!member) return 0
  const setting = await db.setting.findUnique({ where: { key: 'gamification.engagement_weights' } })
  const weights = setting ? { ...DEFAULT_ENGAGEMENT_WEIGHTS, ...JSON.parse(setting.value) } : DEFAULT_ENGAGEMENT_WEIGHTS
  // Normalize each dimension to 0-100
  const attendancePct = member.attendancePercentage
  const participationCount = member.activities.length
  const participationPct = Math.min(100, participationCount * 20)
  const registrations = await db.eventRegistration.count({ where: { userId: member.userId || undefined } })
  const registrationPct = Math.min(100, registrations * 25)
  const timelyCount = member.attendanceRecords.filter((r) => r.status === 'PRESENT').length
  const timelyPct = member.attendanceRecords.length > 0 ? (timelyCount / member.attendanceRecords.length) * 100 : 0
  const outreachCount = member.activities.filter((a) => a.activity?.activityType === 'OUTREACH' || a.activity?.activityType === 'EVANGELISM').length
  const outreachPct = Math.min(100, outreachCount * 33)
  const followUpCount = await db.followUp.count({ where: { assignedWorkerId: member.userId || undefined, status: 'CLOSED' } })
  const followUpPct = Math.min(100, followUpCount * 25)
  const score =
    attendancePct * weights.attendance +
    participationPct * weights.participation +
    registrationPct * weights.registration +
    timelyPct * weights.timely +
    outreachPct * weights.outreach +
    followUpPct * weights.followUp
  await db.member.update({ where: { id: memberId }, data: { engagementScore: Math.round(score * 10) / 10 } })
  return score
}

// ============================================================
// ENGAGEMENT HEALTH indicator (section 65)
// ============================================================

export function getEngagementHealth(score: number): { state: string; color: string; label: string } {
  if (score >= 75) return { state: 'HIGHLY_ENGAGED', color: '#16A34A', label: 'Highly Engaged' }
  if (score >= 50) return { state: 'ENGAGED', color: '#0EA5E9', label: 'Engaged' }
  if (score >= 30) return { state: 'AT_RISK', color: '#EAB308', label: 'At Risk' }
  if (score >= 15) return { state: 'INACTIVE', color: '#F97316', label: 'Inactive' }
  return { state: 'NEEDS_FOLLOW_UP', color: '#DC2626', label: 'Needs Follow-Up' }
}

// ============================================================
// LEADERBOARDS (section 24)
// ============================================================

export type LeaderboardPeriod = 'WEEKLY' | 'MONTHLY' | 'QUARTERLY' | 'ALL_TIME'

export async function getLeaderboard(cellId: string, period: LeaderboardPeriod, limit = 20) {
  const now = new Date()
  let since: Date | null = null
  if (period === 'WEEKLY') since = new Date(now.getTime() - 7 * 24 * 3600 * 1000)
  else if (period === 'MONTHLY') since = new Date(now.getFullYear(), now.getMonth(), 1)
  else if (period === 'QUARTERLY') {
    const q = Math.floor(now.getMonth() / 3)
    since = new Date(now.getFullYear(), q * 3, 1)
  }
  const where: any = { member: { cellId } }
  if (since) where.createdAt = { gte: since }
  const rows = await db.pointTransaction.groupBy({
    by: ['memberId'],
    where,
    _sum: { points: true },
    orderBy: { _sum: { points: 'desc' } },
    take: limit,
  })
  const memberIds = rows.map((r) => r.memberId)
  const members = await db.member.findMany({
    where: { id: { in: memberIds } },
    include: { currentRank: true, user: true },
  })
  const map = new Map(members.map((m) => [m.id, m]))
  return rows.map((r, i) => ({
    rank: i + 1,
    memberId: r.memberId,
    name: map.get(r.memberId)?.fullName || 'Unknown',
    points: r._sum.points || 0,
    rankName: map.get(r.memberId)?.currentRank?.name || 'Newcomer',
    rankIcon: map.get(r.memberId)?.currentRank?.icon || '🌱',
  }))
}

// ============================================================
// CHALLENGE EVALUATION
// ============================================================

export async function evaluateChallenges(memberId: string) {
  const challenges = await db.challenge.findMany({ where: { isActive: true } })
  for (const ch of challenges) {
    let progress = 0
    let completed = false
    if (ch.goalType === 'ATTEND_CONSECUTIVE') {
      const member = await db.member.findUnique({ where: { id: memberId } })
      progress = member?.currentStreak || 0
      completed = progress >= ch.goalValue
    } else if (ch.goalType === 'ATTEND_TOTAL') {
      const count = await db.attendanceRecord.count({ where: { memberId } })
      progress = count
      completed = count >= ch.goalValue
    } else if (ch.goalType === 'INVITE_GUEST') {
      const count = await db.visitor.count({ where: { invitedByMemberId: memberId } })
      progress = count
      completed = count >= ch.goalValue
    } else if (ch.goalType === 'COMPLETE_TRAINING') {
      const count = await db.activityParticipation.count({
        where: { memberId, activity: { activityType: 'TRAINING' } },
      })
      progress = count
      completed = count >= ch.goalValue
    }
    await db.challengeProgress.upsert({
      where: { challengeId_memberId: { challengeId: ch.id, memberId } },
      create: { challengeId: ch.id, memberId, progress, completed, completedAt: completed ? new Date() : null },
      update: { progress, completed, completedAt: completed ? new Date() : null },
    })
    if (completed && ch.pointsReward > 0) {
      const existing = await db.challengeProgress.findUnique({
        where: { challengeId_memberId: { challengeId: ch.id, memberId } },
      })
      if (existing && !existing.completed) {
        // Already handled by update above; award once
      }
    }
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { getSessionFromCookie, type SessionUser, can } from './auth'
import { db } from './db'

export interface AuthedRequest {
  session: SessionUser
  member: any | null
  cellId: string | null
}

export async function requireAuth(): Promise<{ session: SessionUser; member: any | null; cellId: string | null } | NextResponse> {
  const session = await getSessionFromCookie()
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  let member: any = null
  if (session.role !== 'SUPER_ADMIN') {
    member = await db.member.findUnique({
      where: { userId: session.userId },
      include: { cell: true },
    })
  }
  const cellId = member?.cellId || null
  return { session, member, cellId }
}

export function isAuthedResult(r: any): r is { session: SessionUser; member: any | null; cellId: string | null } {
  return r && typeof r === 'object' && 'session' in r && !('status' in r)
}

// Permission-gated helpers — each reads from the DB-driven permission matrix.
export function canManage(role: string): boolean {
  return can(role, 'MANAGE_EVENTS') || can(role, 'MANAGE_CELL') || can(role, 'MANAGE_VISITORS')
}

export function canTakeAttendance(role: string): boolean {
  return can(role, 'TAKE_ATTENDANCE')
}

export function canViewAllMembers(role: string): boolean {
  return can(role, 'VIEW_ALL_MEMBERS')
}

// Cell scoping for non-super-admins
export function cellFilter(cellId: string | null) {
  return cellId ? { cellId } : {}
}

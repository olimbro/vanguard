import { db } from './db'
import bcrypt from 'bcryptjs'
import { cookies } from 'next/headers'
import { randomUUID } from 'crypto'

export const SESSION_COOKIE = 'vcms_session'
const SESSION_EXPIRY_HOURS = 24 * 7 // 7 days

export interface SessionUser {
  userId: string
  email: string
  name: string
  role: string
  status: string
}

// In-memory session store (for dev / single-instance). For production, swap for Redis/DB.
// Use globalThis to survive HMR module re-evaluations in dev.
const globalAny = globalThis as any
if (!globalAny.__vcmsSessions) globalAny.__vcmsSessions = new Map<string, { user: SessionUser; expiresAt: number }>()
const sessions: Map<string, { user: SessionUser; expiresAt: number }> = globalAny.__vcmsSessions

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 10)
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash)
}

export async function createSession(user: SessionUser): Promise<string> {
  const token = randomUUID()
  const expiresAt = Date.now() + SESSION_EXPIRY_HOURS * 3600 * 1000
  sessions.set(token, { user, expiresAt })
  return token
}

export async function getSession(token?: string): Promise<SessionUser | null> {
  if (!token) return null
  const session = sessions.get(token)
  if (!session) return null
  if (Date.now() > session.expiresAt) {
    sessions.delete(token)
    return null
  }
  return session.user
}

export async function destroySession(token?: string): Promise<void> {
  if (token) sessions.delete(token)
}

export async function getSessionFromCookie(): Promise<SessionUser | null> {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value
  return getSession(token)
}

// ============================================================
// RBAC — DB-driven permission matrix
// SUPER_ADMIN always has every permission (hardcoded override).
// All other roles' permissions are configurable by the super admin
// via the Permissions management UI and stored in the Setting table
// under the key "permissions.matrix".
// ============================================================

export type Role = 'SUPER_ADMIN' | 'CELL_ADMIN' | 'ASSISTANT' | 'WORKER' | 'MEMBER' | 'VISITOR'

export const ALL_ROLES: Role[] = ['SUPER_ADMIN', 'CELL_ADMIN', 'ASSISTANT', 'WORKER', 'MEMBER', 'VISITOR']

export const ROLE_LABELS: Record<Role, string> = {
  SUPER_ADMIN: 'Super Admin',
  CELL_ADMIN: 'Cell Admin / Leader',
  ASSISTANT: 'Assistant Cell Leader',
  WORKER: 'Worker',
  MEMBER: 'Member',
  VISITOR: 'Visitor / Guest',
}

export interface PermissionDef {
  key: string
  label: string
  description: string
  category: 'User Management' | 'Cell Operations' | 'Events & Attendance' | 'Communication' | 'Reports & Admin'
}

// All configurable permissions. SUPER_ADMIN is always granted every one of these.
export const ALL_PERMISSIONS: PermissionDef[] = [
  { key: 'MANAGE_USERS', label: 'Manage Users & Assign Roles', description: 'Change user roles and account status', category: 'User Management' },
  { key: 'MANAGE_PERMISSIONS', label: 'Manage Role Permissions', description: 'Configure what each role can do', category: 'User Management' },
  { key: 'MANAGE_CELL', label: 'Manage Cell Information', description: 'Edit cell name, venue, meeting schedule', category: 'Cell Operations' },
  { key: 'MANAGE_VISITORS', label: 'Manage Visitors', description: 'Add, edit, and convert visitors to members', category: 'Cell Operations' },
  { key: 'MANAGE_FOLLOWUPS', label: 'Manage Follow-Ups', description: 'Create and update follow-up tasks', category: 'Cell Operations' },
  { key: 'MANAGE_EVENTS', label: 'Manage Events', description: 'Create, edit, and delete events', category: 'Events & Attendance' },
  { key: 'TAKE_ATTENDANCE', label: 'Take Attendance', description: 'Record attendance for events', category: 'Events & Attendance' },
  { key: 'MANAGE_GAMIFICATION', label: 'Manage Gamification', description: 'Configure points, ranks, badges, challenges', category: 'Events & Attendance' },
  { key: 'SEND_ANNOUNCEMENTS', label: 'Send Announcements', description: 'Post announcements to the cell', category: 'Communication' },
  { key: 'SEND_MESSAGES', label: 'Send Messages', description: 'Participate in cell group chat', category: 'Communication' },
  { key: 'VIEW_ALL_MEMBERS', label: 'View All Members', description: 'See all member profiles including private data', category: 'Reports & Admin' },
  { key: 'VIEW_REPORTS', label: 'View Reports', description: 'Access all reports and analytics', category: 'Reports & Admin' },
  { key: 'VIEW_AUDIT_LOG', label: 'View Audit Log', description: 'See all administrative actions', category: 'Reports & Admin' },
  { key: 'MANAGE_SETTINGS', label: 'Manage System Settings', description: 'Configure branding, thresholds, notifications', category: 'Reports & Admin' },
]

export type PermissionMatrix = Record<string, Record<string, boolean>>

export const DEFAULT_PERMISSIONS: PermissionMatrix = {
  SUPER_ADMIN: Object.fromEntries(ALL_PERMISSIONS.map((p) => [p.key, true])),
  CELL_ADMIN: {
    MANAGE_CELL: true, MANAGE_VISITORS: true, MANAGE_FOLLOWUPS: true,
    MANAGE_EVENTS: true, TAKE_ATTENDANCE: true, MANAGE_GAMIFICATION: true,
    SEND_ANNOUNCEMENTS: true, SEND_MESSAGES: true,
    VIEW_ALL_MEMBERS: true, VIEW_REPORTS: true, VIEW_AUDIT_LOG: true, MANAGE_SETTINGS: true,
  },
  ASSISTANT: {
    MANAGE_EVENTS: true, TAKE_ATTENDANCE: true, MANAGE_FOLLOWUPS: true,
    SEND_ANNOUNCEMENTS: true, SEND_MESSAGES: true,
    VIEW_ALL_MEMBERS: true, VIEW_REPORTS: true,
  },
  WORKER: {
    TAKE_ATTENDANCE: true, MANAGE_FOLLOWUPS: true, SEND_MESSAGES: true,
    VIEW_ALL_MEMBERS: true, VIEW_REPORTS: true,
  },
  MEMBER: {
    SEND_MESSAGES: true,
  },
  VISITOR: {},
}

// In-memory cache of the permission matrix. Lazily loaded from DB on first
// access; refreshed whenever the super admin updates it via the API.
// Use globalThis to survive HMR module re-evaluations in dev.
if (!globalAny.__vcmsMatrixCache) globalAny.__vcmsMatrixCache = DEFAULT_PERMISSIONS
if (globalAny.__vcmsMatrixLoaded === undefined) globalAny.__vcmsMatrixLoaded = false

async function loadMatrixFromDB(): Promise<PermissionMatrix> {
  try {
    const setting = await db.setting.findUnique({ where: { key: 'permissions.matrix' } })
    if (setting) {
      const parsed = JSON.parse(setting.value)
      // Always force SUPER_ADMIN = all true
      parsed.SUPER_ADMIN = Object.fromEntries(ALL_PERMISSIONS.map((p) => [p.key, true]))
      return parsed
    }
  } catch {}
  return DEFAULT_PERMISSIONS
}

// Fire-and-forget initial load. The first few requests may use defaults,
// which is fine because defaults match the seeded matrix.
if (!globalAny.__vcmsMatrixInitialized) {
  globalAny.__vcmsMatrixInitialized = true
  loadMatrixFromDB()
    .then((m) => { globalAny.__vcmsMatrixCache = m; globalAny.__vcmsMatrixLoaded = true })
    .catch(() => { globalAny.__vcmsMatrixLoaded = true })
}

export async function refreshPermissionMatrix(): Promise<void> {
  const m = await loadMatrixFromDB()
  globalAny.__vcmsMatrixCache = m
  globalAny.__vcmsMatrixLoaded = true
}

export function getPermissionMatrix(): PermissionMatrix {
  return globalAny.__vcmsMatrixCache || DEFAULT_PERMISSIONS
}

export function can(role: string, permission: string): boolean {
  // SUPER_ADMIN always has every permission — this is non-configurable.
  if (role === 'SUPER_ADMIN') return true
  const cache = globalAny.__vcmsMatrixCache || DEFAULT_PERMISSIONS
  return cache[role]?.[permission] === true
}

// ============================================================
// Convenience helpers (used across API routes)
// ============================================================

export function canManageUsers(role: string): boolean {
  return can(role, 'MANAGE_USERS')
}

export function canManagePermissions(role: string): boolean {
  return can(role, 'MANAGE_PERMISSIONS')
}

export function canManageEvents(role: string): boolean {
  return can(role, 'MANAGE_EVENTS')
}

export function canTakeAttendance(role: string): boolean {
  return can(role, 'TAKE_ATTENDANCE')
}

export function canViewAllMembers(role: string): boolean {
  return can(role, 'VIEW_ALL_MEMBERS')
}

export function canViewReports(role: string): boolean {
  return can(role, 'VIEW_REPORTS')
}

export function canSendAnnouncements(role: string): boolean {
  return can(role, 'SEND_ANNOUNCEMENTS')
}

export function canViewAuditLog(role: string): boolean {
  return can(role, 'VIEW_AUDIT_LOG')
}

export function canManageSettings(role: string): boolean {
  return can(role, 'MANAGE_SETTINGS')
}

export function canManageGamification(role: string): boolean {
  return can(role, 'MANAGE_GAMIFICATION')
}

export function canManageVisitors(role: string): boolean {
  return can(role, 'MANAGE_VISITORS')
}

export function canManageFollowups(role: string): boolean {
  return can(role, 'MANAGE_FOLLOWUPS')
}

// "Manager" = any role that can manage events/members/visitors — used for UI gating.
export function isManager(role: string): boolean {
  return (
    can(role, 'MANAGE_EVENTS') ||
    can(role, 'MANAGE_CELL') ||
    can(role, 'MANAGE_VISITORS') ||
    can(role, 'MANAGE_FOLLOWUPS')
  )
}

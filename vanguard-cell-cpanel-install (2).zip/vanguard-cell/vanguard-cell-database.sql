-- Vanguard Cell Management System — MySQL Database Dump
-- Christ Embassy — Vanguard Cell 1, Awka Church
-- Generated: 2026-10-08T06:21:01.497Z
--
-- This SQL file creates the complete database schema and seeds it with:
-- - Christ Embassy church, Awka Zone, Vanguard Cell 1
-- - 19 demo users (super admin, cell leader, assistant, workers, members, visitors)
-- - 7 ranks, 9 badges, 2 challenges
-- - 13 weekly Saturday events (8 past + 4 upcoming)
-- - 1 End-of-Year Fellowship registration event with form fields
-- - 8 weeks of realistic attendance records
-- - Default permission matrix, settings, welcome announcement, cell chat
--
-- Installation:
--   1. Create a MySQL database (e.g., via cPanel → MySQL Databases)
--   2. Import this file via phpMyAdmin → Import
--   3. Or run: mysql -u USER -p DATABASE < vanguard-cell-database.sql
--
-- After import, update the super admin password via the installer.

SET FOREIGN_KEY_CHECKS = 0;

-- Drop existing tables
DROP TABLE IF EXISTS `Setting`;
DROP TABLE IF EXISTS `AuditLog`;
DROP TABLE IF EXISTS `Certificate`;
DROP TABLE IF EXISTS `CertificateTemplate`;
DROP TABLE IF EXISTS `Document`;
DROP TABLE IF EXISTS `Notification`;
DROP TABLE IF EXISTS `Announcement`;
DROP TABLE IF EXISTS `Message`;
DROP TABLE IF EXISTS `ConversationParticipant`;
DROP TABLE IF EXISTS `Conversation`;
DROP TABLE IF EXISTS `ActivityParticipation`;
DROP TABLE IF EXISTS `Activity`;
DROP TABLE IF EXISTS `ChallengeProgress`;
DROP TABLE IF EXISTS `Challenge`;
DROP TABLE IF EXISTS `FollowUp`;
DROP TABLE IF EXISTS `Visitor`;
DROP TABLE IF EXISTS `SyncRecord`;
DROP TABLE IF EXISTS `AttendanceRecord`;
DROP TABLE IF EXISTS `RegistrationFieldValue`;
DROP TABLE IF EXISTS `EventRegistration`;
DROP TABLE IF EXISTS `RegistrationField`;
DROP TABLE IF EXISTS `Event`;
DROP TABLE IF EXISTS `EventSeries`;
DROP TABLE IF EXISTS `Member`;
DROP TABLE IF EXISTS `Badge`;
DROP TABLE IF EXISTS `Rank`;
DROP TABLE IF EXISTS `Cell`;
DROP TABLE IF EXISTS `Zone`;
DROP TABLE IF EXISTS `Church`;
DROP TABLE IF EXISTS `User`;

-- Create tables
CREATE TABLE `User` (
  `id` VARCHAR(191) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `phone` VARCHAR(191) NULL,
  `passwordHash` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `preferredName` VARCHAR(191) NULL,
  `role` VARCHAR(191) NOT NULL DEFAULT 'MEMBER',
  `status` VARCHAR(191) NOT NULL DEFAULT 'ACTIVE',
  `twoFactorEnabled` BOOLEAN NOT NULL DEFAULT false,
  `emailVerifiedAt` DATETIME(3) NULL,
  `lastLoginAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `User_email_key`(`email`),
  INDEX `User_role_idx`(`role`),
  INDEX `User_status_idx`(`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Church` (
  `id` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `slug` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `logoUrl` VARCHAR(191) NULL,
  `contactEmail` VARCHAR(191) NULL,
  `contactPhone` VARCHAR(191) NULL,
  `address` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Church_slug_key`(`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Zone` (
  `id` VARCHAR(191) NOT NULL,
  `churchId` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `slug` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Zone_churchId_slug_key`(`churchId`, `slug`),
  CONSTRAINT `Zone_churchId_fkey` FOREIGN KEY (`churchId`) REFERENCES `Church`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Cell` (
  `id` VARCHAR(191) NOT NULL,
  `churchId` VARCHAR(191) NOT NULL,
  `zoneId` VARCHAR(191) NULL,
  `name` VARCHAR(191) NOT NULL,
  `slug` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `meetingDay` VARCHAR(191) NULL,
  `meetingTime` VARCHAR(191) NULL,
  `venue` VARCHAR(191) NULL,
  `address` VARCHAR(191) NULL,
  `leaderUserId` VARCHAR(191) NULL,
  `logoUrl` VARCHAR(191) NULL,
  `brandColor` VARCHAR(191) NULL DEFAULT '#0B2A5B',
  `accentColor` VARCHAR(191) NULL DEFAULT '#D4AF37',
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Cell_churchId_slug_key`(`churchId`, `slug`),
  INDEX `Cell_zoneId_idx`(`zoneId`),
  INDEX `Cell_leaderUserId_idx`(`leaderUserId`),
  CONSTRAINT `Cell_churchId_fkey` FOREIGN KEY (`churchId`) REFERENCES `Church`(`id`) ON DELETE CASCADE,
  CONSTRAINT `Cell_zoneId_fkey` FOREIGN KEY (`zoneId`) REFERENCES `Zone`(`id`),
  CONSTRAINT `Cell_leaderUserId_fkey` FOREIGN KEY (`leaderUserId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Rank` (
  `id` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `level` INT NOT NULL,
  `minPoints` INT NOT NULL DEFAULT 0,
  `color` VARCHAR(191) NOT NULL DEFAULT '#0B2A5B',
  `icon` VARCHAR(191) NULL,
  `description` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Rank_name_key`(`name`),
  UNIQUE INDEX `Rank_level_key`(`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Badge` (
  `id` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `slug` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `icon` VARCHAR(191) NOT NULL,
  `color` VARCHAR(191) NOT NULL DEFAULT '#D4AF37',
  `criteria` TEXT NULL,
  `pointsReward` INT NOT NULL DEFAULT 0,
  `isActive` BOOLEAN NOT NULL DEFAULT true,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Badge_name_key`(`name`),
  UNIQUE INDEX `Badge_slug_key`(`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Member` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `cellId` VARCHAR(191) NOT NULL,
  `fullName` VARCHAR(191) NOT NULL,
  `preferredName` VARCHAR(191) NULL,
  `photoUrl` VARCHAR(191) NULL,
  `gender` VARCHAR(191) NULL,
  `dateOfBirth` DATETIME(3) NULL,
  `phone` VARCHAR(191) NULL,
  `whatsapp` VARCHAR(191) NULL,
  `email` VARCHAR(191) NULL,
  `address` VARCHAR(191) NULL,
  `location` VARCHAR(191) NULL,
  `occupation` VARCHAR(191) NULL,
  `emergencyContact` VARCHAR(191) NULL,
  `status` VARCHAR(191) NOT NULL DEFAULT 'NEW_MEMBER',
  `memberCategory` VARCHAR(191) NULL,
  `dateJoinedCell` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `dateConverted` DATETIME(3) NULL,
  `assignedWorkerId` VARCHAR(191) NULL,
  `spiritualMilestones` TEXT NULL,
  `notes` TEXT NULL,
  `accountStatus` VARCHAR(191) NOT NULL DEFAULT 'ACTIVE',
  `isMinor` BOOLEAN NOT NULL DEFAULT false,
  `guardianName` VARCHAR(191) NULL,
  `guardianConsent` BOOLEAN NOT NULL DEFAULT false,
  `lastAttendanceAt` DATETIME(3) NULL,
  `attendancePercentage` FLOAT NOT NULL DEFAULT 0,
  `engagementScore` FLOAT NOT NULL DEFAULT 0,
  `currentPoints` INT NOT NULL DEFAULT 0,
  `currentRankId` VARCHAR(191) NULL,
  `currentStreak` INT NOT NULL DEFAULT 0,
  `longestStreak` INT NOT NULL DEFAULT 0,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Member_userId_key`(`userId`),
  INDEX `Member_cellId_idx`(`cellId`),
  INDEX `Member_status_idx`(`status`),
  INDEX `Member_assignedWorkerId_idx`(`assignedWorkerId`),
  CONSTRAINT `Member_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE,
  CONSTRAINT `Member_cellId_fkey` FOREIGN KEY (`cellId`) REFERENCES `Cell`(`id`),
  CONSTRAINT `Member_currentRankId_fkey` FOREIGN KEY (`currentRankId`) REFERENCES `Rank`(`id`),
  CONSTRAINT `Member_assignedWorkerId_fkey` FOREIGN KEY (`assignedWorkerId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `EventSeries` (
  `id` VARCHAR(191) NOT NULL,
  `cellId` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `recurrenceRule` TEXT NOT NULL,
  `eventType` VARCHAR(191) NOT NULL DEFAULT 'WEEKLY_CELL_MEETING',
  `venue` VARCHAR(191) NULL,
  `address` VARCHAR(191) NULL,
  `hostUserId` VARCHAR(191) NULL,
  `createdById` VARCHAR(191) NOT NULL,
  `isActive` BOOLEAN NOT NULL DEFAULT true,
  `startDate` DATETIME(3) NOT NULL,
  `endDate` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `EventSeries_cellId_fkey` FOREIGN KEY (`cellId`) REFERENCES `Cell`(`id`) ON DELETE CASCADE,
  CONSTRAINT `EventSeries_hostUserId_fkey` FOREIGN KEY (`hostUserId`) REFERENCES `User`(`id`),
  CONSTRAINT `EventSeries_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Event` (
  `id` VARCHAR(191) NOT NULL,
  `cellId` VARCHAR(191) NOT NULL,
  `seriesId` VARCHAR(191) NULL,
  `name` VARCHAR(191) NOT NULL,
  `slug` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `eventType` VARCHAR(191) NOT NULL DEFAULT 'WEEKLY_CELL_MEETING',
  `startDate` DATETIME(3) NOT NULL,
  `endDate` DATETIME(3) NULL,
  `startTime` VARCHAR(191) NULL,
  `endTime` VARCHAR(191) NULL,
  `venue` VARCHAR(191) NULL,
  `address` VARCHAR(191) NULL,
  `mapLink` VARCHAR(191) NULL,
  `hostUserId` VARCHAR(191) NULL,
  `coverImageUrl` VARCHAR(191) NULL,
  `capacity` INT NULL,
  `registrationRequired` BOOLEAN NOT NULL DEFAULT false,
  `registrationDeadline` DATETIME(3) NULL,
  `attendanceRequired` BOOLEAN NOT NULL DEFAULT true,
  `isPublic` BOOLEAN NOT NULL DEFAULT false,
  `memberEligibility` VARCHAR(191) NOT NULL DEFAULT 'ANY',
  `guestEligibility` BOOLEAN NOT NULL DEFAULT true,
  `status` VARCHAR(191) NOT NULL DEFAULT 'DRAFT',
  `accessRule` VARCHAR(191) NOT NULL DEFAULT 'ANYONE',
  `enableGeolocation` BOOLEAN NOT NULL DEFAULT false,
  `geoLat` FLOAT NULL,
  `geoLng` FLOAT NULL,
  `geoRadiusMeters` INT NULL,
  `enablePin` BOOLEAN NOT NULL DEFAULT false,
  `enableQr` BOOLEAN NOT NULL DEFAULT true,
  `createdById` VARCHAR(191) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Event_cellId_slug_key`(`cellId`, `slug`),
  INDEX `Event_cellId_idx`(`cellId`),
  INDEX `Event_startDate_idx`(`startDate`),
  INDEX `Event_status_idx`(`status`),
  CONSTRAINT `Event_cellId_fkey` FOREIGN KEY (`cellId`) REFERENCES `Cell`(`id`) ON DELETE CASCADE,
  CONSTRAINT `Event_seriesId_fkey` FOREIGN KEY (`seriesId`) REFERENCES `EventSeries`(`id`),
  CONSTRAINT `Event_hostUserId_fkey` FOREIGN KEY (`hostUserId`) REFERENCES `User`(`id`),
  CONSTRAINT `Event_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `RegistrationField` (
  `id` VARCHAR(191) NOT NULL,
  `eventId` VARCHAR(191) NOT NULL,
  `label` VARCHAR(191) NOT NULL,
  `fieldKey` VARCHAR(191) NOT NULL,
  `fieldType` VARCHAR(191) NOT NULL,
  `options` TEXT NULL,
  `required` BOOLEAN NOT NULL DEFAULT false,
  `order` INT NOT NULL DEFAULT 0,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE INDEX `RegistrationField_eventId_fieldKey_key`(`eventId`, `fieldKey`),
  CONSTRAINT `RegistrationField_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Event`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `EventRegistration` (
  `id` VARCHAR(191) NOT NULL,
  `eventId` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NULL,
  `registrationNumber` VARCHAR(191) NOT NULL,
  `status` VARCHAR(191) NOT NULL DEFAULT 'REGISTERED',
  `qrToken` VARCHAR(191) NULL,
  `guestName` VARCHAR(191) NULL,
  `guestEmail` VARCHAR(191) NULL,
  `guestPhone` VARCHAR(191) NULL,
  `invitedByMemberId` VARCHAR(191) NULL,
  `numGuests` INT NOT NULL DEFAULT 1,
  `dietaryInfo` VARCHAR(191) NULL,
  `specialNeeds` TEXT NULL,
  `formData` TEXT NULL,
  `checkedInAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `EventRegistration_registrationNumber_key`(`registrationNumber`),
  UNIQUE INDEX `EventRegistration_qrToken_key`(`qrToken`),
  INDEX `EventRegistration_eventId_idx`(`eventId`),
  INDEX `EventRegistration_userId_idx`(`userId`),
  CONSTRAINT `EventRegistration_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Event`(`id`) ON DELETE CASCADE,
  CONSTRAINT `EventRegistration_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `RegistrationFieldValue` (
  `id` VARCHAR(191) NOT NULL,
  `registrationId` VARCHAR(191) NOT NULL,
  `fieldId` VARCHAR(191) NOT NULL,
  `value` TEXT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `RegistrationFieldValue_registrationId_fieldId_key`(`registrationId`, `fieldId`),
  CONSTRAINT `RegistrationFieldValue_registrationId_fkey` FOREIGN KEY (`registrationId`) REFERENCES `EventRegistration`(`id`) ON DELETE CASCADE,
  CONSTRAINT `RegistrationFieldValue_fieldId_fkey` FOREIGN KEY (`fieldId`) REFERENCES `RegistrationField`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `AttendanceRecord` (
  `id` VARCHAR(191) NOT NULL,
  `eventId` VARCHAR(191) NOT NULL,
  `memberId` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NULL,
  `status` VARCHAR(191) NOT NULL DEFAULT 'PRESENT',
  `method` VARCHAR(191) NOT NULL DEFAULT 'MANUAL',
  `checkInTime` DATETIME(3) NULL,
  `checkOutTime` DATETIME(3) NULL,
  `durationMinutes` INT NULL,
  `deviceIdentifier` VARCHAR(191) NULL,
  `verificationStatus` VARCHAR(191) NOT NULL DEFAULT 'VERIFIED',
  `locationVerified` BOOLEAN NOT NULL DEFAULT false,
  `recordedById` VARCHAR(191) NOT NULL,
  `notes` TEXT NULL,
  `syncStatus` VARCHAR(191) NOT NULL DEFAULT 'SYNCED',
  `offlineUuid` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `AttendanceRecord_eventId_memberId_key`(`eventId`, `memberId`),
  UNIQUE INDEX `AttendanceRecord_offlineUuid_key`(`offlineUuid`),
  INDEX `AttendanceRecord_memberId_idx`(`memberId`),
  INDEX `AttendanceRecord_eventId_idx`(`eventId`),
  CONSTRAINT `AttendanceRecord_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Event`(`id`) ON DELETE CASCADE,
  CONSTRAINT `AttendanceRecord_memberId_fkey` FOREIGN KEY (`memberId`) REFERENCES `Member`(`id`) ON DELETE CASCADE,
  CONSTRAINT `AttendanceRecord_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`),
  CONSTRAINT `AttendanceRecord_recordedById_fkey` FOREIGN KEY (`recordedById`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `SyncRecord` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `offlineUuid` VARCHAR(191) NOT NULL,
  `eventId` VARCHAR(191) NOT NULL,
  `memberId` VARCHAR(191) NOT NULL,
  `status` VARCHAR(191) NOT NULL DEFAULT 'PENDING',
  `payload` LONGTEXT NOT NULL,
  `errorMessage` TEXT NULL,
  `syncedAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE INDEX `SyncRecord_offlineUuid_key`(`offlineUuid`),
  CONSTRAINT `SyncRecord_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Visitor` (
  `id` VARCHAR(191) NOT NULL,
  `memberId` VARCHAR(191) NULL,
  `cellId` VARCHAR(191) NOT NULL,
  `fullName` VARCHAR(191) NOT NULL,
  `phone` VARCHAR(191) NULL,
  `email` VARCHAR(191) NULL,
  `gender` VARCHAR(191) NULL,
  `invitedByMemberId` VARCHAR(191) NULL,
  `firstEventId` VARCHAR(191) NULL,
  `firstVisitDate` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `followUpStatus` VARCHAR(191) NOT NULL DEFAULT 'NEW',
  `convertedAt` DATETIME(3) NULL,
  `notes` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Visitor_memberId_key`(`memberId`),
  INDEX `Visitor_cellId_idx`(`cellId`),
  CONSTRAINT `Visitor_memberId_fkey` FOREIGN KEY (`memberId`) REFERENCES `Member`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `FollowUp` (
  `id` VARCHAR(191) NOT NULL,
  `subjectMemberId` VARCHAR(191) NOT NULL,
  `assignedWorkerId` VARCHAR(191) NULL,
  `status` VARCHAR(191) NOT NULL DEFAULT 'NEW',
  `priority` VARCHAR(191) NOT NULL DEFAULT 'NORMAL',
  `contactMethod` VARCHAR(191) NULL,
  `lastContactAt` DATETIME(3) NULL,
  `nextFollowUpAt` DATETIME(3) NULL,
  `outcome` VARCHAR(191) NULL,
  `notes` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `FollowUp_subjectMemberId_idx`(`subjectMemberId`),
  INDEX `FollowUp_assignedWorkerId_idx`(`assignedWorkerId`),
  INDEX `FollowUp_status_idx`(`status`),
  CONSTRAINT `FollowUp_subjectMemberId_fkey` FOREIGN KEY (`subjectMemberId`) REFERENCES `Member`(`id`) ON DELETE CASCADE,
  CONSTRAINT `FollowUp_assignedWorkerId_fkey` FOREIGN KEY (`assignedWorkerId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Challenge` (
  `id` VARCHAR(191) NOT NULL,
  `cellId` VARCHAR(191) NULL,
  `name` VARCHAR(191) NOT NULL,
  `slug` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `goalType` VARCHAR(191) NOT NULL,
  `goalValue` INT NOT NULL,
  `pointsReward` INT NOT NULL DEFAULT 0,
  `badgeId` VARCHAR(191) NULL,
  `startDate` DATETIME(3) NOT NULL,
  `endDate` DATETIME(3) NULL,
  `isActive` BOOLEAN NOT NULL DEFAULT true,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Challenge_slug_key`(`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `ChallengeProgress` (
  `id` VARCHAR(191) NOT NULL,
  `challengeId` VARCHAR(191) NOT NULL,
  `memberId` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NULL,
  `progress` INT NOT NULL DEFAULT 0,
  `completed` BOOLEAN NOT NULL DEFAULT false,
  `completedAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `ChallengeProgress_challengeId_memberId_key`(`challengeId`, `memberId`),
  CONSTRAINT `ChallengeProgress_challengeId_fkey` FOREIGN KEY (`challengeId`) REFERENCES `Challenge`(`id`) ON DELETE CASCADE,
  CONSTRAINT `ChallengeProgress_memberId_fkey` FOREIGN KEY (`memberId`) REFERENCES `Member`(`id`) ON DELETE CASCADE,
  CONSTRAINT `ChallengeProgress_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Activity` (
  `id` VARCHAR(191) NOT NULL,
  `cellId` VARCHAR(191) NULL,
  `eventId` VARCHAR(191) NULL,
  `name` VARCHAR(191) NOT NULL,
  `activityType` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `date` DATETIME(3) NOT NULL,
  `pointsReward` INT NOT NULL DEFAULT 0,
  `ledByUserId` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  CONSTRAINT `Activity_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Event`(`id`),
  CONSTRAINT `Activity_cellId_fkey` FOREIGN KEY (`cellId`) REFERENCES `Cell`(`id`),
  CONSTRAINT `Activity_ledByUserId_fkey` FOREIGN KEY (`ledByUserId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `ActivityParticipation` (
  `id` VARCHAR(191) NOT NULL,
  `activityId` VARCHAR(191) NOT NULL,
  `memberId` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NULL,
  `participatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `pointsAwarded` INT NOT NULL DEFAULT 0,
  `notes` VARCHAR(191) NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `ActivityParticipation_activityId_memberId_key`(`activityId`, `memberId`),
  CONSTRAINT `ActivityParticipation_activityId_fkey` FOREIGN KEY (`activityId`) REFERENCES `Activity`(`id`) ON DELETE CASCADE,
  CONSTRAINT `ActivityParticipation_memberId_fkey` FOREIGN KEY (`memberId`) REFERENCES `Member`(`id`) ON DELETE CASCADE,
  CONSTRAINT `ActivityParticipation_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Conversation` (
  `id` VARCHAR(191) NOT NULL,
  `cellId` VARCHAR(191) NULL,
  `type` VARCHAR(191) NOT NULL DEFAULT 'DIRECT',
  `name` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `Conversation_cellId_fkey` FOREIGN KEY (`cellId`) REFERENCES `Cell`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `ConversationParticipant` (
  `id` VARCHAR(191) NOT NULL,
  `conversationId` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `lastReadAt` DATETIME(3) NULL,
  `muted` BOOLEAN NOT NULL DEFAULT false,
  `joinedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE INDEX `ConversationParticipant_conversationId_userId_key`(`conversationId`, `userId`),
  CONSTRAINT `ConversationParticipant_conversationId_fkey` FOREIGN KEY (`conversationId`) REFERENCES `Conversation`(`id`) ON DELETE CASCADE,
  CONSTRAINT `ConversationParticipant_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Message` (
  `id` VARCHAR(191) NOT NULL,
  `conversationId` VARCHAR(191) NOT NULL,
  `senderId` VARCHAR(191) NOT NULL,
  `body` TEXT NOT NULL,
  `messageType` VARCHAR(191) NOT NULL DEFAULT 'TEXT',
  `attachmentUrl` VARCHAR(191) NULL,
  `replyToId` VARCHAR(191) NULL,
  `isDeleted` BOOLEAN NOT NULL DEFAULT false,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  INDEX `Message_conversationId_idx`(`conversationId`),
  CONSTRAINT `Message_conversationId_fkey` FOREIGN KEY (`conversationId`) REFERENCES `Conversation`(`id`) ON DELETE CASCADE,
  CONSTRAINT `Message_senderId_fkey` FOREIGN KEY (`senderId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Announcement` (
  `id` VARCHAR(191) NOT NULL,
  `cellId` VARCHAR(191) NULL,
  `eventId` VARCHAR(191) NULL,
  `authorId` VARCHAR(191) NOT NULL,
  `title` VARCHAR(191) NOT NULL,
  `body` TEXT NOT NULL,
  `category` VARCHAR(191) NOT NULL DEFAULT 'GENERAL',
  `priority` VARCHAR(191) NOT NULL DEFAULT 'NORMAL',
  `isPinned` BOOLEAN NOT NULL DEFAULT false,
  `publishedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `expiresAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  INDEX `Announcement_cellId_idx`(`cellId`),
  CONSTRAINT `Announcement_cellId_fkey` FOREIGN KEY (`cellId`) REFERENCES `Cell`(`id`),
  CONSTRAINT `Announcement_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Event`(`id`),
  CONSTRAINT `Announcement_authorId_fkey` FOREIGN KEY (`authorId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Notification` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `type` VARCHAR(191) NOT NULL,
  `title` VARCHAR(191) NOT NULL,
  `body` TEXT NULL,
  `link` VARCHAR(191) NULL,
  `data` TEXT NULL,
  `isRead` BOOLEAN NOT NULL DEFAULT false,
  `readAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  INDEX `Notification_userId_isRead_idx`(`userId`, `isRead`),
  CONSTRAINT `Notification_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Document` (
  `id` VARCHAR(191) NOT NULL,
  `cellId` VARCHAR(191) NULL,
  `title` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `fileUrl` VARCHAR(191) NOT NULL,
  `fileType` VARCHAR(191) NOT NULL,
  `fileSize` INT NULL,
  `category` VARCHAR(191) NULL,
  `accessLevel` VARCHAR(191) NOT NULL DEFAULT 'MEMBERS',
  `uploadedById` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  CONSTRAINT `Document_cellId_fkey` FOREIGN KEY (`cellId`) REFERENCES `Cell`(`id`),
  CONSTRAINT `Document_uploadedById_fkey` FOREIGN KEY (`uploadedById`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `CertificateTemplate` (
  `id` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `description` TEXT NULL,
  `template` LONGTEXT NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE INDEX `CertificateTemplate_name_key`(`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Certificate` (
  `id` VARCHAR(191) NOT NULL,
  `templateId` VARCHAR(191) NULL,
  `memberId` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NULL,
  `certificateNumber` VARCHAR(191) NOT NULL,
  `title` VARCHAR(191) NOT NULL,
  `program` VARCHAR(191) NOT NULL,
  `issuedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `issuedById` VARCHAR(191) NULL,
  `verificationCode` VARCHAR(191) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Certificate_certificateNumber_key`(`certificateNumber`),
  UNIQUE INDEX `Certificate_verificationCode_key`(`verificationCode`),
  CONSTRAINT `Certificate_templateId_fkey` FOREIGN KEY (`templateId`) REFERENCES `CertificateTemplate`(`id`),
  CONSTRAINT `Certificate_memberId_fkey` FOREIGN KEY (`memberId`) REFERENCES `Member`(`id`) ON DELETE CASCADE,
  CONSTRAINT `Certificate_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`),
  CONSTRAINT `Certificate_issuedById_fkey` FOREIGN KEY (`issuedById`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `AuditLog` (
  `id` VARCHAR(191) NOT NULL,
  `actorId` VARCHAR(191) NULL,
  `action` VARCHAR(191) NOT NULL,
  `objectType` VARCHAR(191) NOT NULL,
  `objectId` VARCHAR(191) NULL,
  `oldValue` LONGTEXT NULL,
  `newValue` LONGTEXT NULL,
  `ipAddress` VARCHAR(191) NULL,
  `userAgent` TEXT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  INDEX `AuditLog_actorId_idx`(`actorId`),
  INDEX `AuditLog_objectType_idx`(`objectType`),
  INDEX `AuditLog_createdAt_idx`(`createdAt`),
  CONSTRAINT `AuditLog_actorId_fkey` FOREIGN KEY (`actorId`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `Setting` (
  `id` VARCHAR(191) NOT NULL,
  `key` VARCHAR(191) NOT NULL,
  `value` LONGTEXT NOT NULL,
  `category` VARCHAR(191) NOT NULL DEFAULT 'GENERAL',
  `updatedById` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `Setting_key_key`(`key`),
  CONSTRAINT `Setting_updatedById_fkey` FOREIGN KEY (`updatedById`) REFERENCES `User`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed data

-- Data for User
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj5x000lkhk2bk2tnd1n', 'superadmin@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'System Super Admin', NULL, 'SUPER_ADMIN', 'ACTIVE', 0, '2026-10-07 23:31:24', '2026-10-08 05:23:18', '2026-10-07 23:31:24', '2026-10-08 05:23:18');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj5y000mkhk299eijc44', 'leader@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Sister Lizzy Okoro', NULL, 'CELL_ADMIN', 'ACTIVE', 0, '2026-10-07 23:31:24', '2026-10-08 05:22:58', '2026-10-07 23:31:24', '2026-10-08 05:22:58');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj60000nkhk2zloo0v64', 'assistant@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Brother Chidi Eze', NULL, 'ASSISTANT', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj61000okhk2d6uwwbu3', 'worker1@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Sister Ngozi Adichie', NULL, 'WORKER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj62000pkhk2b7i5bjhm', 'worker2@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Brother Emeka Obi', NULL, 'WORKER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj63000qkhk2imrxdkkr', 'worker3@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Sister Amara Nwosu', NULL, 'WORKER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj63000rkhk215jbdhmc', 'member1@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'John Egbuna', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', '2026-10-08 05:23:04', '2026-10-07 23:31:24', '2026-10-08 05:23:04');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj64000skhk2cjbhfw91', 'member2@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Grace Okwu', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj65000tkhk2hyybrmjv', 'member3@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'David Onuoha', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj66000ukhk2sdknjbkv', 'member4@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Faith Aniekwe', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj67000vkhk2u87se85d', 'member5@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Samuel Ike', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj69000wkhk2s9h763bm', 'member6@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Blessing Eze', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6a000xkhk2gsff9owk', 'member7@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Joseph Nwankwo', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6c000ykhk2023ja7yf', 'member8@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Esther Okafor', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6e000zkhk2y13zw71a', 'member9@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Peter Madu', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6f0010khk2zpmbjowj', 'member10@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Ruth Chukwu', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6h0011khk2k8wkcn7d', 'visitor1@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Daniel Uche', NULL, 'VISITOR', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6i0012khk2xg4aoery', 'visitor2@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Mary Adebayo', NULL, 'VISITOR', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6j0013khk2f9pfnjez', 'visitor3@vanguard.test', NULL, '$2b$10$cTAmaYXTbrmvQdIy2o151uAUrCqXys9mxcbfE5j4eSTH7RzUrojqe', 'Paul Okeke', NULL, 'VISITOR', 'ACTIVE', 0, '2026-10-07 23:31:24', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `User` (`id`, `email`, `phone`, `passwordHash`, `name`, `preferredName`, `role`, `status`, `twoFactorEnabled`, `emailVerifiedAt`, `lastLoginAt`, `createdAt`, `updatedAt`) VALUES ('cmuz2l3qa000ckhyx7oolqsp9', 'testnew@test.com', '+234 809 999 0000', '$2b$10$05QJOyANRJfb4TVDLE6bNOiYPWYcwc2dL0D8F.X1XKnEbHM7OSeTW', 'Test Newuser', NULL, 'MEMBER', 'ACTIVE', 0, '2026-10-08 05:02:20', NULL, '2026-10-08 05:02:20', '2026-10-08 05:02:20');

-- Data for Church
INSERT INTO `Church` (`id`, `name`, `slug`, `description`, `logoUrl`, `contactEmail`, `contactPhone`, `address`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj360000khk291jl48iv', 'Christ Embassy', 'christ-embassy', 'LoveWorld / Christ Embassy', NULL, 'info@christembassy.org', NULL, 'Lagos, Nigeria', '2026-10-07 23:31:24', '2026-10-07 23:31:24');

-- Data for Zone
INSERT INTO `Zone` (`id`, `churchId`, `name`, `slug`, `description`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj390002khk2ahi9nbum', 'cmuyqrj360000khk291jl48iv', 'Awka Zone', 'awka-zone', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');

-- Data for Cell
INSERT INTO `Cell` (`id`, `churchId`, `zoneId`, `name`, `slug`, `description`, `meetingDay`, `meetingTime`, `venue`, `address`, `leaderUserId`, `logoUrl`, `brandColor`, `accentColor`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj360000khk291jl48iv', 'cmuyqrj390002khk2ahi9nbum', 'Vanguard Cell 1', 'vanguard-cell-1', 'Vanguard Cell 1 — Awka Church', 'SATURDAY', '16:00', 'Sister Lizzy\'s House', 'Awka, Anambra State, Nigeria', NULL, NULL, '#0B2A5B', '#D4AF37', '2026-10-07 23:31:24', '2026-10-07 23:31:24');

-- Data for Rank
INSERT INTO `Rank` (`id`, `name`, `level`, `minPoints`, `color`, `icon`, `description`, `createdAt`) VALUES ('cmuyqrj3c0005khk2ccha8wyz', 'Newcomer', 1, 0, '#6B7280', '🌱', NULL, '2026-10-07 23:31:24');
INSERT INTO `Rank` (`id`, `name`, `level`, `minPoints`, `color`, `icon`, `description`, `createdAt`) VALUES ('cmuyqrj3d0006khk2tbuymfhz', 'Participant', 2, 50, '#0EA5E9', '👣', NULL, '2026-10-07 23:31:24');
INSERT INTO `Rank` (`id`, `name`, `level`, `minPoints`, `color`, `icon`, `description`, `createdAt`) VALUES ('cmuyqrj3e0007khk2iaqvu5a5', 'Committed', 3, 150, '#123F8C', '🤝', NULL, '2026-10-07 23:31:24');
INSERT INTO `Rank` (`id`, `name`, `level`, `minPoints`, `color`, `icon`, `description`, `createdAt`) VALUES ('cmuyqrj3e0008khk24t09bzki', 'Active', 4, 300, '#0B2A5B', '⚡', NULL, '2026-10-07 23:31:24');
INSERT INTO `Rank` (`id`, `name`, `level`, `minPoints`, `color`, `icon`, `description`, `createdAt`) VALUES ('cmuyqrj3f0009khk2d0ddgjfb', 'Faithful', 5, 500, '#D4AF37', '🔥', NULL, '2026-10-07 23:31:24');
INSERT INTO `Rank` (`id`, `name`, `level`, `minPoints`, `color`, `icon`, `description`, `createdAt`) VALUES ('cmuyqrj3g000akhk21hyzlg18', 'Champion', 6, 800, '#E7B93E', '🏆', NULL, '2026-10-07 23:31:24');
INSERT INTO `Rank` (`id`, `name`, `level`, `minPoints`, `color`, `icon`, `description`, `createdAt`) VALUES ('cmuyqrj3h000bkhk2jm92opt4', 'Vanguard', 7, 1200, '#7C3AED', '🚀', NULL, '2026-10-07 23:31:24');

-- Data for Badge
INSERT INTO `Badge` (`id`, `name`, `slug`, `description`, `icon`, `color`, `criteria`, `pointsReward`, `isActive`, `createdAt`) VALUES ('cmuyqrj3i000ckhk2t7fvo6uz', 'First Step', 'first-step', 'Attended your first event.', '🏅', '#10B981', '{"type":"ATTEND_COUNT","value":1}', 5, 1, '2026-10-07 23:31:24');
INSERT INTO `Badge` (`id`, `name`, `slug`, `description`, `icon`, `color`, `criteria`, `pointsReward`, `isActive`, `createdAt`) VALUES ('cmuyqrj3j000dkhk2b2fvvt84', 'Faithful', 'faithful', 'Attended 4 consecutive meetings.', '🔥', '#D4AF37', '{"type":"STREAK","value":4}', 25, 1, '2026-10-07 23:31:24');
INSERT INTO `Badge` (`id`, `name`, `slug`, `description`, `icon`, `color`, `criteria`, `pointsReward`, `isActive`, `createdAt`) VALUES ('cmuyqrj3k000ekhk2a3b4rwca', 'Consistent', 'consistent', 'Attended 8 consecutive meetings.', '🎯', '#E7B93E', '{"type":"STREAK","value":8}', 50, 1, '2026-10-07 23:31:24');
INSERT INTO `Badge` (`id`, `name`, `slug`, `description`, `icon`, `color`, `criteria`, `pointsReward`, `isActive`, `createdAt`) VALUES ('cmuyqrj3l000fkhk2ksmtk0h2', 'Committed', 'committed', 'Maintained 90%+ attendance over 8+ events.', '⭐', '#123F8C', '{"type":"ATTENDANCE_RATE","value":90,"minEvents":8}', 50, 1, '2026-10-07 23:31:24');
INSERT INTO `Badge` (`id`, `name`, `slug`, `description`, `icon`, `color`, `criteria`, `pointsReward`, `isActive`, `createdAt`) VALUES ('cmuyqrj3m000gkhk2liwvzl3t', 'Welcomer', 'welcomer', 'Successfully brought a registered guest.', '🤝', '#0EA5E9', '{"type":"INVITED_GUEST"}', 10, 1, '2026-10-07 23:31:24');
INSERT INTO `Badge` (`id`, `name`, `slug`, `description`, `icon`, `color`, `criteria`, `pointsReward`, `isActive`, `createdAt`) VALUES ('cmuyqrj3n000hkhk25z20okig', 'Learner', 'learner', 'Completed a training activity.', '📖', '#7C3AED', '{"type":"TRAINING_COMPLETE"}', 20, 1, '2026-10-07 23:31:24');
INSERT INTO `Badge` (`id`, `name`, `slug`, `description`, `icon`, `color`, `criteria`, `pointsReward`, `isActive`, `createdAt`) VALUES ('cmuyqrj3o000ikhk2d8srk2nt', 'Prayer Champion', 'prayer-champion', 'Participated in designated prayer activities.', '🙏', '#0B2A5B', '{"type":"ACTIVITY_TYPE","value":"PRAYER","count":3}', 15, 1, '2026-10-07 23:31:24');
INSERT INTO `Badge` (`id`, `name`, `slug`, `description`, `icon`, `color`, `criteria`, `pointsReward`, `isActive`, `createdAt`) VALUES ('cmuyqrj3p000jkhk2whxc2we2', 'Growing', 'growing', 'Completed the new-member journey.', '🌱', '#22C55E', '{"type":"NEW_MEMBER_JOURNEY"}', 15, 1, '2026-10-07 23:31:24');
INSERT INTO `Badge` (`id`, `name`, `slug`, `description`, `icon`, `color`, `criteria`, `pointsReward`, `isActive`, `createdAt`) VALUES ('cmuyqrj3q000kkhk2inetgiir', 'Vanguard', 'vanguard', 'Reached the Vanguard rank.', '🚀', '#D4AF37', '{"type":"RANK","value":7}', 0, 1, '2026-10-07 23:31:24');

-- Data for Member
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6l0015khk2xqmst5u1', 'cmuyqrj5y000mkhk299eijc44', 'cmuyqrj3a0004khk23qzzyiv7', 'Sister Lizzy Okoro', 'Sister', NULL, 'MALE', NULL, '+234 8010000000', NULL, 'leader@vanguard.test', NULL, NULL, NULL, NULL, 'CELL_LEADER', NULL, '2026-07-09 23:31:24', NULL, NULL, NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 47.5, 240, 'cmuyqrj3d0006khk2tbuymfhz', 8, 8, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6m0017khk2z2tfgdjb', 'cmuyqrj60000nkhk2zloo0v64', 'cmuyqrj3a0004khk23qzzyiv7', 'Brother Chidi Eze', 'Brother', NULL, 'FEMALE', NULL, '+234 8010000137', NULL, 'assistant@vanguard.test', NULL, NULL, NULL, NULL, 'WORKER', NULL, '2026-07-14 23:31:24', NULL, NULL, NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 50, 135, 'cmuyqrj3d0006khk2tbuymfhz', 7, 7, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6o0019khk2zvd2mmhn', 'cmuyqrj61000okhk2d6uwwbu3', 'cmuyqrj3a0004khk23qzzyiv7', 'Sister Ngozi Adichie', 'Sister', NULL, 'MALE', NULL, '+234 8010000274', NULL, 'worker1@vanguard.test', NULL, NULL, NULL, NULL, 'WORKER', NULL, '2026-07-19 23:31:24', NULL, NULL, NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 47.5, 240, 'cmuyqrj3d0006khk2tbuymfhz', 8, 8, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6p001bkhk2oxesrt2g', 'cmuyqrj62000pkhk2b7i5bjhm', 'cmuyqrj3a0004khk23qzzyiv7', 'Brother Emeka Obi', 'Brother', NULL, 'FEMALE', NULL, '+234 8010000411', NULL, 'worker2@vanguard.test', NULL, NULL, NULL, NULL, 'WORKER', NULL, '2026-07-24 23:31:24', NULL, NULL, NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 47.5, 250, 'cmuyqrj3d0006khk2tbuymfhz', 8, 8, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6s001dkhk2c30gxcvj', 'cmuyqrj63000qkhk2imrxdkkr', 'cmuyqrj3a0004khk23qzzyiv7', 'Sister Amara Nwosu', 'Sister', NULL, 'MALE', NULL, '+234 8010000548', NULL, 'worker3@vanguard.test', NULL, NULL, NULL, NULL, 'WORKER', NULL, '2026-07-29 23:31:24', NULL, NULL, NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 50, 145, 'cmuyqrj3d0006khk2tbuymfhz', 7, 7, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6t001fkhk25kone0g0', 'cmuyqrj63000rkhk215jbdhmc', 'cmuyqrj3a0004khk23qzzyiv7', 'John Egbuna', 'John', NULL, 'FEMALE', NULL, '+234 8010000685', NULL, 'member1@vanguard.test', NULL, NULL, NULL, NULL, 'REGULAR_MEMBER', NULL, '2026-08-03 23:31:24', NULL, 'cmuyqrj63000qkhk2imrxdkkr', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 50, 260, 'cmuyqrj3d0006khk2tbuymfhz', 8, 8, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6u001hkhk2u2j4ewjt', 'cmuyqrj64000skhk2cjbhfw91', 'cmuyqrj3a0004khk23qzzyiv7', 'Grace Okwu', 'Grace', NULL, 'MALE', NULL, '+234 8010000822', NULL, 'member2@vanguard.test', NULL, NULL, NULL, NULL, 'NEW_MEMBER', NULL, '2026-08-08 23:31:24', NULL, 'cmuyqrj61000okhk2d6uwwbu3', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 83.33333333333334, 41.7, 105, 'cmuyqrj3d0006khk2tbuymfhz', 5, 5, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6w001jkhk2cmxa0squ', 'cmuyqrj65000tkhk2hyybrmjv', 'cmuyqrj3a0004khk23qzzyiv7', 'David Onuoha', 'David', NULL, 'FEMALE', NULL, '+234 8010000959', NULL, 'member3@vanguard.test', NULL, NULL, NULL, NULL, 'WORKER', NULL, '2026-08-13 23:31:24', NULL, 'cmuyqrj62000pkhk2b7i5bjhm', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 48.6, 130, 'cmuyqrj3d0006khk2tbuymfhz', 7, 7, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6x001lkhk2dhdmqj3b', 'cmuyqrj66000ukhk2sdknjbkv', 'cmuyqrj3a0004khk23qzzyiv7', 'Faith Aniekwe', 'Faith', NULL, 'MALE', NULL, '+234 8010001096', NULL, 'member4@vanguard.test', NULL, NULL, NULL, NULL, 'ACTIVE_MEMBER', NULL, '2026-08-18 23:31:24', NULL, 'cmuyqrj63000qkhk2imrxdkkr', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 71.42857142857143, 35.7, 105, 'cmuyqrj3d0006khk2tbuymfhz', 5, 5, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj6z001nkhk2dre3caqg', 'cmuyqrj67000vkhk2u87se85d', 'cmuyqrj3a0004khk23qzzyiv7', 'Samuel Ike', 'Samuel', NULL, 'FEMALE', NULL, '+234 8010001233', NULL, 'member5@vanguard.test', NULL, NULL, NULL, NULL, 'REGULAR_MEMBER', NULL, '2026-08-23 23:31:24', NULL, 'cmuyqrj61000okhk2d6uwwbu3', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 48.6, 130, 'cmuyqrj3d0006khk2tbuymfhz', 7, 7, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj71001pkhk2e20fb6p6', 'cmuyqrj69000wkhk2s9h763bm', 'cmuyqrj3a0004khk23qzzyiv7', 'Blessing Eze', 'Blessing', NULL, 'MALE', NULL, '+234 8010001370', NULL, 'member6@vanguard.test', NULL, NULL, NULL, NULL, 'NEW_MEMBER', NULL, '2026-08-28 23:31:24', NULL, 'cmuyqrj62000pkhk2b7i5bjhm', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 50, 250, 'cmuyqrj3d0006khk2tbuymfhz', 8, 8, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj72001rkhk2v2a8phjd', 'cmuyqrj6a000xkhk2gsff9owk', 'cmuyqrj3a0004khk23qzzyiv7', 'Joseph Nwankwo', 'Joseph', NULL, 'FEMALE', NULL, '+234 8010001507', NULL, 'member7@vanguard.test', NULL, NULL, NULL, NULL, 'WORKER', NULL, '2026-09-02 23:31:24', NULL, 'cmuyqrj63000qkhk2imrxdkkr', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 48.6, 130, 'cmuyqrj3d0006khk2tbuymfhz', 7, 7, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj74001tkhk22t0fdz37', 'cmuyqrj6c000ykhk2023ja7yf', 'cmuyqrj3a0004khk23qzzyiv7', 'Esther Okafor', 'Esther', NULL, 'MALE', NULL, '+234 8010001644', NULL, 'member8@vanguard.test', NULL, NULL, NULL, NULL, 'ACTIVE_MEMBER', NULL, '2026-09-07 23:31:24', NULL, 'cmuyqrj61000okhk2d6uwwbu3', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 50, 250, 'cmuyqrj3d0006khk2tbuymfhz', 8, 8, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj76001vkhk2jd4onj3q', 'cmuyqrj6e000zkhk2y13zw71a', 'cmuyqrj3a0004khk23qzzyiv7', 'Peter Madu', 'Peter', NULL, 'FEMALE', NULL, '+234 8010001781', NULL, 'member9@vanguard.test', NULL, NULL, NULL, NULL, 'REGULAR_MEMBER', NULL, '2026-09-12 23:31:24', NULL, 'cmuyqrj62000pkhk2b7i5bjhm', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 50, 65, 'cmuyqrj3d0006khk2tbuymfhz', 1, 3, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj77001xkhk2wauf7lkp', 'cmuyqrj6f0010khk2zpmbjowj', 'cmuyqrj3a0004khk23qzzyiv7', 'Ruth Chukwu', 'Ruth', NULL, 'MALE', NULL, '+234 8010001918', NULL, 'member10@vanguard.test', NULL, NULL, NULL, NULL, 'NEW_MEMBER', NULL, '2026-09-17 23:31:24', NULL, 'cmuyqrj63000qkhk2imrxdkkr', NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 100, 48.8, 245, 'cmuyqrj3d0006khk2tbuymfhz', 8, 8, '2026-10-07 23:31:24', '2026-10-07 23:31:25');
INSERT INTO `Member` (`id`, `userId`, `cellId`, `fullName`, `preferredName`, `photoUrl`, `gender`, `dateOfBirth`, `phone`, `whatsapp`, `email`, `address`, `location`, `occupation`, `emergencyContact`, `status`, `memberCategory`, `dateJoinedCell`, `dateConverted`, `assignedWorkerId`, `spiritualMilestones`, `notes`, `accountStatus`, `isMinor`, `guardianName`, `guardianConsent`, `lastAttendanceAt`, `attendancePercentage`, `engagementScore`, `currentPoints`, `currentRankId`, `currentStreak`, `longestStreak`, `createdAt`, `updatedAt`) VALUES ('cmuz2l3rb000ekhyx7m0sbmah', 'cmuz2l3qa000ckhyx7oolqsp9', 'cmuyqrj3a0004khk23qzzyiv7', 'Test Newuser', 'Test', NULL, NULL, NULL, '+234 809 999 0000', NULL, 'testnew@test.com', NULL, NULL, NULL, NULL, 'NEW_MEMBER', NULL, '2026-10-08 05:02:20', NULL, NULL, NULL, NULL, 'ACTIVE', 0, NULL, 0, NULL, 0, 0, 0, NULL, 0, 0, '2026-10-08 05:02:20', '2026-10-08 05:02:20');

-- Data for EventSeries
INSERT INTO `EventSeries` (`id`, `cellId`, `name`, `description`, `recurrenceRule`, `eventType`, `venue`, `address`, `hostUserId`, `createdById`, `isActive`, `startDate`, `endDate`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7c0022khk2xaoah5cg', 'cmuyqrj3a0004khk23qzzyiv7', 'Weekly Vanguard Cell Meeting', 'Weekly cell meeting — every Saturday at 4:00 PM at Sister Lizzy\'s House.', '{"frequency":"WEEKLY","dayOfWeek":6,"time":"16:00"}', 'WEEKLY_CELL_MEETING', 'Sister Lizzy\'s House', 'Awka, Anambra State', 'cmuyqrj5y000mkhk299eijc44', 'cmuyqrj5y000mkhk299eijc44', 1, '2026-01-01 00:00:00', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `EventSeries` (`id`, `cellId`, `name`, `description`, `recurrenceRule`, `eventType`, `venue`, `address`, `hostUserId`, `createdById`, `isActive`, `startDate`, `endDate`, `createdAt`, `updatedAt`) VALUES ('cmuz2gfo7001vkhgifmitk7mq', 'cmuyqrj3a0004khk23qzzyiv7', 'Weekly Vanguard Cell Meeting', 'Weekly cell meeting — every Saturday at 4:00 PM at Sister Lizzy\'s House.', '{"frequency":"WEEKLY","dayOfWeek":6,"time":"16:00"}', 'WEEKLY_CELL_MEETING', 'Sister Lizzy\'s House', 'Awka, Anambra State', 'cmuyqrj5y000mkhk299eijc44', 'cmuyqrj5y000mkhk299eijc44', 1, '2026-01-01 00:00:00', NULL, '2026-10-08 04:58:42', '2026-10-08 04:58:42');

-- Data for Event
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 15 Aug 2026', 'vanguard-meeting-2026-08-15', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-08-15 16:00:00', '2026-08-15 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'COMPLETED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 22 Aug 2026', 'vanguard-meeting-2026-08-22', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-08-22 16:00:00', '2026-08-22 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'COMPLETED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 29 Aug 2026', 'vanguard-meeting-2026-08-29', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-08-29 16:00:00', '2026-08-29 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'COMPLETED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 5 Sept 2026', 'vanguard-meeting-2026-09-05', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-09-05 16:00:00', '2026-09-05 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'COMPLETED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 12 Sept 2026', 'vanguard-meeting-2026-09-12', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-09-12 16:00:00', '2026-09-12 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'COMPLETED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 19 Sept 2026', 'vanguard-meeting-2026-09-19', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-09-19 16:00:00', '2026-09-19 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'COMPLETED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 26 Sept 2026', 'vanguard-meeting-2026-09-26', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-09-26 16:00:00', '2026-09-26 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'COMPLETED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7m002ikhk227q17bis', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 3 Oct 2026', 'vanguard-meeting-2026-10-03', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-10-03 16:00:00', '2026-10-03 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'COMPLETED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7n002kkhk2jh6c9yye', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 10 Oct 2026', 'vanguard-meeting-2026-10-10', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-10-10 16:00:00', '2026-10-10 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'PUBLISHED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7p002mkhk2rp59juy8', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 17 Oct 2026', 'vanguard-meeting-2026-10-17', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-10-17 16:00:00', '2026-10-17 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'PUBLISHED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7q002okhk2d3d9n1yc', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 24 Oct 2026', 'vanguard-meeting-2026-10-24', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-10-24 16:00:00', '2026-10-24 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'PUBLISHED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7r002qkhk2sak4jji5', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 31 Oct 2026', 'vanguard-meeting-2026-10-31', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-10-31 16:00:00', '2026-10-31 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'PUBLISHED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7s002skhk2lcgn3gwy', 'cmuyqrj3a0004khk23qzzyiv7', 'cmuyqrj7c0022khk2xaoah5cg', 'Vanguard Cell Meeting — 7 Nov 2026', 'vanguard-meeting-2026-11-07', 'Weekly cell meeting.', 'WEEKLY_CELL_MEETING', '2026-11-07 16:00:00', '2026-11-07 18:00:00', '16:00', '18:00', 'Sister Lizzy\'s House', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, 0, NULL, 1, 0, 'ANY', 1, 'PUBLISHED', 'MEMBERS_ONLY', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Event` (`id`, `cellId`, `seriesId`, `name`, `slug`, `description`, `eventType`, `startDate`, `endDate`, `startTime`, `endTime`, `venue`, `address`, `mapLink`, `hostUserId`, `coverImageUrl`, `capacity`, `registrationRequired`, `registrationDeadline`, `attendanceRequired`, `isPublic`, `memberEligibility`, `guestEligibility`, `status`, `accessRule`, `enableGeolocation`, `geoLat`, `geoLng`, `geoRadiusMeters`, `enablePin`, `enableQr`, `createdById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7t002ukhk2m478mv2m', 'cmuyqrj3a0004khk23qzzyiv7', NULL, 'Vanguard Cell End-of-Year Fellowship', 'vanguard-end-of-year-fellowship', 'A special end-of-year celebration with food, worship, and testimonies.', 'SOCIAL_FELLOWSHIP', '2026-12-20 18:00:00', '2026-12-20 21:00:00', '18:00', '21:00', 'Christ Embassy Awka Main Hall', 'Awka, Anambra State', NULL, 'cmuyqrj5y000mkhk299eijc44', NULL, 80, 1, '2026-12-13 18:00:00', 1, 1, 'ANY', 1, 'REGISTRATION_OPEN', 'ANYONE', 0, NULL, NULL, NULL, 1, 1, 'cmuyqrj5y000mkhk299eijc44', '2026-10-07 23:31:24', '2026-10-07 23:31:24');

-- Data for RegistrationField
INSERT INTO `RegistrationField` (`id`, `eventId`, `label`, `fieldKey`, `fieldType`, `options`, `required`, `order`, `createdAt`) VALUES ('cmuyqrj7t002wkhk2p01bymq7', 'cmuyqrj7t002ukhk2m478mv2m', 'Full Name', 'name', 'TEXT', NULL, 1, 1, '2026-10-07 23:31:24');
INSERT INTO `RegistrationField` (`id`, `eventId`, `label`, `fieldKey`, `fieldType`, `options`, `required`, `order`, `createdAt`) VALUES ('cmuyqrj7u002ykhk2j7fkd4wc', 'cmuyqrj7t002ukhk2m478mv2m', 'Phone Number', 'phone', 'PHONE', NULL, 1, 2, '2026-10-07 23:31:24');
INSERT INTO `RegistrationField` (`id`, `eventId`, `label`, `fieldKey`, `fieldType`, `options`, `required`, `order`, `createdAt`) VALUES ('cmuyqrj7v0030khk21qhno45k', 'cmuyqrj7t002ukhk2m478mv2m', 'Email', 'email', 'EMAIL', NULL, 0, 3, '2026-10-07 23:31:24');
INSERT INTO `RegistrationField` (`id`, `eventId`, `label`, `fieldKey`, `fieldType`, `options`, `required`, `order`, `createdAt`) VALUES ('cmuyqrj7v0032khk2ie4v460k', 'cmuyqrj7t002ukhk2m478mv2m', 'Gender', 'gender', 'RADIO', '["Male","Female"]', 1, 4, '2026-10-07 23:31:24');
INSERT INTO `RegistrationField` (`id`, `eventId`, `label`, `fieldKey`, `fieldType`, `options`, `required`, `order`, `createdAt`) VALUES ('cmuyqrj7v0034khk2nz1mercw', 'cmuyqrj7t002ukhk2m478mv2m', 'Number of Guests', 'num_guests', 'NUMBER', NULL, 1, 5, '2026-10-07 23:31:24');
INSERT INTO `RegistrationField` (`id`, `eventId`, `label`, `fieldKey`, `fieldType`, `options`, `required`, `order`, `createdAt`) VALUES ('cmuyqrj7w0036khk2s52p87v8', 'cmuyqrj7t002ukhk2m478mv2m', 'Dietary Information', 'dietary', 'TEXT', NULL, 0, 6, '2026-10-07 23:31:24');
INSERT INTO `RegistrationField` (`id`, `eventId`, `label`, `fieldKey`, `fieldType`, `options`, `required`, `order`, `createdAt`) VALUES ('cmuyqrj7w0038khk2abaowhds', 'cmuyqrj7t002ukhk2m478mv2m', 'Special Needs', 'special_needs', 'TEXTAREA', NULL, 0, 7, '2026-10-07 23:31:24');
INSERT INTO `RegistrationField` (`id`, `eventId`, `label`, `fieldKey`, `fieldType`, `options`, `required`, `order`, `createdAt`) VALUES ('cmuyqrj7x003akhk2zykl41n7', 'cmuyqrj7t002ukhk2m478mv2m', 'Consent to be photographed', 'consent', 'CONSENT', NULL, 1, 8, '2026-10-07 23:31:24');

-- Data for AttendanceRecord
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7z003ckhk2bj1k1bm9', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj6l0015khk2xqmst5u1', 'cmuyqrj5y000mkhk299eijc44', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj80003ekhk21dsj1ocp', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj6m0017khk2z2tfgdjb', 'cmuyqrj60000nkhk2zloo0v64', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj81003gkhk2pev3b7z6', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj6o0019khk2zvd2mmhn', 'cmuyqrj61000okhk2d6uwwbu3', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj81003ikhk2yrcoq9y3', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj6p001bkhk2oxesrt2g', 'cmuyqrj62000pkhk2b7i5bjhm', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj82003kkhk2rks00ek4', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj6s001dkhk2c30gxcvj', 'cmuyqrj63000qkhk2imrxdkkr', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj82003mkhk2sg7zlakp', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj6t001fkhk25kone0g0', 'cmuyqrj63000rkhk215jbdhmc', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj83003okhk2e46p4eth', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj6w001jkhk2cmxa0squ', 'cmuyqrj65000tkhk2hyybrmjv', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj84003qkhk24u0y557y', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj6x001lkhk2dhdmqj3b', 'cmuyqrj66000ukhk2sdknjbkv', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8e003skhk2xadwb9c5', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj6z001nkhk2dre3caqg', 'cmuyqrj67000vkhk2u87se85d', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8e003ukhk28zjlu2ni', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj71001pkhk2e20fb6p6', 'cmuyqrj69000wkhk2s9h763bm', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8f003wkhk2cud71qdg', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj72001rkhk2v2a8phjd', 'cmuyqrj6a000xkhk2gsff9owk', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8g003ykhk29pqp6cvn', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj74001tkhk22t0fdz37', 'cmuyqrj6c000ykhk2023ja7yf', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8g0040khk2ev58hnkd', 'cmuyqrj7f0024khk2xrxg2m8k', 'cmuyqrj77001xkhk2wauf7lkp', 'cmuyqrj6f0010khk2zpmbjowj', 'PRESENT', 'MANUAL', '2026-08-15 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8h0042khk2ulr6814p', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6l0015khk2xqmst5u1', 'cmuyqrj5y000mkhk299eijc44', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8j0044khk204udqscq', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6m0017khk2z2tfgdjb', 'cmuyqrj60000nkhk2zloo0v64', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8j0046khk2kfbbw3sl', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6o0019khk2zvd2mmhn', 'cmuyqrj61000okhk2d6uwwbu3', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8k0048khk2hmxihxok', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6p001bkhk2oxesrt2g', 'cmuyqrj62000pkhk2b7i5bjhm', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8m004akhk2g7xc35c0', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6s001dkhk2c30gxcvj', 'cmuyqrj63000qkhk2imrxdkkr', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8n004ckhk22zh67lgh', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6t001fkhk25kone0g0', 'cmuyqrj63000rkhk215jbdhmc', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8o004ekhk2nj3tq8lp', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6u001hkhk2u2j4ewjt', 'cmuyqrj64000skhk2cjbhfw91', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8o004gkhk2oexwpuox', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6w001jkhk2cmxa0squ', 'cmuyqrj65000tkhk2hyybrmjv', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8p004ikhk272j4awen', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6x001lkhk2dhdmqj3b', 'cmuyqrj66000ukhk2sdknjbkv', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8q004kkhk2ayxfe0kb', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj6z001nkhk2dre3caqg', 'cmuyqrj67000vkhk2u87se85d', 'LATE', 'MANUAL', '2026-08-22 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8q004mkhk2lk1xtlty', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj71001pkhk2e20fb6p6', 'cmuyqrj69000wkhk2s9h763bm', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8r004okhk282qonht9', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj72001rkhk2v2a8phjd', 'cmuyqrj6a000xkhk2gsff9owk', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8s004qkhk2a44e01eh', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj74001tkhk22t0fdz37', 'cmuyqrj6c000ykhk2023ja7yf', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8t004skhk2013ov9v4', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj76001vkhk2jd4onj3q', 'cmuyqrj6e000zkhk2y13zw71a', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8u004ukhk2gz9q7yv0', 'cmuyqrj7h0026khk2fh7dhstb', 'cmuyqrj77001xkhk2wauf7lkp', 'cmuyqrj6f0010khk2zpmbjowj', 'PRESENT', 'MANUAL', '2026-08-22 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8u004wkhk23qomsqd7', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6l0015khk2xqmst5u1', 'cmuyqrj5y000mkhk299eijc44', 'LATE', 'MANUAL', '2026-08-29 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8v004ykhk2vokqhwqm', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6m0017khk2z2tfgdjb', 'cmuyqrj60000nkhk2zloo0v64', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8v0050khk21vsslp4o', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6o0019khk2zvd2mmhn', 'cmuyqrj61000okhk2d6uwwbu3', 'LATE', 'MANUAL', '2026-08-29 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8w0052khk2d8tddawy', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6p001bkhk2oxesrt2g', 'cmuyqrj62000pkhk2b7i5bjhm', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8x0054khk26hzt46fl', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6s001dkhk2c30gxcvj', 'cmuyqrj63000qkhk2imrxdkkr', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8x0056khk2990hmq9t', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6t001fkhk25kone0g0', 'cmuyqrj63000rkhk215jbdhmc', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8y0058khk232y08gm1', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6u001hkhk2u2j4ewjt', 'cmuyqrj64000skhk2cjbhfw91', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8z005akhk2pdmjd48e', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6w001jkhk2cmxa0squ', 'cmuyqrj65000tkhk2hyybrmjv', 'LATE', 'MANUAL', '2026-08-29 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj8z005ckhk21zajy9fm', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6x001lkhk2dhdmqj3b', 'cmuyqrj66000ukhk2sdknjbkv', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj90005ekhk2jfgl4pt7', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj6z001nkhk2dre3caqg', 'cmuyqrj67000vkhk2u87se85d', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj90005gkhk2pfbkec20', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj71001pkhk2e20fb6p6', 'cmuyqrj69000wkhk2s9h763bm', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj91005ikhk2zy7abkdm', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj72001rkhk2v2a8phjd', 'cmuyqrj6a000xkhk2gsff9owk', 'LATE', 'MANUAL', '2026-08-29 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj92005kkhk2sn48j1bn', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj74001tkhk22t0fdz37', 'cmuyqrj6c000ykhk2023ja7yf', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj92005mkhk2nkuzobmi', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj76001vkhk2jd4onj3q', 'cmuyqrj6e000zkhk2y13zw71a', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj93005okhk2io2thbur', 'cmuyqrj7i0028khk2l1oxuhel', 'cmuyqrj77001xkhk2wauf7lkp', 'cmuyqrj6f0010khk2zpmbjowj', 'PRESENT', 'MANUAL', '2026-08-29 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj94005qkhk2is2eetim', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj6l0015khk2xqmst5u1', 'cmuyqrj5y000mkhk299eijc44', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj94005skhk2ybant479', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj6m0017khk2z2tfgdjb', 'cmuyqrj60000nkhk2zloo0v64', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj95005ukhk23u4l75jl', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj6o0019khk2zvd2mmhn', 'cmuyqrj61000okhk2d6uwwbu3', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj96005wkhk2inhkqot0', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj6p001bkhk2oxesrt2g', 'cmuyqrj62000pkhk2b7i5bjhm', 'LATE', 'MANUAL', '2026-09-05 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj97005ykhk2zetja1by', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj6s001dkhk2c30gxcvj', 'cmuyqrj63000qkhk2imrxdkkr', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj970060khk200ejdmzs', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj6t001fkhk25kone0g0', 'cmuyqrj63000rkhk215jbdhmc', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj980062khk24creo289', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj6u001hkhk2u2j4ewjt', 'cmuyqrj64000skhk2cjbhfw91', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj990064khk29lkkav9o', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj6w001jkhk2cmxa0squ', 'cmuyqrj65000tkhk2hyybrmjv', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9a0066khk29wj3d6sa', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj6z001nkhk2dre3caqg', 'cmuyqrj67000vkhk2u87se85d', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9b0068khk2zykv6e26', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj71001pkhk2e20fb6p6', 'cmuyqrj69000wkhk2s9h763bm', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9b006akhk26hn9a4p4', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj72001rkhk2v2a8phjd', 'cmuyqrj6a000xkhk2gsff9owk', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9c006ckhk2s7mcihxu', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj74001tkhk22t0fdz37', 'cmuyqrj6c000ykhk2023ja7yf', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9d006ekhk20dk3jiz4', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj76001vkhk2jd4onj3q', 'cmuyqrj6e000zkhk2y13zw71a', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9e006gkhk2uqsg2euh', 'cmuyqrj7j002akhk28kcxyqkh', 'cmuyqrj77001xkhk2wauf7lkp', 'cmuyqrj6f0010khk2zpmbjowj', 'PRESENT', 'MANUAL', '2026-09-05 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9f006ikhk2dvyii0wp', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj6l0015khk2xqmst5u1', 'cmuyqrj5y000mkhk299eijc44', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9g006kkhk21m741io3', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj6o0019khk2zvd2mmhn', 'cmuyqrj61000okhk2d6uwwbu3', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9g006mkhk2qrcjk04l', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj6p001bkhk2oxesrt2g', 'cmuyqrj62000pkhk2b7i5bjhm', 'LATE', 'MANUAL', '2026-09-12 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9i006okhk2xq2h5ux9', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj6s001dkhk2c30gxcvj', 'cmuyqrj63000qkhk2imrxdkkr', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9i006qkhk2hdhvm03i', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj6t001fkhk25kone0g0', 'cmuyqrj63000rkhk215jbdhmc', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9j006skhk2st4t2vez', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj6u001hkhk2u2j4ewjt', 'cmuyqrj64000skhk2cjbhfw91', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9k006ukhk2b5aa6rbx', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj6x001lkhk2dhdmqj3b', 'cmuyqrj66000ukhk2sdknjbkv', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9l006wkhk20tli7ixz', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj6z001nkhk2dre3caqg', 'cmuyqrj67000vkhk2u87se85d', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9m006ykhk2uo7de85r', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj71001pkhk2e20fb6p6', 'cmuyqrj69000wkhk2s9h763bm', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9n0070khk2fhmxzc8g', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj72001rkhk2v2a8phjd', 'cmuyqrj6a000xkhk2gsff9owk', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9n0072khk20h6zy46s', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj74001tkhk22t0fdz37', 'cmuyqrj6c000ykhk2023ja7yf', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9o0074khk2n0pelvst', 'cmuyqrj7k002ckhk23ugl0vm3', 'cmuyqrj77001xkhk2wauf7lkp', 'cmuyqrj6f0010khk2zpmbjowj', 'PRESENT', 'MANUAL', '2026-09-12 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9p0076khk2qwmzixcb', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj6l0015khk2xqmst5u1', 'cmuyqrj5y000mkhk299eijc44', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9s0078khk2ex53gldj', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj6m0017khk2z2tfgdjb', 'cmuyqrj60000nkhk2zloo0v64', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9t007akhk2zxg0whlr', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj6o0019khk2zvd2mmhn', 'cmuyqrj61000okhk2d6uwwbu3', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9u007ckhk2o4az7hw9', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj6p001bkhk2oxesrt2g', 'cmuyqrj62000pkhk2b7i5bjhm', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9v007ekhk2p6z4kx0h', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj6t001fkhk25kone0g0', 'cmuyqrj63000rkhk215jbdhmc', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9w007gkhk2j7qhsph1', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj6u001hkhk2u2j4ewjt', 'cmuyqrj64000skhk2cjbhfw91', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9w007ikhk2tnrlojsg', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj6w001jkhk2cmxa0squ', 'cmuyqrj65000tkhk2hyybrmjv', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9x007kkhk2pnze16nm', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj6x001lkhk2dhdmqj3b', 'cmuyqrj66000ukhk2sdknjbkv', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9y007mkhk274hcyv9y', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj71001pkhk2e20fb6p6', 'cmuyqrj69000wkhk2s9h763bm', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj9z007okhk2pyhj1ssr', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj72001rkhk2v2a8phjd', 'cmuyqrj6a000xkhk2gsff9owk', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja0007qkhk206pl1eij', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj74001tkhk22t0fdz37', 'cmuyqrj6c000ykhk2023ja7yf', 'PRESENT', 'MANUAL', '2026-09-19 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja1007skhk2de1nh6sg', 'cmuyqrj7k002ekhk2weacv5zx', 'cmuyqrj77001xkhk2wauf7lkp', 'cmuyqrj6f0010khk2zpmbjowj', 'LATE', 'MANUAL', '2026-09-19 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja1007ukhk2vxtc5mje', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj6l0015khk2xqmst5u1', 'cmuyqrj5y000mkhk299eijc44', 'LATE', 'MANUAL', '2026-09-26 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja2007wkhk25ouoyfvl', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj6m0017khk2z2tfgdjb', 'cmuyqrj60000nkhk2zloo0v64', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja4007ykhk2ljr7fybw', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj6o0019khk2zvd2mmhn', 'cmuyqrj61000okhk2d6uwwbu3', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja50080khk2993p3psf', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj6p001bkhk2oxesrt2g', 'cmuyqrj62000pkhk2b7i5bjhm', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja60082khk269f53mqb', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj6s001dkhk2c30gxcvj', 'cmuyqrj63000qkhk2imrxdkkr', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja70084khk2prrukmty', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj6t001fkhk25kone0g0', 'cmuyqrj63000rkhk215jbdhmc', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja80086khk2dusm459l', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj6w001jkhk2cmxa0squ', 'cmuyqrj65000tkhk2hyybrmjv', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrja90088khk2dunsy1pq', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj6x001lkhk2dhdmqj3b', 'cmuyqrj66000ukhk2sdknjbkv', 'EXCUSED', 'MANUAL', NULL, NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjaa008akhk2uogmbfqb', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj6z001nkhk2dre3caqg', 'cmuyqrj67000vkhk2u87se85d', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjab008ckhk2kvqzghj4', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj71001pkhk2e20fb6p6', 'cmuyqrj69000wkhk2s9h763bm', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjab008ekhk2xwuxuk6l', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj72001rkhk2v2a8phjd', 'cmuyqrj6a000xkhk2gsff9owk', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjac008gkhk2w5bt1ovc', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj74001tkhk22t0fdz37', 'cmuyqrj6c000ykhk2023ja7yf', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjad008ikhk2a3uxsoer', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj76001vkhk2jd4onj3q', 'cmuyqrj6e000zkhk2y13zw71a', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjae008kkhk2bd9v1c02', 'cmuyqrj7l002gkhk2555l71v5', 'cmuyqrj77001xkhk2wauf7lkp', 'cmuyqrj6f0010khk2zpmbjowj', 'PRESENT', 'MANUAL', '2026-09-26 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjae008mkhk2zamimqkd', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6l0015khk2xqmst5u1', 'cmuyqrj5y000mkhk299eijc44', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjaf008okhk2remffspm', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6m0017khk2z2tfgdjb', 'cmuyqrj60000nkhk2zloo0v64', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjag008qkhk26gnn4pej', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6o0019khk2zvd2mmhn', 'cmuyqrj61000okhk2d6uwwbu3', 'LATE', 'MANUAL', '2026-10-03 16:20:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjah008skhk20zto4obz', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6p001bkhk2oxesrt2g', 'cmuyqrj62000pkhk2b7i5bjhm', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjah008ukhk2d1mrgt9h', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6s001dkhk2c30gxcvj', 'cmuyqrj63000qkhk2imrxdkkr', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjb5008wkhk2pfd8kxx2', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6t001fkhk25kone0g0', 'cmuyqrj63000rkhk215jbdhmc', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjb6008ykhk2bsyv6uzq', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6u001hkhk2u2j4ewjt', 'cmuyqrj64000skhk2cjbhfw91', 'EXCUSED', 'MANUAL', NULL, NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjb70090khk2ct53nxk2', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6w001jkhk2cmxa0squ', 'cmuyqrj65000tkhk2hyybrmjv', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjb70092khk2k4drokgn', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6x001lkhk2dhdmqj3b', 'cmuyqrj66000ukhk2sdknjbkv', 'EXCUSED', 'MANUAL', NULL, NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjb80094khk2edgl6sy3', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj6z001nkhk2dre3caqg', 'cmuyqrj67000vkhk2u87se85d', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjb90096khk29gywuhvf', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj71001pkhk2e20fb6p6', 'cmuyqrj69000wkhk2s9h763bm', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjba0098khk2sqvi1oy2', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj74001tkhk22t0fdz37', 'cmuyqrj6c000ykhk2023ja7yf', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `AttendanceRecord` (`id`, `eventId`, `memberId`, `userId`, `status`, `method`, `checkInTime`, `checkOutTime`, `durationMinutes`, `deviceIdentifier`, `verificationStatus`, `locationVerified`, `recordedById`, `notes`, `syncStatus`, `offlineUuid`, `createdAt`, `updatedAt`) VALUES ('cmuyqrjba009akhk2h9wbozuh', 'cmuyqrj7m002ikhk227q17bis', 'cmuyqrj77001xkhk2wauf7lkp', 'cmuyqrj6f0010khk2zpmbjowj', 'PRESENT', 'MANUAL', '2026-10-03 16:00:00', NULL, NULL, NULL, 'VERIFIED', 0, 'cmuyqrj5y000mkhk299eijc44', NULL, 'SYNCED', NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');

-- Data for Visitor
INSERT INTO `Visitor` (`id`, `memberId`, `cellId`, `fullName`, `phone`, `email`, `gender`, `invitedByMemberId`, `firstEventId`, `firstVisitDate`, `followUpStatus`, `convertedAt`, `notes`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj79001ykhk2u0c8l1ml', NULL, 'cmuyqrj3a0004khk23qzzyiv7', 'Daniel Uche', '+234 8020000000', 'visitor1@vanguard.test', NULL, 'cmuyqrj6p001bkhk2oxesrt2g', NULL, '2026-09-23 23:31:24', 'NEW', NULL, NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Visitor` (`id`, `memberId`, `cellId`, `fullName`, `phone`, `email`, `gender`, `invitedByMemberId`, `firstEventId`, `firstVisitDate`, `followUpStatus`, `convertedAt`, `notes`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7a001zkhk27xs6esbz', NULL, 'cmuyqrj3a0004khk23qzzyiv7', 'Mary Adebayo', '+234 8020000137', 'visitor2@vanguard.test', NULL, 'cmuyqrj6s001dkhk2c30gxcvj', NULL, '2026-09-23 23:31:24', 'CONTACTED', NULL, NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');
INSERT INTO `Visitor` (`id`, `memberId`, `cellId`, `fullName`, `phone`, `email`, `gender`, `invitedByMemberId`, `firstEventId`, `firstVisitDate`, `followUpStatus`, `convertedAt`, `notes`, `createdAt`, `updatedAt`) VALUES ('cmuyqrj7b0020khk2lx95p32s', NULL, 'cmuyqrj3a0004khk23qzzyiv7', 'Paul Okeke', '+234 8020000274', 'visitor3@vanguard.test', NULL, 'cmuyqrj6t001fkhk25kone0g0', NULL, '2026-09-23 23:31:24', 'ENGAGED', NULL, NULL, '2026-10-07 23:31:24', '2026-10-07 23:31:24');

-- Data for Challenge
INSERT INTO `Challenge` (`id`, `cellId`, `name`, `slug`, `description`, `goalType`, `goalValue`, `pointsReward`, `badgeId`, `startDate`, `endDate`, `isActive`, `createdAt`) VALUES ('cmuyqrk3j00pjkhk2gp9l6ir5', 'cmuyqrj3a0004khk23qzzyiv7', '4-Week Attendance Challenge', '4-week-attendance', 'Attend four consecutive weekly cell meetings.', 'ATTEND_CONSECUTIVE', 4, 50, NULL, '2026-10-07 23:31:25', NULL, 1, '2026-10-07 23:31:25');
INSERT INTO `Challenge` (`id`, `cellId`, `name`, `slug`, `description`, `goalType`, `goalValue`, `pointsReward`, `badgeId`, `startDate`, `endDate`, `isActive`, `createdAt`) VALUES ('cmuyqrk3k00pkkhk2gsa6ky1e', 'cmuyqrj3a0004khk23qzzyiv7', 'Invite a Guest', 'invite-a-guest', 'Bring a first-time guest to any cell event.', 'INVITE_GUEST', 1, 10, NULL, '2026-10-07 23:31:25', NULL, 1, '2026-10-07 23:31:25');

-- Data for Conversation
INSERT INTO `Conversation` (`id`, `cellId`, `type`, `name`, `createdAt`, `updatedAt`) VALUES ('cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj3a0004khk23qzzyiv7', 'CELL_GROUP', 'Vanguard Cell 1 — Cell Chat', '2026-10-07 23:31:25', '2026-10-07 23:31:25');

-- Data for ConversationParticipant
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3o00ptkhk21z43ko8q', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj5x000lkhk2bk2tnd1n', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3p00pvkhk25fx0g0fy', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj5y000mkhk299eijc44', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3p00pxkhk2j85im2pj', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj60000nkhk2zloo0v64', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3q00pzkhk2e8rtjiso', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj61000okhk2d6uwwbu3', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3r00q1khk29sx88nor', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj62000pkhk2b7i5bjhm', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3r00q3khk2jhpus3lj', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj63000qkhk2imrxdkkr', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3r00q5khk2vjwna9dd', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj63000rkhk215jbdhmc', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3s00q7khk2uxqyd20k', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj64000skhk2cjbhfw91', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3s00q9khk2eklx1er1', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj65000tkhk2hyybrmjv', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3s00qbkhk2ngm68x2x', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj66000ukhk2sdknjbkv', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3t00qdkhk2ipfs2em5', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj67000vkhk2u87se85d', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3t00qfkhk2rvi7e8nn', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj69000wkhk2s9h763bm', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3u00qhkhk2r79xn2a1', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj6a000xkhk2gsff9owk', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3u00qjkhk2u03uqr95', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj6c000ykhk2023ja7yf', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3v00qlkhk2n355nqu3', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj6e000zkhk2y13zw71a', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3v00qnkhk25rag8mg7', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj6f0010khk2zpmbjowj', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3v00qpkhk2693hpuxe', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj6h0011khk2k8wkcn7d', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3w00qrkhk2q5lwd7c3', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj6i0012khk2xg4aoery', NULL, 0, '2026-10-07 23:31:25');
INSERT INTO `ConversationParticipant` (`id`, `conversationId`, `userId`, `lastReadAt`, `muted`, `joinedAt`) VALUES ('cmuyqrk3w00qtkhk2lrhevc2y', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj6j0013khk2f9pfnjez', NULL, 0, '2026-10-07 23:31:25');

-- Data for Message
INSERT INTO `Message` (`id`, `conversationId`, `senderId`, `body`, `messageType`, `attachmentUrl`, `replyToId`, `isDeleted`, `createdAt`) VALUES ('cmuyqrk3x00qvkhk2nor7m7w9', 'cmuyqrk3o00prkhk24j3e473g', 'cmuyqrj5y000mkhk299eijc44', 'Welcome family! This is our new cell chat. Glory to God!', 'TEXT', NULL, NULL, 0, '2026-10-07 23:31:25');

-- Data for Announcement
INSERT INTO `Announcement` (`id`, `cellId`, `eventId`, `authorId`, `title`, `body`, `category`, `priority`, `isPinned`, `publishedAt`, `expiresAt`, `createdAt`) VALUES ('cmuyqrk3n00ppkhk22zne1nx2', 'cmuyqrj3a0004khk23qzzyiv7', NULL, 'cmuyqrj5y000mkhk299eijc44', 'Welcome to Vanguard Cell 1 PWA!', 'Praise God! We are excited to launch our new cell management app. Install it on your phone, register for events, check in with QR codes, and grow with us.', 'CELL', 'HIGH', 1, '2026-10-07 23:31:25', NULL, '2026-10-07 23:31:25');

-- Data for AuditLog
INSERT INTO `AuditLog` (`id`, `actorId`, `action`, `objectType`, `objectId`, `oldValue`, `newValue`, `ipAddress`, `userAgent`, `createdAt`) VALUES ('cmuyraccu0001khyxweyy4v08', 'cmuyqrj5y000mkhk299eijc44', 'LOGIN', 'User', 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/153.0.0.0 Safari/537.36', '2026-10-07 23:46:02');
INSERT INTO `AuditLog` (`id`, `actorId`, `action`, `objectType`, `objectId`, `oldValue`, `newValue`, `ipAddress`, `userAgent`, `createdAt`) VALUES ('cmuz2homd0003khyxmly8h8xd', 'cmuyqrj5x000lkhk2bk2tnd1n', 'LOGIN', 'User', 'cmuyqrj5x000lkhk2bk2tnd1n', NULL, NULL, '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/153.0.0.0 Safari/537.36', '2026-10-08 04:59:40');
INSERT INTO `AuditLog` (`id`, `actorId`, `action`, `objectType`, `objectId`, `oldValue`, `newValue`, `ipAddress`, `userAgent`, `createdAt`) VALUES ('cmuz2ic310005khyxxoy1g1jr', 'cmuyqrj5x000lkhk2bk2tnd1n', 'LOGIN', 'User', 'cmuyqrj5x000lkhk2bk2tnd1n', NULL, NULL, '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/153.0.0.0 Safari/537.36', '2026-10-08 05:00:11');
INSERT INTO `AuditLog` (`id`, `actorId`, `action`, `objectType`, `objectId`, `oldValue`, `newValue`, `ipAddress`, `userAgent`, `createdAt`) VALUES ('cmuz2jxfg0007khyxb5eyezyr', 'cmuyqrj5x000lkhk2bk2tnd1n', 'LOGIN', 'User', 'cmuyqrj5x000lkhk2bk2tnd1n', NULL, NULL, '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/153.0.0.0 Safari/537.36', '2026-10-08 05:01:25');
INSERT INTO `AuditLog` (`id`, `actorId`, `action`, `objectType`, `objectId`, `oldValue`, `newValue`, `ipAddress`, `userAgent`, `createdAt`) VALUES ('cmuz2knf0000bkhyxdjkcxbdu', 'cmuyqrj5x000lkhk2bk2tnd1n', 'PERMISSION_CHANGE', 'PermissionMatrix', 'permissions.matrix', NULL, '{"SUPER_ADMIN":{"MANAGE_USERS":true,"MANAGE_PERMISSIONS":true,"MANAGE_CELL":true,"MANAGE_VISITORS":true,"MANAGE_FOLLOWUPS":true,"MANAGE_EVENTS":true,"TAKE_ATTENDANCE":true,"MANAGE_GAMIFICATION":true,"SEND_ANNOUNCEMENTS":true,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":true,"VIEW_REPORTS":true,"VIEW_AUDIT_LOG":true,"MANAGE_SETTINGS":true},"CELL_ADMIN":{"MANAGE_USERS":true,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":true,"MANAGE_VISITORS":true,"MANAGE_FOLLOWUPS":true,"MANAGE_EVENTS":true,"TAKE_ATTENDANCE":true,"MANAGE_GAMIFICATION":true,"SEND_ANNOUNCEMENTS":true,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":true,"VIEW_REPORTS":true,"VIEW_AUDIT_LOG":true,"MANAGE_SETTINGS":true},"ASSISTANT":{"MANAGE_USERS":false,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":false,"MANAGE_VISITORS":false,"MANAGE_FOLLOWUPS":true,"MANAGE_EVENTS":true,"TAKE_ATTENDANCE":true,"MANAGE_GAMIFICATION":false,"SEND_ANNOUNCEMENTS":true,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":true,"VIEW_REPORTS":true,"VIEW_AUDIT_LOG":false,"MANAGE_SETTINGS":false},"WORKER":{"MANAGE_USERS":false,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":false,"MANAGE_VISITORS":false,"MANAGE_FOLLOWUPS":true,"MANAGE_EVENTS":false,"TAKE_ATTENDANCE":true,"MANAGE_GAMIFICATION":false,"SEND_ANNOUNCEMENTS":false,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":true,"VIEW_REPORTS":true,"VIEW_AUDIT_LOG":false,"MANAGE_SETTINGS":false},"MEMBER":{"MANAGE_USERS":false,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":false,"MANAGE_VISITORS":false,"MANAGE_FOLLOWUPS":false,"MANAGE_EVENTS":false,"TAKE_ATTENDANCE":false,"MANAGE_GAMIFICATION":false,"SEND_ANNOUNCEMENTS":false,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":false,"VIEW_REPORTS":false,"VIEW_AUDIT_LOG":false,"MANAGE_SETTINGS":false},"VISITOR":{"MANAGE_USERS":false,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":false,"MANAGE_VISITORS":false,"MANAGE_FOLLOWUPS":false,"MANAGE_EVENTS":false,"TAKE_ATTENDANCE":false,"MANAGE_GAMIFICATION":false,"SEND_ANNOUNCEMENTS":false,"SEND_MESSAGES":false,"VIEW_ALL_MEMBERS":false,"VIEW_REPORTS":false,"VIEW_AUDIT_LOG":false,"MANAGE_SETTINGS":false}}', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/153.0.0.0 Safari/537.36', '2026-10-08 05:01:59');
INSERT INTO `AuditLog` (`id`, `actorId`, `action`, `objectType`, `objectId`, `oldValue`, `newValue`, `ipAddress`, `userAgent`, `createdAt`) VALUES ('cmuz2l3rf000gkhyxhyyfwne7', 'cmuz2l3qa000ckhyx7oolqsp9', 'REGISTER', 'User', 'cmuz2l3qa000ckhyx7oolqsp9', NULL, NULL, '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/153.0.0.0 Safari/537.36', '2026-10-08 05:02:20');
INSERT INTO `AuditLog` (`id`, `actorId`, `action`, `objectType`, `objectId`, `oldValue`, `newValue`, `ipAddress`, `userAgent`, `createdAt`) VALUES ('cmuz3bmz6000ikhyxq08efap9', 'cmuyqrj5y000mkhk299eijc44', 'LOGIN', 'User', 'cmuyqrj5y000mkhk299eijc44', NULL, NULL, '21.0.0.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36', '2026-10-08 05:22:58');
INSERT INTO `AuditLog` (`id`, `actorId`, `action`, `objectType`, `objectId`, `oldValue`, `newValue`, `ipAddress`, `userAgent`, `createdAt`) VALUES ('cmuz3bs4f000kkhyx7a5xs2lp', 'cmuyqrj63000rkhk215jbdhmc', 'LOGIN', 'User', 'cmuyqrj63000rkhk215jbdhmc', NULL, NULL, '21.0.0.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36', '2026-10-08 05:23:04');
INSERT INTO `AuditLog` (`id`, `actorId`, `action`, `objectType`, `objectId`, `oldValue`, `newValue`, `ipAddress`, `userAgent`, `createdAt`) VALUES ('cmuz3c2d9000mkhyxh0tka1ft', 'cmuyqrj5x000lkhk2bk2tnd1n', 'LOGIN', 'User', 'cmuyqrj5x000lkhk2bk2tnd1n', NULL, NULL, '21.0.0.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36', '2026-10-08 05:23:18');

-- Data for Setting
INSERT INTO `Setting` (`id`, `key`, `value`, `category`, `updatedById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrk3l00plkhk297u3dks4', 'system.brand_name', '"Vanguard Cell Management System"', 'BRANDING', NULL, '2026-10-07 23:31:25', '2026-10-07 23:31:25');
INSERT INTO `Setting` (`id`, `key`, `value`, `category`, `updatedById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrk3m00pmkhk2gp9j7g9z', 'attendance.inactivity_threshold_weeks', '3', 'ATTENDANCE', NULL, '2026-10-07 23:31:25', '2026-10-07 23:31:25');
INSERT INTO `Setting` (`id`, `key`, `value`, `category`, `updatedById`, `createdAt`, `updatedAt`) VALUES ('cmuyqrk3m00pnkhk2ui5ilwqn', 'notifications.event_reminders', '{"days7":true,"days3":true,"day1":true,"hour2":true}', 'NOTIFICATIONS', NULL, '2026-10-07 23:31:25', '2026-10-07 23:31:25');
INSERT INTO `Setting` (`id`, `key`, `value`, `category`, `updatedById`, `createdAt`, `updatedAt`) VALUES ('cmuz2glno0000khhbnex26jsy', 'permissions.matrix', '{"SUPER_ADMIN":{"MANAGE_USERS":true,"MANAGE_PERMISSIONS":true,"MANAGE_CELL":true,"MANAGE_VISITORS":true,"MANAGE_FOLLOWUPS":true,"MANAGE_EVENTS":true,"TAKE_ATTENDANCE":true,"MANAGE_GAMIFICATION":true,"SEND_ANNOUNCEMENTS":true,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":true,"VIEW_REPORTS":true,"VIEW_AUDIT_LOG":true,"MANAGE_SETTINGS":true},"CELL_ADMIN":{"MANAGE_USERS":true,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":true,"MANAGE_VISITORS":true,"MANAGE_FOLLOWUPS":true,"MANAGE_EVENTS":true,"TAKE_ATTENDANCE":true,"MANAGE_GAMIFICATION":true,"SEND_ANNOUNCEMENTS":true,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":true,"VIEW_REPORTS":true,"VIEW_AUDIT_LOG":true,"MANAGE_SETTINGS":true},"ASSISTANT":{"MANAGE_USERS":false,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":false,"MANAGE_VISITORS":false,"MANAGE_FOLLOWUPS":true,"MANAGE_EVENTS":true,"TAKE_ATTENDANCE":true,"MANAGE_GAMIFICATION":false,"SEND_ANNOUNCEMENTS":true,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":true,"VIEW_REPORTS":true,"VIEW_AUDIT_LOG":false,"MANAGE_SETTINGS":false},"WORKER":{"MANAGE_USERS":false,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":false,"MANAGE_VISITORS":false,"MANAGE_FOLLOWUPS":true,"MANAGE_EVENTS":false,"TAKE_ATTENDANCE":true,"MANAGE_GAMIFICATION":false,"SEND_ANNOUNCEMENTS":false,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":true,"VIEW_REPORTS":true,"VIEW_AUDIT_LOG":false,"MANAGE_SETTINGS":false},"MEMBER":{"MANAGE_USERS":false,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":false,"MANAGE_VISITORS":false,"MANAGE_FOLLOWUPS":false,"MANAGE_EVENTS":false,"TAKE_ATTENDANCE":false,"MANAGE_GAMIFICATION":false,"SEND_ANNOUNCEMENTS":false,"SEND_MESSAGES":true,"VIEW_ALL_MEMBERS":false,"VIEW_REPORTS":false,"VIEW_AUDIT_LOG":false,"MANAGE_SETTINGS":false},"VISITOR":{"MANAGE_USERS":false,"MANAGE_PERMISSIONS":false,"MANAGE_CELL":false,"MANAGE_VISITORS":false,"MANAGE_FOLLOWUPS":false,"MANAGE_EVENTS":false,"TAKE_ATTENDANCE":false,"MANAGE_GAMIFICATION":false,"SEND_ANNOUNCEMENTS":false,"SEND_MESSAGES":false,"VIEW_ALL_MEMBERS":false,"VIEW_REPORTS":false,"VIEW_AUDIT_LOG":false,"MANAGE_SETTINGS":false}}', 'PERMISSIONS', 'cmuyqrj5x000lkhk2bk2tnd1n', '2026-10-08 04:58:50', '2026-10-08 05:01:59');

SET FOREIGN_KEY_CHECKS = 1;

-- End of dump

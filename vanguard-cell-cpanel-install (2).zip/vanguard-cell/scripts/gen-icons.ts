import sharp from 'sharp'
import { mkdirSync, writeFileSync } from 'fs'
import { join } from 'path'

const ICONS_DIR = '/home/z/my-project/public/icons'
mkdirSync(ICONS_DIR, { recursive: true })

// Christ Embassy-inspired logo: navy background + gold "V" with cross
function svgIcon(size: number, maskable = false) {
  const padding = maskable ? Math.round(size * 0.15) : Math.round(size * 0.1)
  const cx = size / 2
  const cy = size / 2
  const r = size / 2 - padding
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0B2A5B" />
      <stop offset="100%" stop-color="#123F8C" />
    </linearGradient>
    <linearGradient id="gold" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#E7B93E" />
      <stop offset="100%" stop-color="#D4AF37" />
    </linearGradient>
  </defs>
  <rect width="${size}" height="${size}" fill="url(#bg)" />
  <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="url(#gold)" stroke-width="${Math.max(2, size * 0.012)}" />
  <!-- Gold "V" shape -->
  <path d="M ${cx - r * 0.5} ${cy - r * 0.35} L ${cx} ${cy + r * 0.5} L ${cx + r * 0.5} ${cy - r * 0.35}"
        fill="none" stroke="url(#gold)" stroke-width="${Math.max(3, size * 0.025)}" stroke-linecap="round" stroke-linejoin="round" />
  <!-- Cross at top -->
  <line x1="${cx}" y1="${cy - r * 0.75}" x2="${cx}" y2="${cy - r * 0.45}" stroke="url(#gold)" stroke-width="${Math.max(2, size * 0.018)}" stroke-linecap="round" />
  <line x1="${cx - r * 0.12}" y1="${cy - r * 0.6}" x2="${cx + r * 0.12}" y2="${cy - r * 0.6}" stroke="url(#gold)" stroke-width="${Math.max(2, size * 0.018)}" stroke-linecap="round" />
</svg>`
}

async function generate() {
  // 192x192
  await sharp(Buffer.from(svgIcon(192))).png().toFile(join(ICONS_DIR, 'icon-192.png'))
  // 512x512
  await sharp(Buffer.from(svgIcon(512))).png().toFile(join(ICONS_DIR, 'icon-512.png'))
  // 512 maskable
  await sharp(Buffer.from(svgIcon(512, true))).png().toFile(join(ICONS_DIR, 'icon-maskable-512.png'))
  // favicon
  await sharp(Buffer.from(svgIcon(64))).png().toFile(join(ICONS_DIR, 'favicon.png'))
  console.log('✅ Generated PWA icons')
}

generate().catch((e) => {
  console.error(e)
  process.exit(1)
})

import { db } from '../src/lib/db'
import { hashPassword } from '../src/lib/auth'
import { seedDefaultRanks, seedDefaultBadges } from '../src/lib/gamification'

async function main() {
  console.log('🌱 Seeding Vanguard Cell Management System...')

  // 1. Church + Zone + Cell
  const church = await db.church.upsert({
    where: { slug: 'christ-embassy' },
    create: {
      name: 'Christ Embassy',
      slug: 'christ-embassy',
      description: 'LoveWorld / Christ Embassy',
      contactEmail: 'info@christembassy.org',
      address: 'Lagos, Nigeria',
    },
    update: {},
  })
  // Zone needs unique slug per church — use a try/create pattern since SQLite upsert by composite needs special handling
  let zone = await db.zone.findFirst({ where: { slug: 'awka-zone', churchId: church.id } })
  if (!zone) {
    zone = await db.zone.create({ data: { name: 'Awka Zone', slug: 'awka-zone', churchId: church.id } })
  }
  let cell = await db.cell.findUnique({ where: { churchId_slug: { churchId: church.id, slug: 'vanguard-cell-1' } } })
  if (!cell) {
    cell = await db.cell.create({
      data: {
        churchId: church.id,
        zoneId: zone.id,
        name: 'Vanguard Cell 1',
        slug: 'vanguard-cell-1',
        description: 'Vanguard Cell 1 — Awka Church',
        meetingDay: 'SATURDAY',
        meetingTime: '16:00',
        venue: "Sister Lizzy's House",
        address: 'Awka, Anambra State, Nigeria',
        brandColor: '#0B2A5B',
        accentColor: '#D4AF37',
      },
    })
  }

  // 2. Default ranks + badges
  await seedDefaultRanks()
  await seedDefaultBadges()

  // 3. Users
  const password = await hashPassword('password123')
  const users = [
    { email: 'superadmin@vanguard.test', name: 'System Super Admin', role: 'SUPER_ADMIN' },
    { email: 'leader@vanguard.test', name: 'Sister Lizzy Okoro', role: 'CELL_ADMIN' },
    { email: 'assistant@vanguard.test', name: 'Brother Chidi Eze', role: 'ASSISTANT' },
    { email: 'worker1@vanguard.test', name: 'Sister Ngozi Adichie', role: 'WORKER' },
    { email: 'worker2@vanguard.test', name: 'Brother Emeka Obi', role: 'WORKER' },
    { email: 'worker3@vanguard.test', name: 'Sister Amara Nwosu', role: 'WORKER' },
    { email: 'member1@vanguard.test', name: 'John Egbuna', role: 'MEMBER' },
    { email: 'member2@vanguard.test', name: 'Grace Okwu', role: 'MEMBER' },
    { email: 'member3@vanguard.test', name: 'David Onuoha', role: 'MEMBER' },
    { email: 'member4@vanguard.test', name: 'Faith Aniekwe', role: 'MEMBER' },
    { email: 'member5@vanguard.test', name: 'Samuel Ike', role: 'MEMBER' },
    { email: 'member6@vanguard.test', name: 'Blessing Eze', role: 'MEMBER' },
    { email: 'member7@vanguard.test', name: 'Joseph Nwankwo', role: 'MEMBER' },
    { email: 'member8@vanguard.test', name: 'Esther Okafor', role: 'MEMBER' },
    { email: 'member9@vanguard.test', name: 'Peter Madu', role: 'MEMBER' },
    { email: 'member10@vanguard.test', name: 'Ruth Chukwu', role: 'MEMBER' },
    { email: 'visitor1@vanguard.test', name: 'Daniel Uche', role: 'VISITOR' },
    { email: 'visitor2@vanguard.test', name: 'Mary Adebayo', role: 'VISITOR' },
    { email: 'visitor3@vanguard.test', name: 'Paul Okeke', role: 'VISITOR' },
  ]
  const createdUsers: any[] = []
  for (const u of users) {
    const user = await db.user.upsert({
      where: { email: u.email },
      create: { ...u, passwordHash: password, status: 'ACTIVE', emailVerifiedAt: new Date() },
      update: {},
    })
    createdUsers.push(user)
  }

  // 4. Members for non-SUPER_ADMIN/VISITOR users
  const statuses = ['ACTIVE_MEMBER', 'REGULAR_MEMBER', 'NEW_MEMBER', 'WORKER']
  const workerUserIds = createdUsers.filter((u) => u.role === 'WORKER').map((u) => u.id)
  const leaderUser = createdUsers.find((u) => u.role === 'CELL_ADMIN')!

  const memberUsers = createdUsers.filter((u) =>
    ['MEMBER', 'WORKER', 'CELL_ADMIN', 'ASSISTANT'].includes(u.role)
  )
  const members: any[] = []
  for (let i = 0; i < memberUsers.length; i++) {
    const u = memberUsers[i]
    const status =
      u.role === 'CELL_ADMIN' ? 'CELL_LEADER' :
      u.role === 'ASSISTANT' ? 'WORKER' :
      u.role === 'WORKER' ? 'WORKER' :
      statuses[i % statuses.length]
    const m = await db.member.upsert({
      where: { userId: u.id },
      create: {
        userId: u.id,
        cellId: cell.id,
        fullName: u.name,
        preferredName: u.name.split(' ')[0],
        email: u.email,
        phone: `+234 80${10000000 + i * 137}`,
        gender: i % 2 === 0 ? 'MALE' : 'FEMALE',
        status,
        dateJoinedCell: new Date(Date.now() - (90 - i * 5) * 24 * 3600 * 1000),
        assignedWorkerId: u.role === 'MEMBER' ? workerUserIds[i % workerUserIds.length] : null,
      },
      update: {},
    })
    members.push(m)
  }

  // 5. Visitors
  const visitorUsers = createdUsers.filter((u) => u.role === 'VISITOR')
  for (let i = 0; i < visitorUsers.length; i++) {
    const u = visitorUsers[i]
    const existing = await db.visitor.findFirst({ where: { email: u.email } })
    if (!existing) {
      await db.visitor.create({
        data: {
          cellId: cell.id,
          fullName: u.name,
          email: u.email,
          phone: `+234 80${20000000 + i * 137}`,
          invitedByMemberId: members[i + 3]?.id,
          firstVisitDate: new Date(Date.now() - 14 * 24 * 3600 * 1000),
          followUpStatus: i === 0 ? 'NEW' : i === 1 ? 'CONTACTED' : 'ENGAGED',
        },
      })
    }
  }

  // 6. Weekly Saturday event series
  const series = await db.eventSeries.create({
    data: {
      cellId: cell.id,
      name: 'Weekly Vanguard Cell Meeting',
      description: 'Weekly cell meeting — every Saturday at 4:00 PM at Sister Lizzy\'s House.',
      recurrenceRule: JSON.stringify({ frequency: 'WEEKLY', dayOfWeek: 6, time: '16:00' }),
      eventType: 'WEEKLY_CELL_MEETING',
      venue: "Sister Lizzy's House",
      address: 'Awka, Anambra State',
      hostUserId: leaderUser.id,
      createdById: leaderUser.id,
      startDate: new Date('2026-01-01'),
      isActive: true,
    },
  })

  // 7. Events — generate past 8 weeks + next 4 weeks of Saturday meetings
  const saturdayEvents: any[] = []
  for (let i = -8; i <= 4; i++) {
    const d = new Date()
    d.setDate(d.getDate() + ((6 - d.getDay() + 7) % 7) + i * 7)
    d.setHours(16, 0, 0, 0)
    const ev = await db.event.create({
      data: {
        cellId: cell.id,
        seriesId: series.id,
        name: `Vanguard Cell Meeting — ${d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}`,
        slug: `vanguard-meeting-${d.toISOString().split('T')[0]}`,
        description: 'Weekly cell meeting.',
        eventType: 'WEEKLY_CELL_MEETING',
        startDate: d,
        endDate: new Date(d.getTime() + 2 * 3600 * 1000),
        startTime: '16:00',
        endTime: '18:00',
        venue: "Sister Lizzy's House",
        address: 'Awka, Anambra State',
        hostUserId: leaderUser.id,
        registrationRequired: false,
        attendanceRequired: true,
        isPublic: false,
        accessRule: 'MEMBERS_ONLY',
        enablePin: true,
        enableQr: true,
        status: i < 0 ? 'COMPLETED' : 'PUBLISHED',
        createdById: leaderUser.id,
      },
    })
    saturdayEvents.push(ev)
  }

  // 8. Special registration event (End-of-Year Fellowship)
  const endOfYear = new Date()
  endOfYear.setMonth(11, 20)
  endOfYear.setHours(18, 0, 0, 0)
  const specialEvent = await db.event.create({
    data: {
      cellId: cell.id,
      name: 'Vanguard Cell End-of-Year Fellowship',
      slug: 'vanguard-end-of-year-fellowship',
      description: 'A special end-of-year celebration with food, worship, and testimonies.',
      eventType: 'SOCIAL_FELLOWSHIP',
      startDate: endOfYear,
      endDate: new Date(endOfYear.getTime() + 3 * 3600 * 1000),
      startTime: '18:00',
      endTime: '21:00',
      venue: 'Christ Embassy Awka Main Hall',
      address: 'Awka, Anambra State',
      hostUserId: leaderUser.id,
      registrationRequired: true,
      registrationDeadline: new Date(endOfYear.getTime() - 7 * 24 * 3600 * 1000),
      capacity: 80,
      attendanceRequired: true,
      isPublic: true,
      accessRule: 'ANYONE',
      enablePin: true,
      enableQr: true,
      status: 'REGISTRATION_OPEN',
      createdById: leaderUser.id,
    },
  })

  // 9. Registration fields for the special event
  const regFields = [
    { label: 'Full Name', fieldKey: 'name', fieldType: 'TEXT', required: true, order: 1 },
    { label: 'Phone Number', fieldKey: 'phone', fieldType: 'PHONE', required: true, order: 2 },
    { label: 'Email', fieldKey: 'email', fieldType: 'EMAIL', required: false, order: 3 },
    { label: 'Gender', fieldKey: 'gender', fieldType: 'RADIO', options: JSON.stringify(['Male', 'Female']), required: true, order: 4 },
    { label: 'Number of Guests', fieldKey: 'num_guests', fieldType: 'NUMBER', required: true, order: 5 },
    { label: 'Dietary Information', fieldKey: 'dietary', fieldType: 'TEXT', required: false, order: 6 },
    { label: 'Special Needs', fieldKey: 'special_needs', fieldType: 'TEXTAREA', required: false, order: 7 },
    { label: 'Consent to be photographed', fieldKey: 'consent', fieldType: 'CONSENT', required: true, order: 8 },
  ]
  for (const f of regFields) {
    await db.registrationField.create({ data: { ...f, eventId: specialEvent.id } })
  }

  // 10. Attendance records for past events
  const pastEvents = saturdayEvents.filter((e) => e.status === 'COMPLETED')
  for (const ev of pastEvents) {
    for (const m of members) {
      const probability = m.status === 'CELL_LEADER' || m.status === 'WORKER' ? 0.95 : 0.85
      if (Math.random() < probability) {
        const lateProb = 0.1
        const status = Math.random() < lateProb ? 'LATE' : 'PRESENT'
        await db.attendanceRecord.create({
          data: {
            eventId: ev.id,
            memberId: m.id,
            userId: m.userId,
            status,
            method: 'MANUAL',
            checkInTime: new Date(ev.startDate.getTime() + (status === 'LATE' ? 20 * 60 * 1000 : 0)),
            verificationStatus: 'VERIFIED',
            recordedById: leaderUser.id,
            syncStatus: 'SYNCED',
          },
        })
      } else if (Math.random() < 0.2) {
        await db.attendanceRecord.create({
          data: {
            eventId: ev.id,
            memberId: m.id,
            userId: m.userId,
            status: 'EXCUSED',
            method: 'MANUAL',
            verificationStatus: 'VERIFIED',
            recordedById: leaderUser.id,
            syncStatus: 'SYNCED',
          },
        })
      }
    }
  }

  // 11. Recalculate streaks + ranks + attendance % for all members
  const {
    evaluateRank, evaluateBadges, recalculateStreak,
    recalculateAttendancePercentage, recalculateEngagementScore, awardPoints,
  } = await import('../src/lib/gamification')
  for (const m of members) {
    await recalculateStreak(m.id)
    await recalculateAttendancePercentage(m.id)
    const records = await db.attendanceRecord.findMany({ where: { memberId: m.id } })
    for (const r of records) {
      if (r.status === 'PRESENT' || r.status === 'LATE') {
        await awardPoints(m.id, 10, 'ATTEND', { eventId: r.eventId, description: 'Cell meeting attendance' })
        if (r.status === 'PRESENT' && r.checkInTime) {
          const ev = await db.event.findUnique({ where: { id: r.eventId } })
          if (ev && r.checkInTime <= ev.startDate) {
            await awardPoints(m.id, 5, 'ON_TIME', { eventId: r.eventId, description: 'On-time attendance bonus' })
          }
        }
      }
    }
    if (m.longestStreak >= 8) await awardPoints(m.id, 50, 'STREAK_8', { description: '8-week attendance streak bonus' })
    else if (m.longestStreak >= 4) await awardPoints(m.id, 25, 'STREAK_4', { description: '4-week attendance streak bonus' })
    await evaluateRank(m.id)
    await recalculateEngagementScore(m.id)
    await evaluateBadges(m.id)
  }

  // 12. Default challenges
  await db.challenge.upsert({
    where: { slug: '4-week-attendance' },
    create: {
      name: '4-Week Attendance Challenge',
      slug: '4-week-attendance',
      description: 'Attend four consecutive weekly cell meetings.',
      goalType: 'ATTEND_CONSECUTIVE',
      goalValue: 4,
      pointsReward: 50,
      startDate: new Date(),
      isActive: true,
      cellId: cell.id,
    },
    update: {},
  })
  await db.challenge.upsert({
    where: { slug: 'invite-a-guest' },
    create: {
      name: 'Invite a Guest',
      slug: 'invite-a-guest',
      description: 'Bring a first-time guest to any cell event.',
      goalType: 'INVITE_GUEST',
      goalValue: 1,
      pointsReward: 10,
      startDate: new Date(),
      isActive: true,
      cellId: cell.id,
    },
    update: {},
  })

  // 13. Default settings — including the permission matrix
  await db.setting.upsert({
    where: { key: 'system.brand_name' },
    create: { key: 'system.brand_name', value: JSON.stringify('Vanguard Cell Management System'), category: 'BRANDING' },
    update: {},
  })
  await db.setting.upsert({
    where: { key: 'attendance.inactivity_threshold_weeks' },
    create: { key: 'attendance.inactivity_threshold_weeks', value: JSON.stringify(3), category: 'ATTENDANCE' },
    update: {},
  })
  await db.setting.upsert({
    where: { key: 'notifications.event_reminders' },
    create: { key: 'notifications.event_reminders', value: JSON.stringify({ days7: true, days3: true, day1: true, hour2: true }), category: 'NOTIFICATIONS' },
    update: {},
  })
  // Seed the configurable permission matrix (SUPER_ADMIN is always all-true)
  const { DEFAULT_PERMISSIONS } = await import('../src/lib/auth')
  await db.setting.upsert({
    where: { key: 'permissions.matrix' },
    create: { key: 'permissions.matrix', value: JSON.stringify(DEFAULT_PERMISSIONS), category: 'PERMISSIONS' },
    update: {},
  })

  // 14. Welcome announcement
  await db.announcement.create({
    data: {
      cellId: cell.id,
      authorId: leaderUser.id,
      title: 'Welcome to Vanguard Cell 1 PWA!',
      body: 'Praise God! We are excited to launch our new cell management app. Install it on your phone, register for events, check in with QR codes, and grow with us.',
      category: 'CELL',
      priority: 'HIGH',
      isPinned: true,
    },
  })

  // 15. Cell group conversation
  const cellChat = await db.conversation.create({
    data: {
      cellId: cell.id,
      type: 'CELL_GROUP',
      name: 'Vanguard Cell 1 — Cell Chat',
    },
  })
  for (const u of createdUsers) {
    await db.conversationParticipant.create({
      data: { conversationId: cellChat.id, userId: u.id },
    }).catch(() => {})
  }
  await db.message.create({
    data: {
      conversationId: cellChat.id,
      senderId: leaderUser.id,
      body: 'Welcome family! This is our new cell chat. Glory to God!',
    },
  })

  console.log('✅ Seed complete!')
  console.log('Login credentials:')
  console.log('  Super Admin: superadmin@vanguard.test / password123')
  console.log('  Cell Leader: leader@vanguard.test / password123')
  console.log('  Member:      member1@vanguard.test / password123')
  console.log('  Visitor:     visitor1@vanguard.test / password123')
}

main()
  .then(() => db.$disconnect())
  .catch(async (e) => {
    console.error(e)
    await db.$disconnect()
    process.exit(1)
  })

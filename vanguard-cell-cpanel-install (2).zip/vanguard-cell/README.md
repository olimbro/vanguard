# Vanguard Cell Management System

## Quick Install
1. Upload this zip to cPanel → File Manager → public_html/
2. Extract the zip
3. Visit https://yourdomain.com/install.php
4. Follow the installer wizard (imports database, sets super admin)
5. Set up Node.js in cPanel → Setup Node.js App (see INSTALL.md)
6. Run: npm install && npm run build
7. Start the app
8. Delete install.php

See INSTALL.md for detailed step-by-step instructions.

## Demo Logins (after install)
- Super Admin: superadmin@vanguard.test / password123
- Cell Leader: leader@vanguard.test / password123

⚠️ Change all passwords immediately after installation!

## Tech Stack
- Next.js 16 + TypeScript + Prisma ORM + Tailwind CSS
- MySQL/MariaDB database
- PWA (installable, offline-capable)

## Mission
WIN SOULS · BUILD PEOPLE · DEVELOP LEADERS · MULTIPLY CELLS

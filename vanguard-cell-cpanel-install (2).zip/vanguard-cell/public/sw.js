// Vanguard Cell Management System - Service Worker
// Offline shell + IndexedDB-backed attendance queue

const CACHE_NAME = 'vanguard-cell-v1';
const OFFLINE_URL = '/offline.html';

const APP_SHELL = [
  '/',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/offline.html',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL).catch(() => {}))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Network-first for API and HTML; cache-first for static assets
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Skip non-GET requests except for /api/attendance and /api/sync (which we handle via background sync)
  if (req.method !== 'GET') {
    // For POST /api/attendance when offline, queue it
    if (req.url.includes('/api/attendance') || req.url.includes('/api/checkin')) {
      event.respondWith(queueRequest(req));
    }
    return;
  }

  // Never cache API GETs
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(req).catch(() => new Response(JSON.stringify({ error: 'offline' }), { status: 503, headers: { 'Content-Type': 'application/json' } }))
    );
    return;
  }

  // Network-first for HTML, fall back to cache
  if (req.mode === 'navigate' || req.headers.get('accept')?.includes('text/html')) {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const clone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
          return res;
        })
        .catch(() => caches.match(req).then((r) => r || caches.match('/')))
    );
    return;
  }

  // Cache-first for static assets
  event.respondWith(
    caches.match(req).then((cached) => cached || fetch(req).then((res) => {
      const clone = res.clone();
      caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
      return res;
    }).catch(() => cached))
  );
});

// Background sync for offline attendance queue
async function queueRequest(req) {
  try {
    const body = await req.clone().json();
    // Store in IndexedDB
    const db = await openQueueDB();
    await db.put('attendanceQueue', {
      id: body.offlineUuid || crypto.randomUUID(),
      url: req.url,
      method: req.method,
      body: JSON.stringify(body),
      timestamp: Date.now(),
      retries: 0,
    });
    // Try to send immediately if online
    if (navigator.onLine) {
      await flushQueue();
    }
    return new Response(JSON.stringify({ ok: true, queued: true, id: body.offlineUuid }), {
      status: 202,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: 'queue_failed', message: e.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

async function openQueueDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('vanguard_offline', 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('attendanceQueue')) {
        db.createObjectStore('attendanceQueue', { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function flushQueue() {
  const db = await openQueueDB();
  const tx = db.transaction('attendanceQueue', 'readonly');
  const all = await new Promise((resolve) => {
    const req = tx.objectStore('attendanceQueue').getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => resolve([]);
  });
  for (const item of all) {
    try {
      const res = await fetch(item.url, {
        method: item.method,
        headers: { 'Content-Type': 'application/json' },
        body: item.body,
      });
      if (res.ok) {
        const delTx = db.transaction('attendanceQueue', 'readwrite');
        delTx.objectStore('attendanceQueue').delete(item.id);
      }
    } catch (e) {
      // Will retry next time
    }
  }
}

self.addEventListener('sync', (event) => {
  if (event.tag === 'attendance-sync') {
    event.waitUntil(flushQueue());
  }
});

self.addEventListener('message', (event) => {
  if (event.data?.type === 'FLUSH_QUEUE') {
    event.waitUntil(flushQueue().then(() => event.source?.postMessage({ type: 'FLUSHED' })));
  }
});

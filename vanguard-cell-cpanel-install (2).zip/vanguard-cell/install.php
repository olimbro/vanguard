<?php
/**
 * Vanguard Cell Management System — Installer
 * Christ Embassy — Vanguard Cell 1, Awka Church
 *
 * Steps:
 *   1: Server requirements check
 *   2: Database configuration
 *   3: Application + Super Admin configuration
 *   4: Execute installation (import SQL, set password, write .env)
 *   5: Complete
 *
 * After installation, DELETE this file.
 */

set_time_limit(600);
ini_set('memory_limit', '256M');
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);

session_start();
$error = '';
$step = $_POST['step'] ?? ($_SESSION['step'] ?? '1');
$installed = file_exists(__DIR__ . '/.env') && file_exists(__DIR__ . '/.installed');

if ($installed && !isset($_POST['force'])) {
    die('<!DOCTYPE html><html><body style="font-family:sans-serif;padding:40px;max-width:600px;margin:0 auto">
    <h2 style="color:#0B2A5B">Already Installed</h2>
    <p>The Vanguard Cell Management System appears to be already installed.</p>
    <p>To reinstall, delete the <code>.env</code> and <code>.installed</code> files, then refresh this page.</p>
    <p><a href="/" style="color:#0B2A5B">← Go to application</a></p>
    </body></html>');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install — Vanguard Cell Management System</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: linear-gradient(135deg, #0B2A5B 0%, #123F8C 100%); min-height: 100vh; padding: 20px; }
        .container { max-width: 700px; margin: 40px auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
        .header { background: linear-gradient(135deg, #0B2A5B, #123F8C); color: #fff; padding: 30px; text-align: center; }
        .header .logo { width: 64px; height: 64px; background: linear-gradient(135deg, #E7B93E, #D4AF37); border-radius: 16px; margin: 0 auto 12px; display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: bold; color: #0B2A5B; }
        .header h1 { font-size: 22px; margin-bottom: 4px; }
        .header p { opacity: 0.8; font-size: 13px; }
        .body { padding: 30px; }
        .steps { display: flex; gap: 8px; margin-bottom: 30px; }
        .step-dot { flex: 1; height: 4px; background: #e0e0e0; border-radius: 2px; transition: background 0.3s; }
        .step-dot.active { background: #D4AF37; }
        .step-dot.done { background: #22C55E; }
        h2 { color: #0B2A5B; margin-bottom: 16px; font-size: 18px; }
        .form-group { margin-bottom: 16px; }
        label { display: block; font-size: 13px; font-weight: 600; color: #333; margin-bottom: 4px; }
        .hint { font-size: 11px; color: #888; font-weight: 400; }
        input, select { width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px; font-family: inherit; }
        input:focus { outline: none; border-color: #0B2A5B; box-shadow: 0 0 0 3px rgba(11,42,91,0.1); }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .btn { display: block; width: 100%; background: #0B2A5B; color: #fff; padding: 12px 24px; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; text-decoration: none; text-align: center; transition: background 0.2s; }
        .btn:hover { background: #123F8C; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-gold { background: #D4AF37; color: #0B2A5B; }
        .btn-gold:hover { background: #E7B93E; }
        .check { padding: 8px 0; display: flex; align-items: center; gap: 8px; font-size: 13px; }
        .check .ok { color: #22C55E; font-weight: bold; }
        .check .fail { color: #EF4444; font-weight: bold; }
        .check .warn { color: #F59E0B; font-weight: bold; }
        .error { background: #FEF2F2; border: 1px solid #FECACA; color: #991B1B; padding: 12px; border-radius: 8px; margin-bottom: 16px; font-size: 13px; }
        .success { background: #F0FDF4; border: 1px solid #BBF7D0; color: #166534; padding: 12px; border-radius: 8px; margin-bottom: 16px; font-size: 13px; }
        .info { background: #EFF6FF; border: 1px solid #BFDBFE; color: #1E40AF; padding: 12px; border-radius: 8px; margin-bottom: 16px; font-size: 13px; }
        .warn-box { background: #FFFBEB; border: 1px solid #FDE68A; color: #92400E; padding: 12px; border-radius: 8px; margin-bottom: 16px; font-size: 13px; }
        code { background: #f4f4f4; padding: 2px 6px; border-radius: 4px; font-size: 12px; }
        .credentials { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; margin: 16px 0; }
        .credentials dt { font-weight: 600; color: #0B2A5B; font-size: 12px; margin-top: 8px; }
        .credentials dd { font-size: 14px; margin-left: 0; margin-bottom: 4px; }
        .progress { background: #f4f4f4; border-radius: 8px; padding: 20px; text-align: center; margin: 20px 0; }
        .spinner { display: inline-block; width: 32px; height: 32px; border: 3px solid #D4AF37; border-top-color: transparent; border-radius: 50%; animation: spin 0.8s linear infinite; margin-bottom: 12px; }
        @keyframes spin { to { transform: rotate(360deg); } }
        pre { background: #1e293b; color: #e2e8f0; padding: 12px; border-radius: 8px; font-size: 11px; overflow-x: auto; line-height: 1.5; }
        .log-line { font-family: 'Courier New', monospace; font-size: 12px; padding: 2px 0; color: #555; }
        .log-ok { color: #16a34a; }
        .log-err { color: #dc2626; }
        .log-warn { color: #d97706; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">V</div>
        <h1>Vanguard Cell Management System</h1>
        <p>Christ Embassy — Vanguard Cell 1, Awka Church</p>
    </div>
    <div class="body">

<?php
// ============================================================
// HELPER: Execute SQL and log progress
// ============================================================
function log_line($msg, $type = '') {
    echo "<div class='log-line log-$type'>" . htmlspecialchars($msg) . "</div>";
    ob_flush(); flush();
}

// ============================================================
// PROCESS INSTALL
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'install') {
    $step = 'install';
    $dbHost = trim($_POST['db_host'] ?? 'localhost');
    $dbName = trim($_POST['db_name'] ?? '');
    $dbUser = trim($_POST['db_user'] ?? '');
    $dbPass = $_POST['db_pass'] ?? '';
    $appUrl = rtrim(trim($_POST['app_url'] ?? ''), '/');
    $appName = trim($_POST['app_name'] ?? 'Vanguard Cell Management System');
    $adminEmail = trim($_POST['admin_email'] ?? '');
    $adminPass = $_POST['admin_pass'] ?? '';
    $adminName = trim($_POST['admin_name'] ?? 'System Super Admin');
    $importMethod = $_POST['import_method'] ?? 'auto';

    // Validate
    if (!$dbName || !$dbUser || !$appUrl || !$adminEmail || !$adminPass) {
        $error = 'All fields are required.';
        $step = '3';
    } elseif (strlen($adminPass) < 8) {
        $error = 'Super Admin password must be at least 8 characters.';
        $step = '3';
    } elseif (!filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
        $error = 'Super Admin email is not a valid email address.';
        $step = '3';
    } else {
        // ============================================================
        // PHASE 1: Connect to MySQL
        // ============================================================
        echo '<h2>Installing — Step 4 of 4</h2>';
        echo '<div id="install-log" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px;max-height:400px;overflow-y:auto;margin-bottom:16px">';
        log_line("→ Connecting to MySQL at $dbHost / $dbName ...");

        $mysqli = @new mysqli($dbHost, $dbUser, $dbPass, $dbName);
        if ($mysqli->connect_error) {
            log_line("✗ Database connection failed: " . $mysqli->connect_error, 'err');
            $error = 'Database connection failed: ' . $mysqli->connect_error;
            $step = '3';
        } else {
            $mysqli->set_charset('utf8mb4');
            log_line("✓ Connected successfully.", 'ok');

            // ============================================================
            // PHASE 2: Import the SQL dump
            // ============================================================
            $sqlFile = __DIR__ . '/vanguard-cell-database.sql';
            if (!file_exists($sqlFile)) {
                log_line("✗ SQL file not found: vanguard-cell-database.sql", 'err');
                $error = "SQL file not found: vanguard-cell-database.sql.";
                $step = '3';
            } else {
                $importOk = false;
                $importError = '';

                // Method A: mysql CLI (fastest — this is what phpMyAdmin uses)
                if ($importMethod === 'auto' || $importMethod === 'cli') {
                    log_line("→ Trying mysql CLI import...");
                    $escapedPass = str_replace("'", "'\\''", $dbPass);
                    $cmd = "mysql -h " . escapeshellarg($dbHost) . " -u " . escapeshellarg($dbUser) . " -p'" . $escapedPass . "' " . escapeshellarg($dbName) . " < " . escapeshellarg($sqlFile) . " 2>&1";
                    $output = @shell_exec($cmd);
                    if ($output === null || trim($output) === '') {
                        // Check if it actually worked by looking for a table
                        $check = $mysqli->query("SHOW TABLES LIKE 'User'");
                        if ($check && $check->num_rows > 0) {
                            $importOk = true;
                            log_line("✓ SQL imported via mysql CLI.", 'ok');
                        } else {
                            log_line("⚠ mysql CLI produced no output but tables missing — trying PHP fallback.", 'warn');
                        }
                    } else {
                        // CLI produced output — might be an error or warning
                        if (stripos($output, 'ERROR') !== false) {
                            log_line("⚠ mysql CLI error: " . trim($output), 'warn');
                        } else {
                            // Might be just a warning — check if tables exist
                            $check = $mysqli->query("SHOW TABLES LIKE 'User'");
                            if ($check && $check->num_rows > 0) {
                                $importOk = true;
                                log_line("✓ SQL imported via mysql CLI.", 'ok');
                            } else {
                                log_line("⚠ mysql CLI failed silently — trying PHP fallback.", 'warn');
                            }
                        }
                    }
                }

                // Method B: PHP mysqli_multi_query (fallback)
                if (!$importOk && ($importMethod === 'auto' || $importMethod === 'multi')) {
                    log_line("→ Trying PHP multi_query import...");
                    $sql = file_get_contents($sqlFile);
                    // Clean: remove comment-only lines
                    $sql = preg_replace('/^--[^\n]*$/m', '', $sql);
                    $sql = preg_replace('/^\s*$/m', '', $sql);
                    $sql = trim($sql);

                    $mysqli->query('SET FOREIGN_KEY_CHECKS = 0');
                    $result = $mysqli->multi_query($sql);
                    if ($result) {
                        do { $mysqli->store_result(); } while ($mysqli->more_results() && $mysqli->next_result());
                    }
                    $err = $mysqli->error;
                    $mysqli->query('SET FOREIGN_KEY_CHECKS = 1');

                    $check = $mysqli->query("SHOW TABLES LIKE 'User'");
                    if ($check && $check->num_rows > 0) {
                        $importOk = true;
                        log_line("✓ SQL imported via PHP multi_query.", 'ok');
                    } else {
                        log_line("✗ multi_query failed: " . ($err ?: 'unknown error'), 'err');
                        $importError = $err;
                    }
                }

                // Method C: Statement-by-statement (last resort)
                if (!$importOk && ($importMethod === 'auto' || $importMethod === 'stmt')) {
                    log_line("→ Trying statement-by-statement import...");
                    $sql = file_get_contents($sqlFile);
                    // Remove comments
                    $sql = preg_replace('/^--[^\n]*$/m', '', $sql);
                    // Split on semicolons at end of line
                    $statements = preg_split('/;[\r\n]+/', $sql);
                    $count = 0;
                    $errors = 0;
                    $mysqli->query('SET FOREIGN_KEY_CHECKS = 0');
                    foreach ($statements as $stmt) {
                        $stmt = trim($stmt);
                        if (empty($stmt)) continue;
                        if (preg_match('/^(SET|DROP|CREATE|INSERT|UPDATE|DELETE|ALTER|USE|SHOW)/i', $stmt)) {
                            if ($mysqli->query($stmt)) {
                                $count++;
                                if ($count % 20 === 0) log_line("  ... $count statements executed");
                            } else {
                                $errors++;
                                // Ignore "already exists" errors
                                if (stripos($mysqli->error, 'already exists') === false) {
                                    log_line("  ⚠ SQL error: " . substr($mysqli->error, 0, 100), 'warn');
                                }
                            }
                        }
                    }
                    $mysqli->query('SET FOREIGN_KEY_CHECKS = 1');

                    $check = $mysqli->query("SHOW TABLES LIKE 'User'");
                    if ($check && $check->num_rows > 0) {
                        $importOk = true;
                        log_line("✓ SQL imported ($count statements, $errors errors ignored).", 'ok');
                    } else {
                        log_line("✗ Statement-by-statement import failed.", 'err');
                    }
                }

                if (!$importOk) {
                    echo '</div>'; // close log
                    $error = "Database import failed via all methods. Please import <code>vanguard-cell-database.sql</code> manually via phpMyAdmin → Import, then click the button below.";
                    $step = 'manual_import';
                    $_SESSION['db_host'] = $dbHost;
                    $_SESSION['db_name'] = $dbName;
                    $_SESSION['db_user'] = $dbUser;
                    $_SESSION['db_pass'] = $dbPass;
                    $_SESSION['app_url'] = $appUrl;
                    $_SESSION['app_name'] = $appName;
                    $_SESSION['admin_email'] = $adminEmail;
                    $_SESSION['admin_name'] = $adminName;
                    $_SESSION['admin_pass'] = $adminPass;
                } else {
                    // ============================================================
                    // PHASE 3: Update super admin password
                    // ============================================================
                    log_line("→ Configuring super admin account...");
                    $hash = password_hash($adminPass, PASSWORD_BCRYPT, ['cost' => 10]);

                    $stmt = $mysqli->prepare("UPDATE `User` SET `passwordHash` = ?, `email` = ?, `name` = ?, `status` = 'ACTIVE', `emailVerifiedAt` = NOW() WHERE `role` = 'SUPER_ADMIN' LIMIT 1");
                    $stmt->bind_param('sss', $hash, $adminEmail, $adminName);
                    $stmt->execute();
                    $affected = $stmt->affected_rows;
                    $stmt->close();

                    if ($affected === 0) {
                        $id = 'c' . substr(md5(uniqid('', true)), 0, 24);
                        $stmt = $mysqli->prepare("INSERT INTO `User` (`id`, `email`, `passwordHash`, `name`, `role`, `status`, `emailVerifiedAt`, `createdAt`, `updatedAt`) VALUES (?, ?, ?, ?, 'SUPER_ADMIN', 'ACTIVE', NOW(), NOW(), NOW())");
                        $stmt->bind_param('ssss', $id, $adminEmail, $hash, $adminName);
                        $stmt->execute();
                        $stmt->close();
                        log_line("✓ Created new super admin account.", 'ok');
                    } else {
                        log_line("✓ Updated existing super admin password.", 'ok');
                    }

                    // ============================================================
                    // PHASE 4: Write .env
                    // ============================================================
                    log_line("→ Writing .env configuration file...");
                    $envContent = "# Vanguard Cell Management System\n";
                    $envContent .= "# Generated: " . date('Y-m-d H:i:s') . "\n\n";
                    $envContent .= "DATABASE_URL=\"mysql://$dbUser:" . urlencode($dbPass) . "@$dbHost:3306/$dbName\"\n";
                    $envContent .= "NEXTAUTH_URL=\"$appUrl\"\n";
                    $envContent .= "NEXTAUTH_SECRET=\"" . bin2hex(random_bytes(32)) . "\"\n";
                    $envContent .= "NODE_ENV=\"production\"\n";
                    $envContent .= "PORT=3000\n";

                    if (file_put_contents(__DIR__ . '/.env', $envContent) === false) {
                        log_line("✗ Failed to write .env file.", 'err');
                        $error = 'Failed to write .env file. Check directory permissions.';
                        $step = '3';
                    } else {
                        file_put_contents(__DIR__ . '/.installed', date('c'));
                        log_line("✓ Installation complete!", 'ok');
                        echo '</div>'; // close log
                        session_destroy();
                        $step = 'done';
                    }
                }
            }
            if (isset($mysqli) && $mysqli instanceof mysqli) $mysqli->close();
        }
        if ($step !== 'done' && $step !== 'manual_import') echo '</div>';
    }
}

// ============================================================
// PROCESS STEP 2 → 3 (test DB connection)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'test') {
    $dbHost = trim($_POST['db_host'] ?? 'localhost');
    $dbName = trim($_POST['db_name'] ?? '');
    $dbUser = trim($_POST['db_user'] ?? '');
    $dbPass = $_POST['db_pass'] ?? '';

    $_SESSION['db_host'] = $dbHost;
    $_SESSION['db_name'] = $dbName;
    $_SESSION['db_user'] = $dbUser;
    $_SESSION['db_pass'] = $dbPass;

    $testMysqli = @new mysqli($dbHost, $dbUser, $dbPass, $dbName);
    if ($testMysqli->connect_error) {
        $error = 'Database connection failed: ' . $testMysqli->connect_error;
        $step = '2';
    } else {
        $step = '3';
        $testMysqli->close();
    }
}

// ============================================================
// PROCESS: Skip import (user imported via phpMyAdmin manually)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'skip_import') {
    $dbHost = $_SESSION['db_host'] ?? '';
    $dbName = $_SESSION['db_name'] ?? '';
    $dbUser = $_SESSION['db_user'] ?? '';
    $dbPass = $_SESSION['db_pass'] ?? '';
    $appUrl = $_SESSION['app_url'] ?? '';
    $adminEmail = $_SESSION['admin_email'] ?? '';
    $adminPass = $_SESSION['admin_pass'] ?? '';
    $adminName = $_SESSION['admin_name'] ?? 'System Super Admin';

    $mysqli = @new mysqli($dbHost, $dbUser, $dbPass, $dbName);
    if (!$mysqli->connect_error) {
        $mysqli->set_charset('utf8mb4');
        $check = $mysqli->query("SHOW TABLES LIKE 'User'");
        if ($check && $check->num_rows > 0) {
            // Tables exist — set up admin + .env
            $hash = password_hash($adminPass, PASSWORD_BCRYPT, ['cost' => 10]);
            $stmt = $mysqli->prepare("UPDATE `User` SET `passwordHash` = ?, `email` = ?, `name` = ?, `status` = 'ACTIVE' WHERE `role` = 'SUPER_ADMIN' LIMIT 1");
            $stmt->bind_param('sss', $hash, $adminEmail, $adminName);
            $stmt->execute();
            if ($stmt->affected_rows === 0) {
                $id = 'c' . substr(md5(uniqid('', true)), 0, 24);
                $stmt2 = $mysqli->prepare("INSERT INTO `User` (`id`, `email`, `passwordHash`, `name`, `role`, `status`, `createdAt`, `updatedAt`) VALUES (?, ?, ?, ?, 'SUPER_ADMIN', 'ACTIVE', NOW(), NOW())");
                $stmt2->bind_param('ssss', $id, $adminEmail, $hash, $adminName);
                $stmt2->execute();
                $stmt2->close();
            }
            $stmt->close();

            $envContent = "DATABASE_URL=\"mysql://$dbUser:" . urlencode($dbPass) . "@$dbHost:3306/$dbName\"\n";
            $envContent .= "NEXTAUTH_URL=\"$appUrl\"\n";
            $envContent .= "NEXTAUTH_SECRET=\"" . bin2hex(random_bytes(32)) . "\"\n";
            $envContent .= "NODE_ENV=\"production\"\nPORT=3000\n";
            file_put_contents(__DIR__ . '/.env', $envContent);
            file_put_contents(__DIR__ . '/.installed', date('c'));
            $step = 'done';
        } else {
            $error = "The 'User' table was not found. Please ensure you imported vanguard-cell-database.sql via phpMyAdmin first.";
            $step = 'manual_import';
        }
        $mysqli->close();
    } else {
        $error = 'Database connection failed: ' . $mysqli->connect_error;
        $step = 'manual_import';
    }
}

// ============================================================
// RENDER
// ============================================================
if ($error) {
    echo '<div class="error">' . $error . '</div>';
}

// ---- STEP 1 ----
if ($step === '1') {
    $checks = [];
    $checks[] = ['PHP 8.1+', version_compare(PHP_VERSION, '8.1.0', '>='), PHP_VERSION];
    $checks[] = ['MySQLi Extension', extension_loaded('mysqli'), ''];
    $checks[] = ['mbstring Extension', extension_loaded('mbstring'), ''];
    $checks[] = ['Read/Write Permissions', is_writable(__DIR__), ''];
    $checks[] = ['SQL Dump File', file_exists(__DIR__ . '/vanguard-cell-database.sql'), ''];

    $nodeVersion = trim(shell_exec('node --version 2>/dev/null') ?? '');
    $nodeOk = !empty($nodeVersion);
    $checks[] = ['Node.js 18+ (for running the app)', $nodeOk, $nodeVersion];

    // Check if mysql CLI is available
    $mysqlCli = trim(shell_exec('which mysql 2>/dev/null') ?? '');
    $checks[] = ['mysql CLI (faster import)', !empty($mysqlCli), $mysqlCli ? 'available' : 'not found'];

    $criticalPassed = true;
    foreach ($checks as $i => $c) {
        if ($i < 4 && !$c[1]) $criticalPassed = false;
    }
?>
    <div class="steps">
        <div class="step-dot active"></div><div class="step-dot"></div><div class="step-dot"></div><div class="step-dot"></div>
    </div>
    <h2>Step 1: Server Requirements</h2>
    <p style="font-size:13px;color:#666;margin-bottom:20px">The installer will verify that your server meets the minimum requirements.</p>
    <?php foreach ($checks as $i => $c): ?>
        <div class="check">
            <span class="<?php echo $c[1] ? 'ok' : ($i >= 4 ? 'warn' : 'fail') ?>"><?php echo $c[1] ? '✓' : '✗' ?></span>
            <strong><?php echo htmlspecialchars($c[0]) ?></strong>
            <?php if ($c[2]): ?><span style="color:#888;font-size:12px">(<?php echo htmlspecialchars($c[2]) ?>)</span><?php endif; ?>
        </div>
    <?php endforeach; ?>
    <?php if (!$nodeOk): ?>
    <div class="info"><strong>Node.js not detected.</strong> You can still complete the installer and set up Node.js later via cPanel → Setup Node.js App.</div>
    <?php endif; ?>
    <?php if ($criticalPassed): ?>
    <form method="post" style="margin-top:24px">
        <input type="hidden" name="step" value="2">
        <button type="submit" class="btn btn-gold">Continue to Database Setup →</button>
    </form>
    <?php else: ?>
    <div class="error" style="margin-top:20px">Please fix the failed requirements before continuing.</div>
    <?php endif; ?>

<?php
// ---- STEP 2 ----
} elseif ($step === '2') {
    $dbHost = $_SESSION['db_host'] ?? 'localhost';
    $dbName = $_SESSION['db_name'] ?? '';
    $dbUser = $_SESSION['db_user'] ?? '';
?>
    <div class="steps">
        <div class="step-dot done"></div><div class="step-dot active"></div><div class="step-dot"></div><div class="step-dot"></div>
    </div>
    <h2>Step 2: Database Configuration</h2>
    <p style="font-size:13px;color:#666;margin-bottom:20px">Enter your MySQL database credentials.</p>
    <form method="post">
        <input type="hidden" name="step" value="3">
        <input type="hidden" name="action" value="test">
        <div class="form-group">
            <label>Database Host</label>
            <input type="text" name="db_host" value="<?php echo htmlspecialchars($dbHost) ?>" required>
            <span class="hint">Usually <code>localhost</code></span>
        </div>
        <div class="grid">
            <div class="form-group"><label>Database Name</label><input type="text" name="db_name" value="<?php echo htmlspecialchars($dbName) ?>" placeholder="username_vanguard" required></div>
            <div class="form-group"><label>Database User</label><input type="text" name="db_user" value="<?php echo htmlspecialchars($dbUser) ?>" placeholder="username_vanguard" required></div>
        </div>
        <div class="form-group"><label>Database Password</label><input type="password" name="db_pass" placeholder="••••••••" required></div>
        <button type="submit" class="btn">Test Connection & Continue →</button>
    </form>

<?php
// ---- STEP 3 ----
} elseif ($step === '3') {
    $appUrl = 'https://' . $_SERVER['HTTP_HOST'];
    $pathParts = pathinfo($_SERVER['SCRIPT_NAME']);
    if ($pathParts['dirname'] !== '/') $appUrl .= $pathParts['dirname'];
    $dbHost = $_SESSION['db_host'] ?? 'localhost';
    $dbName = $_SESSION['db_name'] ?? '';
    $dbUser = $_SESSION['db_user'] ?? '';
    $dbPass = $_SESSION['db_pass'] ?? '';
?>
    <div class="steps">
        <div class="step-dot done"></div><div class="step-dot done"></div><div class="step-dot active"></div><div class="step-dot"></div>
    </div>
    <h2>Step 3: Application Configuration</h2>
    <div class="success">✓ Database connection successful!</div>
    <form method="post" id="installForm">
        <input type="hidden" name="step" value="install">
        <input type="hidden" name="action" value="install">
        <input type="hidden" name="db_host" value="<?php echo htmlspecialchars($dbHost) ?>">
        <input type="hidden" name="db_name" value="<?php echo htmlspecialchars($dbName) ?>">
        <input type="hidden" name="db_user" value="<?php echo htmlspecialchars($dbUser) ?>">
        <input type="hidden" name="db_pass" value="<?php echo htmlspecialchars($dbPass) ?>">
        <div class="grid">
            <div class="form-group"><label>Application Name</label><input type="text" name="app_name" value="Vanguard Cell Management System" required></div>
            <div class="form-group"><label>Application URL</label><input type="url" name="app_url" value="<?php echo htmlspecialchars($appUrl) ?>" required></div>
        </div>
        <h2 style="margin-top:24px">Super Admin Account</h2>
        <p style="font-size:13px;color:#666;margin-bottom:16px">This will be the primary administrator account.</p>
        <div class="form-group"><label>Admin Name</label><input type="text" name="admin_name" value="System Super Admin" required></div>
        <div class="form-group"><label>Admin Email</label><input type="email" name="admin_email" value="superadmin@vanguard.test" required></div>
        <div class="form-group"><label>Admin Password</label><input type="password" name="admin_pass" required minlength="8" placeholder="Minimum 8 characters"></div>
        <button type="submit" class="btn btn-gold" id="installBtn">⚡ Install Vanguard Cell Management System</button>
    </form>
    <div class="info" style="margin-top:16px"><strong>Installation may take 10-60 seconds.</strong> Do not refresh or close this page. A live log will show progress.</div>

<?php
// ---- MANUAL IMPORT FALLBACK ----
} elseif ($step === 'manual_import') {
?>
    <div class="steps">
        <div class="step-dot done"></div><div class="step-dot done"></div><div class="step-dot active"></div><div class="step-dot"></div>
    </div>
    <h2>Manual Database Import Required</h2>
    <div class="warn-box">The automatic SQL import failed on your server. This is usually due to PHP timeout limits or restricted functions on shared hosting. You can import the database manually via phpMyAdmin.</div>
    <div class="info">
        <strong>Steps to import manually:</strong>
        <ol style="margin:8px 0 0 20px;font-size:13px;line-height:1.8">
            <li>Log in to <strong>cPanel → phpMyAdmin</strong></li>
            <li>Select your database (<code><?php echo htmlspecialchars($_SESSION['db_name'] ?? '') ?></code>) in the left sidebar</li>
            <li>Click the <strong>Import</strong> tab at the top</li>
            <li>Click <strong>Choose File</strong> and select <code>vanguard-cell-database.sql</code> (from this folder)</li>
            <li>Scroll down and click <strong>Go</strong></li>
            <li>Wait for "Import has been successfully finished"</li>
            <li>Come back here and click the button below</li>
        </ol>
    </div>
    <form method="post">
        <input type="hidden" name="action" value="skip_import">
        <button type="submit" class="btn btn-gold">✓ I've imported the SQL — Continue Setup</button>
    </form>

<?php
// ---- DONE ----
} elseif ($step === 'done') {
?>
    <div class="steps">
        <div class="step-dot done"></div><div class="step-dot done"></div><div class="step-dot done"></div><div class="step-dot done"></div>
    </div>
    <div style="text-align:center;padding:20px 0">
        <div style="width:80px;height:80px;background:#22C55E;border-radius:50%;margin:0 auto 20px;display:flex;align-items:center;justify-content:center;font-size:40px;color:white">✓</div>
        <h2 style="color:#0B2A5B;font-size:24px;margin-bottom:8px">Installation Complete!</h2>
        <p style="color:#666;font-size:14px">The Vanguard Cell Management System has been installed successfully.</p>
    </div>
    <dl class="credentials">
        <dt>Super Admin Login</dt>
        <dd><strong>Email:</strong> <?php echo htmlspecialchars($_POST['admin_email'] ?? $_SESSION['admin_email'] ?? '') ?></dd>
        <dd><strong>Password:</strong> (the password you set)</dd>
    </dl>
    <div class="info">
        <strong>Next steps:</strong>
        <ol style="margin:8px 0 0 20px;font-size:13px;line-height:1.6">
            <li><strong>Set up Node.js</strong> in cPanel → Software → Setup Node.js App:
                <ul style="margin:4px 0 0 20px">
                    <li>Node.js version: 18.x or 20.x</li>
                    <li>Application mode: Production</li>
                    <li>Application root: this folder</li>
                    <li>Startup file: <code>server.js</code></li>
                </ul>
            </li>
            <li><strong>Or via terminal:</strong>
                <pre>cd ~/vanguard-cell && npm install && npm run build && npm run start:prod</pre>
            </li>
            <li><strong>Delete <code>install.php</code></strong> for security.</li>
            <li><strong>Visit your app</strong> and log in.</li>
        </ol>
    </div>
    <a href="/" class="btn btn-gold" style="text-decoration:none">Open Vanguard Cell App →</a>
<?php
}
?>

    </div>
</div>
<script>
// Disable install button on submit and show progress
document.getElementById('installForm')?.addEventListener('submit', function() {
    var btn = document.getElementById('installBtn');
    btn.disabled = true;
    btn.textContent = 'Installing... please wait (live log below)';
    btn.style.background = '#9CA3AF';
});
</script>
</body>
</html>

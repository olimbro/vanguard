// Vanguard Cell Management System — Production Server
// For cPanel Node.js deployment (Passenger or Setup Node.js App)
const { createServer } = require('http')
const next = require('next')

const port = process.env.PORT || 3000
const app = next({ dev: false, port })
const handle = app.getRequestHandler()

app.prepare().then(() => {
  createServer((req, res) => {
    handle(req, res)
  }).listen(port, (err) => {
    if (err) {
      console.error('Failed to start server:', err)
      process.exit(1)
    }
    console.log('> Vanguard Cell Management System ready on port ' + port)
  })
}).catch((err) => {
  console.error('Failed to prepare Next.js:', err)
  process.exit(1)
})

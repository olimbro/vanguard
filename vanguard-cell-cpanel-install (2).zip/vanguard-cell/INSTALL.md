# Vanguard Cell Management System — cPanel Installation Guide

A complete, production-ready Progressive Web App for Christ Embassy — Vanguard Cell 1, Awka Church. This guide walks you through deploying the application to a standard cPanel hosting environment.

---

## Table of Contents

1. [Pre-Installation Checklist](#1-pre-installation-checklist)
2. [Upload the Files](#2-upload-the-files)
3. [Create the Database](#3-create-the-database)
4. [Run the Installer](#4-run-the-installer)
5. [Set Up Node.js](#5-set-up-nodejs)
6. [Build & Start the App](#6-build--start-the-app)
7. [Configure Cron Jobs](#7-configure-cron-jobs)
8. [Enable SSL/HTTPS](#8-enable-sslhttps)
9. [Install as PWA](#9-install-as-pwa)
10. [Post-Installation](#10-post-installation)
11. [Troubleshooting](#troubleshooting)

---

## 1. Pre-Installation Checklist

Ensure your cPanel hosting meets these requirements:

| Requirement | Minimum | Recommended |
|---|---|---|
| **PHP** | 8.1+ | 8.3+ |
| **MySQL/MariaDB** | 8.0 / 10.6 | 10.11+ |
| **Node.js** | 18.x | 20.x LTS |
| **npm** | 9.x | 10.x |
| **Disk Space** | 500 MB | 1 GB |
| **SSL/HTTPS** | Required | Let's Encrypt (free) |

**Check in cPanel:**
- ✅ **Software → Setup Node.js App** is available (most cPanel hosts include this)
- ✅ **Databases → MySQL Database Wizard** is available
- ✅ **Files → File Manager** or FTP access
- ✅ **Advanced → Cron Jobs** is available
- ✅ **Security → SSL/TLS Status** (or Let's Encrypt auto-install)

> **Note:** If your cPanel does not have Node.js support, ask your hosting provider to enable it, or choose a host that supports Node.js (e.g., Cloudways, A2 Hosting, Hostinger, Namecheap).

---

## 2. Upload the Files

### Option A: Via cPanel File Manager

1. Log in to cPanel
2. Go to **Files → File Manager**
3. Navigate to your web root (usually `public_html/` or a subdirectory like `public_html/vanguard-cell/`)
4. Click **Upload** and select `vanguard-cell.zip`
5. Right-click the zip → **Extract**
6. Verify these files are present:
   ```
   install.php
   vanguard-cell-database.sql
   package.json
   setup.sh
   .htaccess
   src/
   prisma/
   public/
   next.config.ts
   tsconfig.json
   tailwind.config.ts
   postcss.config.mjs
   components.json
   ```

### Option B: Via FTP (FileZilla, WinSCP, etc.)

1. Connect to your server via FTP
2. Upload the entire `vanguard-cell` folder to `public_html/` (or a subdirectory)
3. Upload the `.htaccess` file (may need to enable "show hidden files" in your FTP client)

---

## 3. Create the Database

1. In cPanel, go to **Databases → MySQL Database Wizard**
2. **Create a database:**
   - Name: `vanguard_cell` (your cPanel prefix will be added, e.g., `username_vanguard_cell`)
3. **Create a database user:**
   - Username: `vcell_admin` (becomes `username_vcell_admin`)
   - Password: generate a strong password and **save it**
4. **Assign privileges:**
   - Check **All Privileges**
5. Click **Next Step** to finish

> **Important:** Note down the database name, username, and password — you'll need them in Step 4.

---

## 4. Run the Installer

The installer is a PHP wizard (like Laravel's installer) that:
- Checks server requirements
- Tests your database connection
- Imports the SQL schema + seed data
- Creates the Super Admin account
- Generates the `.env` configuration file

### Steps:

1. Open your browser and navigate to:
   ```
   https://yourdomain.com/install.php
   ```
   (or `https://yourdomain.com/vanguard-cell/install.php` if installed in a subdirectory)

2. **Step 1 — Requirements Check:**
   - Verify all checks pass (green ✓)
   - If Node.js is not detected, you can still proceed — you'll set it up in Step 5

3. **Step 2 — Database Configuration:**
   - Enter your MySQL host (usually `localhost`)
   - Enter the database name, username, and password from Step 3

4. **Step 3 — Application Configuration:**
   - App name: `Vanguard Cell Management System`
   - App URL: auto-detected (verify it's correct)
   - **Super Admin Email:** e.g., `pastor@yourchurch.org`
   - **Super Admin Password:** choose a strong password (8+ characters)

5. **Step 4 — Install:**
   - Click **⚡ Install Vanguard Cell Management System**
   - Wait for the installer to:
     - Import the SQL dump (creates all 30 tables with seed data)
     - Set the super admin password
     - Generate the `.env` file
   - You'll see a success screen with your login credentials

> **Security:** After installation, **delete `install.php`** from the server.

---

## 5. Set Up Node.js

### In cPanel → Software → Setup Node.js App:

1. Click **Create Application**
2. Configure:
   - **Node.js version:** 20.x (or 18.x minimum)
   - **Application mode:** Production
   - **Application root:** `/home/USERNAME/vanguard-cell` (the folder where you extracted the zip)
   - **Application URL:** your domain or subdomain
   - **Application startup file:** `server.js`
3. Click **Create**

> **Note:** If your cPanel doesn't have "Setup Node.js App", look for "Node.js" or "Passenger" in the Software section. Some hosts use different names.

### Environment Variables:

In the Node.js app settings, add these environment variables (or they'll be read from `.env`):

| Variable | Value |
|---|---|
| `NODE_ENV` | `production` |
| `PORT` | `3000` (or the port assigned by cPanel) |

The `DATABASE_URL` is already in your `.env` file from the installer.

---

## 6. Build & Start the App

### Via cPanel Terminal (or SSH):

1. Open **cPanel → Terminal** (or connect via SSH)
2. Navigate to your app folder:
   ```bash
   cd ~/vanguard-cell
   ```
3. Run the setup script:
   ```bash
   bash setup.sh
   ```
   This will:
   - Install Node.js dependencies (`npm install`)
   - Generate the Prisma client
   - Build the Next.js production app (`npm run build`)
   - Copy the MySQL Prisma schema into place

4. **Start the application:**
   - In cPanel → Setup Node.js App → click **Restart** (or **Run NPM Install** then **Restart**)
   - Or via terminal: `npm run start:prod`

### Via cPanel Node.js App UI:

If you don't have terminal access:

1. In **Setup Node.js App**, scroll to the **NPM Install** section
2. Click **Run npm install**
3. Wait for it to complete
4. Scroll to **Run script** → select `build` → click **Run**
5. Wait for the build to complete
6. Click **Restart** to start the app

---

## 7. Configure Cron Jobs

Set up a cron job to keep the app running and handle scheduled tasks:

### In cPanel → Advanced → Cron Jobs:

**Cron Job 1 — Keep-alive (every 5 minutes):**
```
*/5 * * * * curl -s https://yourdomain.com/ > /dev/null
```

**Cron Job 2 — Recurring event generation (daily at midnight):**
```
0 0 * * * cd /home/USERNAME/vanguard-cell && node scripts/generate-recurring.js >> /home/USERNAME/vanguard-cell/logs/cron.log 2>&1
```

**Cron Job 3 — Inactivity detection (daily at 6 AM):**
```
0 6 * * * cd /home/USERNAME/vanguard-cell && node scripts/check-inactivity.js >> /home/USERNAME/vanguard-cell/logs/cron.log 2>&1
```

---

## 8. Enable SSL/HTTPS

PWA features (service worker, installability) **require HTTPS**.

### In cPanel → Security → SSL/TLS Status:

1. Click **Run AutoSSL** (free Let's Encrypt certificate)
2. Wait for it to complete (1-2 minutes)
3. Verify your site loads at `https://yourdomain.com`

### Force HTTPS:

The included `.htaccess` file already includes HTTPS redirection. Verify it's active by visiting `http://yourdomain.com` — you should be redirected to `https://`.

---

## 9. Install as PWA

The app is a Progressive Web App — users can install it on their phones and desktops.

### Android (Chrome):
1. Visit your site in Chrome
2. Tap the **menu (⋮)** → **Install app**
3. The app appears on your home screen

### iPhone/iPad (Safari):
1. Visit your site in Safari
2. Tap the **Share** button → **Add to Home Screen**
3. The app appears on your home screen

### Desktop (Chrome/Edge):
1. Visit your site
2. Click the **install icon (⊕)** in the address bar
3. Or click **menu (⋮)** → **Install Vanguard Cell...**

The PWA supports:
- ✅ Offline attendance (IndexedDB queue + auto-sync)
- ✅ Installable on Android, iOS, Desktop
- ✅ Standalone display mode (no browser chrome)
- ✅ App icons (192px, 512px, maskable)
- ✅ Christ Embassy theme colors (Navy + Gold)

---

## 10. Post-Installation

### Delete the installer:
```bash
rm ~/vanguard-cell/install.php
```

### Verify everything works:
1. Visit `https://yourdomain.com`
2. Log in with your Super Admin credentials
3. Check the dashboard loads with data
4. Go to **Users** → verify you can see all demo users
5. Go to **Permissions** → verify the permission matrix
6. Go to **Attendance** → try marking attendance
7. On your phone, install the PWA and test check-in

### Customize for your cell:
1. Log in as Super Admin
2. Go to **Settings** → update cell information
3. Go to **Users** → assign roles (Cell Admin, Worker, etc.)
4. Go to **Permissions** → customize what each role can do
5. Go to **Events** → create your cell's events

### Change the super admin password:
1. Log in as Super Admin
2. Go to **Profile** → change password
3. Or via phpMyAdmin: run `UPDATE User SET passwordHash = ... WHERE role = 'SUPER_ADMIN'`

---

## Troubleshooting

### "Database connection failed"
- Verify the database name, username, and password in `.env`
- Check the user has **All Privileges** on the database
- Ensure the MySQL host is `localhost` (not an IP)

### "Node.js not found" / App won't start
- In cPanel → Setup Node.js App, verify the Node.js version is selected
- Check the application root path is correct
- Try running `node --version` in cPanel Terminal

### "502 Bad Gateway" or "503 Service Unavailable"
- The Node.js app crashed — check the error log:
  ```bash
  cat ~/vanguard-cell/logs/error.log
  ```
- Try restarting the app in cPanel → Setup Node.js App → Restart
- Verify `npm run build` completed successfully

### "PWA not installable"
- Ensure HTTPS is active (check SSL/TLS Status)
- Verify `/manifest.json` loads: visit `https://yourdomain.com/manifest.json`
- Verify `/sw.js` loads: visit `https://yourdomain.com/sw.js`
- Check the browser console for service worker errors

### "Offline attendance not syncing"
- The service worker queues offline attendance in IndexedDB
- When back online, it auto-syncs via `/api/sync`
- Check the "pending sync" badge in the top bar
- Click it to manually trigger sync

### "QR code not displaying"
- QR codes use the external API `api.qrserver.com`
- Ensure your server can make outbound HTTPS requests
- Or replace with a local QR library in `src/components/app/views/attendance.tsx`

### Need more help?
- Check the full documentation in `download/README.md`
- Review the audit log at **Audit Log** in the admin panel
- Check server error logs in cPanel → Metrics → Errors

---

## File Structure (After Installation)

```
vanguard-cell/
├── .env                      ← Generated by installer (DB credentials)
├── .installed                ← Marker file (installation complete)
├── .htaccess                 ← Apache config (HTTPS, caching, security)
├── install.php               ← DELETE after installation
├── vanguard-cell-database.sql ← SQL dump (already imported)
├── setup.sh                  ← Post-install setup script
├── package.json              ← Node.js dependencies
├── next.config.ts            ← Next.js configuration
├── tsconfig.json             ← TypeScript configuration
├── tailwind.config.ts        ← Tailwind CSS configuration
├── prisma/
│   └── schema.mysql.prisma   ← MySQL database schema
├── public/
│   ├── manifest.json         ← PWA manifest
│   ├── sw.js                 ← Service Worker
│   ├── offline.html          ← Offline fallback page
│   └── icons/                ← PWA icons (192px, 512px, maskable)
└── src/                      ← Application source code
    ├── app/                  ← Next.js routes + API endpoints
    ├── lib/                  ← Auth, gamification, RBAC
    └── components/           ← React UI components
```

---

## Support

For questions about this application:
- Review the in-app **Settings → About** page
- Check the audit log for any permission changes
- Ensure you're running the latest version

**Mission:** WIN SOULS · BUILD PEOPLE · DEVELOP LEADERS · MULTIPLY CELLS

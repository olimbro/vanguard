#!/bin/bash
# Vanguard Cell Management System — cPanel Setup Script
# Run this AFTER uploading files and completing the PHP installer.
#
# Usage (via SSH or cPanel Terminal):
#   cd ~/vanguard-cell && bash setup.sh
#
# This script:
# 1. Installs Node.js dependencies
# 2. Generates the Prisma client
# 3. Builds the Next.js production app
# 4. Verifies the .env file exists

set -e

echo "=========================================="
echo "  Vanguard Cell Management System"
echo "  cPanel Setup Script"
echo "=========================================="
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "✗ Node.js is not installed."
    echo "  Enable Node.js in cPanel → Software → Setup Node.js App"
    echo "  Or ask your hosting provider to install Node.js 18+"
    exit 1
fi

NODE_VERSION=$(node --version)
echo "✓ Node.js detected: $NODE_VERSION"

if [[ "$NODE_VERSION" =~ ^v([0-9]+) ]]; then
    MAJOR=${BASH_REMATCH[1]}
    if [ "$MAJOR" -lt 18 ]; then
        echo "✗ Node.js 18+ required. You have $NODE_VERSION"
        exit 1
    fi
fi

# Check .env
if [ ! -f .env ]; then
    echo "✗ .env file not found."
    echo "  Run the installer first: visit https://yourdomain.com/install.php"
    exit 1
fi
echo "✓ .env file found"

# Check database.sql was imported
echo ""
echo "Checking database connection..."
npx prisma db pull --schema=prisma/schema.mysql.prisma 2>/dev/null && echo "✓ Database connection OK" || {
    echo "✗ Database connection failed. Check your .env DATABASE_URL"
    echo "  Also ensure you imported vanguard-cell-database.sql via phpMyAdmin"
    exit 1
}

# Install dependencies
echo ""
echo "Installing Node.js dependencies..."
npm install --production=false
echo "✓ Dependencies installed"

# Generate Prisma client
echo ""
echo "Generating Prisma client..."
npx prisma generate --schema=prisma/schema.mysql.prisma
cp prisma/schema.mysql.prisma prisma/schema.prisma
echo "✓ Prisma client generated"

# Build the app
echo ""
echo "Building Next.js production app..."
npm run build
echo "✓ Build complete"

# Create a marker file
echo ""
echo "Setup complete!"
echo ""
echo "=========================================="
echo "  NEXT STEPS"
echo "=========================================="
echo ""
echo "1. Start the app in cPanel → Setup Node.js App → Run:"
echo "   npm run start:prod"
echo ""
echo "2. Set up a cron job (cPanel → Cron Jobs):"
echo "   */5 * * * * cd $(pwd) && node -e \"console.log('keepalive')\""
echo ""
echo "3. Delete install.php for security:"
echo "   rm install.php"
echo ""
echo "4. Visit your site and log in:"
echo "   Email: (the super admin email you set during installation)"
echo "   Password: (the password you chose)"
echo ""
